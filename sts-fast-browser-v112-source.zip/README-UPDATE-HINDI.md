STS Fast Browser v1.0.112 (versionCode 113)

- Restored stable v1.0.110 Replace logic, with single-word tap.
- Removed problematic multiword drag/range box behavior from the live PDF editor.
- Inside Replace only, a Delete button appears beside Apply.
- Tap original PDF word -> Delete -> the exact font glyph bytes are removed from native PDF content stream, preserving space and adjacent words. Edit is validated by rendering an actual temporary PDF before acceptance, then saved in the same viewer.
- On scanned image-only PDFs, if background is flat and safe, Delete masks the selected word's raster pixels with sampled background; underlying scanned image data remains, so this is *visual* deletion, not forensic redaction. Save As required. If background isn't uniform, Delete refuses to avoid damaging borders/stamps.
- Undo/Redo supported for Delete. Upper toolbar remains Text, Replace, Highlighter, Undo, Redo; Save and Save As remain Three-Dot items.
- Original locked v1.0.105 unchanged; no other browser/editor modules touched.
- Text native fonts, unusual encodings, multiple identical occurrences on a page may still make accurate native Delete impossible; safely reject rather than silently altering wrong content.
- Android compile and local unit tests do not replace on-device PDF testing.
