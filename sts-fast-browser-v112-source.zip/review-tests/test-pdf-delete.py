from pathlib import Path
r=Path(__file__).resolve().parents[1]
v=(r/'app/src/main/java/com/sts/fastbrowser/PdfViewerActivity.java').read_text()
n=(r/'app/src/main/java/com/sts/fastbrowser/PdfNativeTextReplace.java').read_text()
m=(r/'app/src/main/java/com/sts/fastbrowser/PdfEditMark.java').read_text()
b=(r/'app/build.gradle').read_text()
assert 'new String[]{"Text", "Replace", "Highlighter", "Undo", "Redo"}' in v
assert 'pm.getMenu().add("Save")' in v and 'pm.getMenu().add("Save As")' in v
assert 'deleteTextButton=editButton("Delete")' in v
assert 'deleteTextButton.setVisibility(isPdfReplacementMode()?View.VISIBLE:View.GONE)' in v
assert 'deleteTextButton.setOnClickListener(v -> deleteSelectedPdfText())' in v
assert 'private void applyPdfReplacement(){changeSelectedPdfText(false);}' in v
assert 'private void deleteSelectedPdfText(){changeSelectedPdfText(true);}' in v
assert 'String changed=delete?"":inlineText.getText().toString().trim()' in v
assert 'PdfTextSelection.pick(textDocument,page,x,y)' in v
assert 'selectPdfText(pageIndex,xy[0],xy[1]);' in v
assert 'selectPdfRange(pageIndex,' not in v
assert 'spanActive' not in v and 'spanDragging' not in v
assert 'canvas.drawRect(Math.min(sx,ex)' not in v
assert '"Delete".equals(mark.kind)' in v
assert 'PdfNativeTextReplace.delete(doc,mark.page,mark.oldText)' in v
assert 'PdfNativeTextReplace.delete(doc,m.page,m.oldText)' in v
assert 'isNativePdfEdit(mark)' in v
assert 'refreshNativeReplacePreview();redrawPdfMarks()' in v
assert '"ScanDelete".equals(mark.kind)' in v
assert '"ScanDelete".equals(kind)' in m
assert 'if("ScanDelete".equals(kind))return;' in m
assert 'if(scanned.complexBackground)' in v
assert 'saveRow.setVisibility(View.VISIBLE)' in v
assert 'static void delete(PDDocument doc,int pageIndex,String oldText)' in n
assert 'mutate(doc,pageIndex,oldText,"",true)' in n
assert 'float adjustment=byteWidth(m.font,newBytes)-byteWidth(m.font,oldBytes)' in n
assert 'page.setContents(stream)' in n
assert "versionName '1.0.112'" in b and 'versionCode 113' in b
print('PASS restored tap-only Replace; Delete within Replace; native removal and scan safety; preview/undo/save')
