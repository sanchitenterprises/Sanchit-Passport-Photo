from pathlib import Path
root=Path(__file__).resolve().parents[1]
v=(root/'app/src/main/java/com/sts/fastbrowser/PdfViewerActivity.java').read_text()
b=(root/'app/build.gradle').read_text()
assert 'renderActualNativeReplacement(nativeMarks,sel.page)' in v
assert 'PdfNativeTextReplace.replace(doc,m.page,m.oldText,m.text)' in v
assert 'acceptNativePreview(sel.page,result)' in v
assert 'if(result==null){editHint.setText((delete?"Delete":"Replace")' in v
assert 'replacementApplying' in v
assert 'replacementPreviewVersion' in v
assert 'refreshNativeReplacePreview()' in v
assert 'replacementPreviewPage==pageIndex' in v
assert '!isNativePdfEdit(mark)' in v
assert "abiFilters 'arm64-v8a', 'armeabi-v7a'" in b
print('PDF native preview and ARM offline OCR tests passed')
