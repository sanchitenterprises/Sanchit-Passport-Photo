package com.sts.fastbrowser;

import com.tom_roush.pdfbox.cos.COSArray;
import com.tom_roush.pdfbox.cos.COSBase;
import com.tom_roush.pdfbox.cos.COSFloat;
import com.tom_roush.pdfbox.cos.COSName;
import com.tom_roush.pdfbox.cos.COSNumber;
import com.tom_roush.pdfbox.cos.COSString;
import com.tom_roush.pdfbox.contentstream.operator.Operator;
import com.tom_roush.pdfbox.pdfparser.PDFStreamParser;
import com.tom_roush.pdfbox.pdfwriter.ContentStreamWriter;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.pdmodel.PDPage;
import com.tom_roush.pdfbox.pdmodel.PDResources;
import com.tom_roush.pdfbox.pdmodel.common.PDStream;
import com.tom_roush.pdfbox.pdmodel.font.PDFont;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Conservative *native* PDF text-object replacement, no white masking or rasterized text.
 * Only replaces an exact unique text fragment contained within one Tj/TJ string in the
 * page content stream, using its existing font and restoring the original text advance.
 * Rejects ambiguous, split-across-operators, non-encodable and image/scanned text.
 */
final class PdfNativeTextReplace {
    private PdfNativeTextReplace() {}
    private static final class Glyph {
        final int charFrom, charTo, byteFrom, byteTo;
        Glyph(int a,int b,int c,int d){charFrom=a;charTo=b;byteFrom=c;byteTo=d;}
    }
    private static final class Match {
        int opIndex, arrayIndex, fromByte, toByte;
        COSString token;
        PDFont font;
    }

    static void replace(PDDocument doc,int pageIndex,String oldText,String replacement) throws IOException {
        mutate(doc,pageIndex,oldText,replacement,false);
    }

    /** Remove the exact selected native glyph bytes, retaining their advance.
     * This is actual content-stream deletion, not white paint or text overlay. */
    static void delete(PDDocument doc,int pageIndex,String oldText) throws IOException {
        mutate(doc,pageIndex,oldText,"",true);
    }
    private static void mutate(PDDocument doc,int pageIndex,String oldText,String replacement,boolean deleting) throws IOException {
        if (oldText==null||oldText.isEmpty()||replacement==null||(!deleting&&replacement.isEmpty())
                ||oldText.length()>500||replacement.length()>500)
            throw new IOException("Empty or overly long PDF text");
        PDPage page=doc.getPage(pageIndex);
        PDResources resources=page.getResources();
        if(resources==null)throw new IOException("No page font resources");
        PDFStreamParser parser=new PDFStreamParser(page);
        parser.parse();
        List<Object> tokens=parser.getTokens();
        PDFont font=null;
        List<Match> matches=new ArrayList<>();
        for(int i=0;i<tokens.size();i++){
            Object current=tokens.get(i);
            if(!(current instanceof Operator))continue;
            String op=((Operator)current).getName();
            if("Tf".equals(op)){
                if(i>=2 && tokens.get(i-2) instanceof COSName && tokens.get(i-1) instanceof COSNumber)
                    font=resources.getFont((COSName)tokens.get(i-2));
            }else if("Tj".equals(op) && font!=null && i>=1 && tokens.get(i-1) instanceof COSString){
                findMatches((COSString)tokens.get(i-1),font,oldText,i,-1,matches);
            }else if("TJ".equals(op) && font!=null && i>=1 && tokens.get(i-1) instanceof COSArray){
                COSArray items=(COSArray)tokens.get(i-1);
                for(int j=0;j<items.size();j++)if(items.get(j) instanceof COSString)
                    findMatches((COSString)items.get(j),font,oldText,i,j,matches);
            }
        }
        if(matches.size()!=1)throw new IOException(matches.isEmpty()
                ?"Selected text cannot be edited natively (image, subset, or split text)"
                :"Selected PDF text occurs more than once on the page");
        Match m=matches.get(0);
        byte[] raw=m.token.getBytes();
        byte[] before=Arrays.copyOfRange(raw,0,m.fromByte);
        byte[] oldBytes=Arrays.copyOfRange(raw,m.fromByte,m.toByte);
        byte[] after=Arrays.copyOfRange(raw,m.toByte,raw.length);
        byte[] newBytes;
        try { newBytes=m.font.encode(replacement); }
        catch(Exception e){throw new IOException("Existing PDF font cannot encode replacement",e);}
        float adjustment=byteWidth(m.font,newBytes)-byteWidth(m.font,oldBytes);
        COSArray changed=new COSArray();
        if(before.length!=0)changed.add(new COSString(before));
        changed.add(new COSString(newBytes));
        // TJ uses units of 1/1000 text-space; positive advance compensation.
        if(Math.abs(adjustment)>0.001f)changed.add(new COSFloat(adjustment));
        if(after.length!=0)changed.add(new COSString(after));
        if(m.arrayIndex<0){
            tokens.set(m.opIndex-1,changed);
            tokens.set(m.opIndex,Operator.getOperator("TJ"));
        }else{
            COSArray original=(COSArray)tokens.get(m.opIndex-1);
            COSArray rebuilt=new COSArray();
            for(int j=0;j<original.size();j++){
                if(j==m.arrayIndex){for(int k=0;k<changed.size();k++)rebuilt.add(changed.get(k));}
                else rebuilt.add(original.get(j));
            }
            tokens.set(m.opIndex-1,rebuilt);
        }
        // Prepare new stream first. Change page resources only after complete serialization.
        ByteArrayOutputStream data=new ByteArrayOutputStream();
        new ContentStreamWriter(data).writeTokens(tokens);
        PDStream stream=new PDStream(doc);
        try(OutputStream out=stream.createOutputStream(COSName.FLATE_DECODE)){
            data.writeTo(out);
        }
        page.setContents(stream);
    }

    private static float byteWidth(PDFont font,byte[] encoded) throws IOException {
        ByteArrayInputStream stream=new ByteArrayInputStream(encoded);
        float width=0;
        while(stream.available()>0)width+=font.getWidth(font.readCode(stream));
        return width;
    }

    private static void findMatches(COSString token,PDFont font,String target,
                                    int opIndex,int arrIndex,List<Match> out){
        try {
            byte[] raw=token.getBytes();
            ByteArrayInputStream input=new ByteArrayInputStream(raw);
            StringBuilder decoded=new StringBuilder();
            List<Glyph> glyphs=new ArrayList<>();
            while(input.available()>0){
                int from=raw.length-input.available();
                int code=font.readCode(input);
                int to=raw.length-input.available();
                String text=font.toUnicode(code);
                if(text==null||text.isEmpty())return;
                int charFrom=decoded.length();decoded.append(text);
                glyphs.add(new Glyph(charFrom,decoded.length(),from,to));
            }
            int from=decoded.indexOf(target);
            while(from>=0){
                int to=from+target.length();
                Glyph first=null,last=null;
                for(Glyph g:glyphs){if(g.charFrom==from)first=g;if(g.charTo==to)last=g;}
                if(first!=null&&last!=null&&first.byteFrom<last.byteTo){
                    Match match=new Match();match.opIndex=opIndex;match.arrayIndex=arrIndex;
                    match.token=token;match.font=font;match.fromByte=first.byteFrom;match.toByte=last.byteTo;
                    out.add(match);
                }
                from=decoded.indexOf(target,from+1);
            }
        }catch(Exception ignored){/* unknown mapping: leave original PDF untouched */}
    }
}
