"""Compile the production JavaScript builder and simulate a transient generated PDF blob.

This test is deliberately offline; it does not assert that UIDAI itself was exercised.
"""
from pathlib import Path
import os, subprocess, tempfile, textwrap
src=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/sts/fastbrowser/MainActivity.java').read_text()
start=src.index('    private void injectPdfHook(WebView view) {')
end=src.index('    private class PdfBridge {',start)
method=src[start:end]
assert 'var saved=new Map()' in method and 'STSPdfBlob.begin(id' in method
assert 'URL.createObjectURL=function' in method and 'window.__stsStartPdf' in method
assert 'new FileReader()' in method
assert 'while(saved.size>3)' in method
assert 'window.__stsStartPdf(h,n)' in method
assert 'STSPdfBlob.finish(id)' in method
assert 'openBrowserBlobPdfFallback' in src
assert 'isPdfDownload(url, mt, contentDisposition)' in src
assert 'versionCode 117' in (Path(__file__).resolve().parents[1]/'app/build.gradle').read_text()
with tempfile.TemporaryDirectory() as d:
    Path(d,'CheckHook.java').write_text('''import java.nio.file.*;\nclass CheckHook {\nstatic final int MAX_PDF_BLOB_BYTES=64*1024*1024;\nstatic class WebView {void evaluateJavascript(String s,Object ignored){try{Files.writeString(Path.of("''' + str(Path(d,'hook.js')) + '''"),s);}catch(Exception e){throw new RuntimeException(e);}}}\n''' + method+'''
public static void main(String[] a){new CheckHook().injectPdfHook(new WebView());}\n}''')
    r=subprocess.run(['javac','-d',d,str(Path(d,'CheckHook.java'))],capture_output=True,text=True)
    assert r.returncode==0, r.stderr[:2000]
    r=subprocess.run(['java','-cp',d,'CheckHook'],capture_output=True,text=True)
    assert r.returncode==0,r.stderr
    hook=Path(d,'hook.js')
    r=subprocess.run(['node','--check',str(hook)],capture_output=True,text=True)
    assert r.returncode==0, r.stderr[:1600]
    script=r'''const fs=require('fs'),vm=require('vm');
const src=fs.readFileSync(process.argv[2],'utf8');
const written=[],native=new Map();let listener=null,counter=0;
const URLMock={createObjectURL(b){return 'blob:sts/'+(++counter);},revokeObjectURL(){}};
const bridge={begin(id,name){native.set(id,{name,buf:''});return true;},chunk(id,s){native.get(id).buf+=s;},finish(id){let v=native.get(id);let pdf=Buffer.from(v.buf,'base64');if(pdf.slice(0,5).toString()!=='%PDF-')throw Error('Bad PDF');written.push({name:v.name,data:pdf});native.delete(id);},fail(id){throw Error('blob transfer failed: '+id)}};
const doc={addEventListener(name,fn){if(name==='click')listener=fn;},querySelectorAll(){return []}};
const sandbox={window:{},URL:URLMock,document:doc,STSPdfBlob:bridge,STSPdf:{openPdf(){}},Blob,Promise,Date,Math,fetch:async()=>{throw Error('revoked')},FileReader:class{readAsDataURL(b){b.arrayBuffer().then(a=>{this.result='data:application/pdf;base64,'+Buffer.from(a).toString('base64');this.onload()}).catch(x=>this.onerror(x));}}};
vm.runInNewContext(src,sandbox);
const blob=new Blob([Buffer.from('%PDF-1.7\nTest PDF\n')],{type:'application/pdf'});
const url=URLMock.createObjectURL(blob);URLMock.revokeObjectURL(url);
let cancelled=false;
listener({target:{closest(){return {href:url,getAttribute(k){if(k==='download')return 'eadhaar.pdf';return '';}}}},preventDefault(){cancelled=true},stopPropagation(){}});
setImmediate(()=>setImmediate(()=>{if(!cancelled||written.length!==1||written[0].name!=='eadhaar.pdf')process.exitCode=1;else console.log('PASS captured generated PDF after blob URL revocation');}));
'''
    Path(d,'check.cjs').write_text(script)
    r=subprocess.run(['node',str(Path(d,'check.cjs')),str(hook)],capture_output=True,text=True)
    assert r.returncode==0, r.stderr+' '+r.stdout
    print(r.stdout.strip())
print('PASS Java source string, browser JavaScript syntax, revoked-blob handling')
