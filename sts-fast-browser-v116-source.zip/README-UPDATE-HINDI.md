STS Fast Browser v1.0.116 — UIDAI और अन्य वेबसाइटों से बनने वाली PDF का डाउनलोड सुधार
Version code: 117, package com.sts.fastbrowser

मुख्य बदलाव केवल MainActivity.java के PDF download bridge में हैं:
- वेबसाइट में बना PDF blob उसी WebView से तुरंत पकड़ना; लिंक revoke होने के बाद भी अस्थायी Blob की bytes उपलब्ध रहें।
- PDF <a download> क्लिक को ब्राउज़र में ही संभालना; Java/UI thread की देरी से bytes खोने की समस्या को कम करना।
- PDF filename Content-Disposition में हो लेकिन MIME application/octet-stream आए, तब भी PDF viewer route।
- डेटा को ऐप के निजी cache में सीमित 64MB से अधिक न लिखना; मूल PDF और वेबसाइट login सुरक्षित रखना।
- असफल Blob transfer बनाम गलत PDF bytes के अलग संदेश।
- मौजूदा HTTP URL, data PDF और पुराने download logic fallback मौजूद।

बिना बदलाव: पाँच बटन Text, Replace, Highlighter, Undo, Redo, Save/Save As 3-dot में, और बाकी browser features।
LOCKED BASE v1.0.105 सुरक्षित। पिछले signed v1.0.115 को नहीं बदला गया।

परीक्षण: local static tests और offline JS generated Blob/PDF revocation simulation पास।
यह UIDAI की असली, निजी Aadhaar PDF या OTP download का प्रमाणित end-to-end टेस्ट नहीं है।
अपना आधार/पासवर्ड उपयोगकर्ता से माँगे बिना सुधार किया गया है।
