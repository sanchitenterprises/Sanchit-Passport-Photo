package com.sts.fastbrowser;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.PictureInPictureParams;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentUris;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.pdf.PdfDocument;
import android.database.Cursor;
import android.net.Uri;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.util.Size;
import android.util.LruCache;
import android.util.Rational;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebViewDatabase;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.URL;
import java.net.Socket;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Date;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.text.SimpleDateFormat;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class MainActivity extends android.app.Activity {
    private static final int REQ_LOCATION = 812;
    private static final int REQ_DOCUMENT_ACCESS = 813;
    private static final int REQ_PHONE_DATA_DELETE = 814;
    private static final int REQ_EXPORT_SETTINGS = 815;
    private static final int REQ_IMPORT_SETTINGS = 816;
    private static final int REQ_FILE_CHOOSER = 817;
    private static final String PREFS = "sts_fast_browser_prefs";
    private static final String KEY_STARTUP_PENDING = "startup_pending";
    private static final String KEY_LAST_GOOD_CONFIG = "last_good_config";
    private static final String KEY_LAST_HEALTH_WEBVIEW = "last_health_webview";
    private static final String KEY_LAST_HEALTH_TIME = "last_health_time";
    private static final String KEY_SITES = "sites_json";
    private static final String KEY_SITES_D1 = "sites_d1_json";
    private static final String KEY_SITES_D2 = "sites_d2_json";
    private static final String KEY_SITES_MIGRATED = "sites_split_migrated";
    private static final String KEY_ADBLOCK = "adblock";
    private static final String KEY_HARD_ADBLOCK = "hard_adblock";
    private static final String KEY_SLOT1_NAME = "slot1_name";
    private static final String KEY_SLOT1_URL = "slot1_url";
    private static final String KEY_SLOT2_NAME = "slot2_name";
    private static final String KEY_SLOT2_URL = "slot2_url";
    private static final String GOOGLE_NAME = "Google";
    private static final String GOOGLE_URL = "https://www.google.com/";

    private SharedPreferences prefs;
    private final List<Site> sitesD1 = new ArrayList<>();
    private final List<Site> sitesD2 = new ArrayList<>();
    private LinearLayout slot1Container;
    private LinearLayout slot2Container;
    private TextView slot1Button;
    private EditText slot2Button;
    private ImageView slot1HomeIcon;
    private ImageView slot1RefreshIcon;
    private android.window.OnBackInvokedCallback systemBackCallback;
    private boolean phoneBackPending;
    private boolean clearD1WebsiteHistory;
    private boolean addressEdited;
    private boolean manualD2Address;
    private String manualAddressShown = "";

    private ImageView menuButton;
    private AlertDialog manageSitesDialog;
    private BrowserVideoController videoController;
    private LinearLayout browserTopBar;
    private FrameLayout webStage;
    private FrameLayout loadingOverlay;
    private ImageView loadingLogo;
    private android.animation.AnimatorSet loadingLogoAnimator;
    private boolean webView1Loading = false;
    private boolean webView2Loading = false;
    private WebView webView1;
    private WebView webView2;
    private final java.util.WeakHashMap<WebView, Float> browserPageZoom = new java.util.WeakHashMap<>();
    private final java.util.WeakHashMap<WebView, float[]> browserLastTouch = new java.util.WeakHashMap<>();
    // Active-slot alias. D1 and D2 themselves stay alive independently.
    private WebView webView;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private WebView pendingGeoView;
    private AlertDialog geoConsentDialog;
    private boolean locationPermissionInFlight;
    private ValueCallback<Uri[]> pendingFileChooser;
    private final java.util.WeakHashMap<WebView, DownloadHint> downloadHints = new java.util.WeakHashMap<>();
    private boolean adBlockEnabled = true;
    private boolean hardAdBlockEnabled = true;
    private int activeSlot = 1;
    private volatile boolean webView1YouTube = false;
    private volatile boolean webView2YouTube = false;
    private String slot1Name = GOOGLE_NAME;
    private String slot1Url = GOOGLE_URL;
    private String slot2Name = GOOGLE_NAME;
    private String slot2Url = GOOGLE_URL;
    private String d2HttpsUpgradeSource = null;
    private String d2HttpsUpgradeTarget = null;
    private boolean d2AllowHttpOnce = false;
    private volatile boolean slot1DocumentsHome = true;
    private volatile String phoneDataMode = "All Data";
    private volatile boolean documentAccessRequested = false;
    private volatile int documentsLoadGeneration = 0;
    private static final int PHONE_DATA_BATCH_SIZE = 350;
    private volatile List<DocumentEntry> phoneDataSnapshot = new ArrayList<>();
    private volatile int phoneDataSnapshotGeneration = -1;
    private volatile String phoneDataSnapshotMode = "";
    private final LruCache<String, byte[]> phoneDataThumbCache = new LruCache<String, byte[]>(12 * 1024 * 1024) {
        @Override
        protected int sizeOf(String key, byte[] value) {
            return value == null ? 0 : value.length;
        }
    };

    private final String[] blockedHosts = new String[] {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.", "adsystem.com", "adnxs.com", "adsrvr.org",
            "taboola.com", "outbrain.com", "criteo.com", "criteo.net",
            "scorecardresearch.com", "zedo.com", "pubmatic.com", "rubiconproject.com",
            "openx.net", "moatads.com", "amazon-adsystem.com", "serving-sys.com",
            "smartadserver.com", "adform.net", "quantserve.com", "yieldmo.com",
            "casalemedia.com", "lijit.com", "smaato.net", "advertising.com",
            "media.net", "revcontent.com", "mgid.com", "exoclick.com",
            "propellerads.com", "popads.net", "popcash.net", "onclickads.net",
            "hilltopads.net", "juicyads.com", "trafficjunky.net", "adsafeprotected.com"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 33) {
            systemBackCallback = this::onBackPressed;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, systemBackCallback);
        }
        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#355C62"));
        w.setNavigationBarColor(Color.parseColor("#F2F5F4"));

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        // If the previous launch died before startup completed, restore only the last
        // known-good app configuration. User files and WebView data are never wiped.
        boolean previousStartupIncomplete = prefs.getBoolean(KEY_STARTUP_PENDING, false);
        if (previousStartupIncomplete) {
            String lastGood = prefs.getString(KEY_LAST_GOOD_CONFIG, "");
            if (!TextUtils.isEmpty(lastGood)) {
                applyBackupJsonToPrefs(lastGood);
            }
        }
        prefs.edit().putBoolean(KEY_STARTUP_PENDING, true).commit();

        try {
            adBlockEnabled = prefs.getBoolean(KEY_ADBLOCK, true);
            hardAdBlockEnabled = prefs.getBoolean(KEY_HARD_ADBLOCK, true);
            loadSites();
            loadSlots();
            setContentView(buildUi());
            videoController = new BrowserVideoController(this, () -> webView, browserTopBar);
            configureWebView(webView1);
            configureWebView(webView2);
            showWebView(1);
            updateSlotLabels();
            if (!handleBrowserIntent(getIntent())) {
                loadInitialPage();
            }
            markStartupHealthy();
            runSilentHealthCheck();
        } catch (Exception | LinkageError startupError) {
            showSafeStartupScreen();
        }
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout top = new LinearLayout(this);
        browserTopBar = top;
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(4), dp(3), dp(4), dp(3));
        GradientDrawable topBg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.parseColor("#D9F0EE"), Color.parseColor("#E3EAF4"), Color.parseColor("#EEE8F4")}
        );
        top.setBackground(topBg);
        root.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        slot1Container = makeSlotContainer(Color.parseColor("#BFE3DF"));
        slot2Container = makeSlotContainer(Color.parseColor("#CAD7E7"));

        slot1HomeIcon = makeIconButton(R.drawable.ic_home);
        slot1Button = makeSlotLabel("Phone Data");
        android.graphics.drawable.Drawable arrow = getDrawable(R.drawable.ic_dropdown);
        arrow.setBounds(0, 0, dp(12), dp(12));
        slot1Button.setCompoundDrawables(null, null, arrow, null);
        slot1Button.setCompoundDrawablePadding(dp(3));
        slot1Button.setEllipsize(TextUtils.TruncateAt.END);
        slot1RefreshIcon = makeIconButton(R.drawable.ic_refresh);
        slot2Button = makeD2AddressBar();
        slot1Container.addView(slot1Button, new LinearLayout.LayoutParams(-1, -1));
        slot2Container.addView(slot2Button, new LinearLayout.LayoutParams(-1, -1));
        menuButton = makeIconButton(R.drawable.ic_more);
        menuButton.setBackground(makeRipple(Color.TRANSPARENT));
        menuButton.setContentDescription("Menu");
        top.addView(slot1HomeIcon, new LinearLayout.LayoutParams(dp(40), -1));
        LinearLayout.LayoutParams dropdownParams = new LinearLayout.LayoutParams(0, -1, 0.85f);
        dropdownParams.setMargins(0, 0, dp(3), 0);
        top.addView(slot1Container, dropdownParams);
        LinearLayout.LayoutParams addressParams = new LinearLayout.LayoutParams(0, -1, 1.15f);
        addressParams.setMargins(0, 0, dp(3), 0);
        top.addView(slot2Container, addressParams);
        top.addView(slot1RefreshIcon, new LinearLayout.LayoutParams(dp(40), -1));
        top.addView(menuButton, new LinearLayout.LayoutParams(dp(40), -1));
        root.setFocusableInTouchMode(true);

        webStage = new FrameLayout(this);
        webView1 = new WebView(this);
        webView2 = new WebView(this);
        webView1.setBackgroundColor(Color.WHITE);
        webView2.setBackgroundColor(Color.WHITE);
        webStage.addView(webView1, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ));
        webStage.addView(webView2, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ));

        loadingOverlay = new FrameLayout(this);
        loadingOverlay.setBackgroundColor(Color.argb(235, 255, 255, 255));
        loadingOverlay.setClickable(true);
        loadingOverlay.setFocusable(false);
        loadingOverlay.setVisibility(View.GONE);
        loadingOverlay.setAlpha(0f);

        loadingLogo = new ImageView(this);
        loadingLogo.setImageResource(R.drawable.sfb_app_icon_v2);
        loadingLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        loadingLogo.setContentDescription("Loading");
        FrameLayout.LayoutParams loadingLogoLp = new FrameLayout.LayoutParams(dp(92), dp(92));
        loadingLogoLp.gravity = Gravity.CENTER;
        loadingOverlay.addView(loadingLogo, loadingLogoLp);

        webStage.addView(loadingOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ));

        webView2.setVisibility(View.GONE);
        webView = webView1;
        root.addView(webStage, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        slot1Button.setOnClickListener(v -> showSitePopup(slot1Container, 1));
        slot2Button.setOnEditorActionListener((v, actionId, event) -> {
            navigateD2Address(v.getText().toString());
            return true;
        });
        slot2Button.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                slot2Button.post(() -> {
                    if (slot2Button.hasFocus()) slot2Button.selectAll();
                });
            } else {
                addressEdited = false;
                syncD2AddressBar(null);
            }
            updateAddressAction();
        });
        slot2Button.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence text, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence text, int start, int before, int count) {
                if (slot2Button.hasFocus()) addressEdited = true;
                updateAddressAction();
            }
            @Override public void afterTextChanged(android.text.Editable text) { }
        });
        slot1HomeIcon.setContentDescription("Home / Phone Data");
        slot1RefreshIcon.setContentDescription("Refresh current page");
        slot2Button.setContentDescription("Type or paste a website address or search");
        slot1HomeIcon.setOnClickListener(v -> {
            finishAddressEditing();
            showDocumentsHome();
        });
        slot1RefreshIcon.setOnClickListener(v -> performAddressAction());
        menuButton.setOnClickListener(this::showMainMenu);
        applyPressAnimation(slot1Button);
        applyPressAnimation(slot1HomeIcon);
        applyPressAnimation(slot1RefreshIcon);
        applyPressAnimation(menuButton);

        return root;
    }

    private LinearLayout makeSlotContainer(int baseColor) {
        LinearLayout slot = new LinearLayout(this);
        slot.setOrientation(LinearLayout.HORIZONTAL);
        slot.setGravity(Gravity.CENTER_VERTICAL);
        slot.setPadding(dp(1), 0, dp(1), 0);
        slot.setBackground(makeRipple(Color.TRANSPARENT));
        return slot;
    }

    private TextView makeSlotLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#162326"));
        tv.setTextSize(13);
        tv.setGravity(Gravity.CENTER);
        tv.setSingleLine(true);
        tv.setPadding(dp(2), 0, dp(2), 0);
        tv.setClickable(true);
        tv.setFocusable(true);
        return tv;
    }

    private EditText makeD2AddressBar() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(Color.parseColor("#162326"));
        input.setHintTextColor(Color.parseColor("#68777A"));
        input.setHint("Search or type website");
        input.setTextSize(12);
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.setPadding(dp(7), 0, dp(3), 0);
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_GO);
        input.setSelectAllOnFocus(false);
        input.setLongClickable(true);
        input.setTextIsSelectable(true);

        input.setCompoundDrawablePadding(dp(2));
        return input;
    }

    private ImageView makeIconButton(int drawableRes) {
        ImageView iv = new ImageView(this);
        iv.setImageResource(drawableRes);
        iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        iv.setPadding(dp(8), dp(8), dp(8), dp(8));
        iv.setClickable(true);
        iv.setFocusable(true);
        iv.setBackground(makeRipple(Color.TRANSPARENT));
        return iv;
    }

    private TextView makeTopButton(String text, int baseColor) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#162326"));
        tv.setTextSize(14);
        tv.setGravity(Gravity.CENTER);
        tv.setSingleLine(true);
        tv.setPadding(dp(8), 0, dp(8), 0);
        tv.setBackground(makeRipple(baseColor));
        tv.setClickable(true);
        tv.setFocusable(true);
        return tv;
    }

    private RippleDrawable makeRipple(int baseColor) {
        GradientDrawable base = new GradientDrawable();
        base.setColor(baseColor);
        base.setCornerRadius(dp(10));
        if (Color.alpha(baseColor) != 0) base.setStroke(dp(1), darken(baseColor, 0.12f));
        ColorStateList ripple = ColorStateList.valueOf(withAlpha(Color.parseColor("#203B40"), 48));
        return new RippleDrawable(ripple, base, null);
    }

    private void applyPressAnimation(View v) {
        v.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(70).start();
            } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(110).start();
            }
            return false;
        });
    }

    private void installReliablePinchZoomOut(WebView targetWebView) {
        // This is browser-page zoom only. PDF/Image viewers are separate activities.
        //
        // Native WebView pinch-out can stop at its minimum/overview scale. For the user's
        // "make the whole website smaller so the right side becomes visible" gesture,
        // apply a Chromium CSS page zoom below 100%. While CSS zoom is below 100%,
        // the reverse two-finger gesture restores it toward 100%. At 100%, normal
        // WebView zoom-in remains untouched.
        browserPageZoom.put(targetWebView, 1.0f);
        final boolean[] customGesture = {false};
        final boolean[] multiTouch = {false};

        ScaleGestureDetector detector = new ScaleGestureDetector(this,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    @Override
                    public boolean onScaleBegin(ScaleGestureDetector detector) {
                        return true;
                    }

                    @Override
                    public boolean onScale(ScaleGestureDetector detector) {
                        float factor = detector.getScaleFactor();
                        if (Float.isNaN(factor) || Float.isInfinite(factor)) return false;

                        float current = browserPageZoom.containsKey(targetWebView) ? browserPageZoom.get(targetWebView) : 1.0f;

                        // At normal 100% zoom, keep pinch-to-zoom-in completely native.
                        // Switch to custom page scaling only when the fingers move inward
                        // (zoom out), or while restoring an already zoomed-out page.
                        if (!customGesture[0] && current >= 0.999f && factor >= 0.995f) {
                            return false;
                        }

                        customGesture[0] = true;

                        float next = current * factor;
                        next = Math.max(0.25f, Math.min(1.0f, next));
                        if (Math.abs(next - current) < 0.001f) return true;

                        browserPageZoom.put(targetWebView, next);
                        applyBrowserPageZoom(targetWebView, next);
                        return true;
                    }
                });

        targetWebView.setOnTouchListener((view, event) -> {
            int action = event.getActionMasked();

            if (action == MotionEvent.ACTION_DOWN) {
                customGesture[0] = false;
                multiTouch[0] = false;
                browserLastTouch.put(targetWebView, new float[]{event.getX(), event.getY()});
                captureDownloadHintAtPoint(targetWebView, event.getX(), event.getY());
            }

            if (event.getPointerCount() >= 2) multiTouch[0] = true;

            boolean wasCustom = customGesture[0];
            if (event.getPointerCount() >= 2 || multiTouch[0] || customGesture[0]) {
                detector.onTouchEvent(event);
            }

            // Cancel WebView's native pinch only after this gesture has actually
            // become a custom zoom-out gesture. Single-finger touch stays untouched.
            if (!wasCustom && customGesture[0]) {
                MotionEvent cancel = MotionEvent.obtain(event);
                cancel.setAction(MotionEvent.ACTION_CANCEL);
                try {
                    targetWebView.onTouchEvent(cancel);
                } finally {
                    cancel.recycle();
                }
            }

            boolean consume = customGesture[0];

            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                customGesture[0] = false;
                multiTouch[0] = false;
            } else if (action == MotionEvent.ACTION_POINTER_UP && event.getPointerCount() <= 2) {
                customGesture[0] = false;
                multiTouch[0] = false;
            }

            return consume;
        });

    }

    private void applyBrowserPageZoom(WebView view, float scale) {
        if (view == null) return;
        final float safe = Math.max(0.25f, Math.min(1.0f, scale));
        String js =
                "(function(){" +
                "try{" +
                "var z=" + String.format(Locale.US, "%.4f", safe) + ";" +
                "var d=document.documentElement;" +
                "if(d){" +
                "d.style.setProperty('zoom',String(z),'important');" +
                "d.style.setProperty('transform-origin','0 0','important');" +
                "}" +
                "}catch(e){}" +
                "})();";
        try { view.evaluateJavascript(js, null); } catch (Exception ignored) {}
    }

    private void installImageLongPressDownload(WebView targetWebView) {
        targetWebView.setOnLongClickListener(v -> {
            WebView.HitTestResult hit = targetWebView.getHitTestResult();
            int type = hit == null ? WebView.HitTestResult.UNKNOWN_TYPE : hit.getType();
            boolean imageHit = type == WebView.HitTestResult.IMAGE_TYPE ||
                    type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE;
            if (!imageHit) return false;

            float[] point = browserLastTouch.get(targetWebView);
            float x = point == null ? targetWebView.getWidth() / 2f : point[0];
            float y = point == null ? targetWebView.getHeight() / 2f : point[1];
            String fallbackUrl = hit == null ? "" : hit.getExtra();
            resolveLongPressedImage(targetWebView, x, y, fallbackUrl);
            return true;
        });
    }

    private void resolveLongPressedImage(WebView view, float rawX, float rawY, String fallbackUrl) {
        if (view == null) return;
        String x = String.format(Locale.US, "%.2f", rawX);
        String y = String.format(Locale.US, "%.2f", rawY);
        String js =
                "(function(){try{" +
                "var d=(window.devicePixelRatio||1),x=" + x + "/d,y=" + y + "/d;" +
                "var e=document.elementFromPoint(x,y),img=e;" +
                "if(img&&img.tagName&&String(img.tagName).toLowerCase()!=='img'){" +
                "img=img.closest?img.closest('img'):null;}" +
                "if(!img){var p=e,c=0;while(p&&c<5&&!img){if(p.querySelector)img=p.querySelector('img');p=p.parentElement;c++;}}" +
                "if(!img)return JSON.stringify({urls:[],name:''});" +
                "var urls=[],seen={};function add(u){try{u=String(u||'').trim();if(!u||u.indexOf('data:')===0)return;" +
                "if(u.indexOf('//')===0)u=location.protocol+u;else if(u.indexOf('/')===0)u=new URL(u,location.href).href;" +
                "if(!seen[u]){seen[u]=1;urls.push(u);}}catch(z){}}" +
                "function attr(node,k){try{return node&&node.getAttribute?node.getAttribute(k):'';}catch(z){return '';}}" +
                "var p=img,c=0;while(p&&c<8){" +
                "['data-iurl','data-original','data-original-src','data-full','data-full-src','data-highres','data-hi-res','data-src','data-image','data-url'].forEach(function(k){add(attr(p,k));});" +
                "var h=attr(p,'href')||(p.href||'');if(h){try{var hu=new URL(h,location.href);" +
                "['imgurl','media','image_url','image','src','url'].forEach(function(k){var q=hu.searchParams.get(k);if(q)add(q);});" +
                "if(/\\.(jpg|jpeg|png|webp|gif|bmp|avif|heic|heif)(?:$|[?#])/i.test(hu.href))add(hu.href);}catch(z){}}" +
                "p=p.parentElement;c++;}" +
                "var ss=attr(img,'srcset');if(ss){var best='';var score=-1;ss.split(',').forEach(function(part){" +
                "var s=part.trim().split(/\\s+/),u=s[0],q=s[1]||'1x',v=parseFloat(q)||1;" +
                "if(/w$/i.test(q))v*=1000;else if(/x$/i.test(q))v*=100;if(v>score){score=v;best=u;}});add(best);}" +
                "add(img.currentSrc);add(attr(img,'src'));add(img.src);" +
                "var name=attr(img,'alt')||attr(img,'title')||'';" +
                "return JSON.stringify({urls:urls,name:String(name||'').trim()});" +
                "}catch(e){return JSON.stringify({urls:[],name:''});}})()";

        try {
            view.evaluateJavascript(js, value -> {
                ArrayList<String> urls = new ArrayList<>();
                String label = "";
                try {
                    if (!TextUtils.isEmpty(value) && !"null".equals(value)) {
                        JSONArray wrap = new JSONArray("[" + value + "]");
                        String raw = wrap.optString(0, "");
                        JSONObject obj = new JSONObject(raw);
                        JSONArray arr = obj.optJSONArray("urls");
                        if (arr != null) {
                            for (int i = 0; i < arr.length(); i++) {
                                String u = arr.optString(i, "");
                                if (!TextUtils.isEmpty(u) && !urls.contains(u)) urls.add(u);
                            }
                        }
                        label = obj.optString("name", "");
                    }
                } catch (Exception ignored) {}

                if (!TextUtils.isEmpty(fallbackUrl) && !urls.contains(fallbackUrl)) {
                    urls.add(fallbackUrl);
                }
                if (urls.isEmpty()) {
                    Toast.makeText(this, "Original image link नहीं मिला", Toast.LENGTH_SHORT).show();
                    return;
                }
                showImageLongPressMenu(view, urls, label);
            });
        } catch (Exception e) {
            if (!TextUtils.isEmpty(fallbackUrl)) {
                ArrayList<String> urls = new ArrayList<>();
                urls.add(fallbackUrl);
                showImageLongPressMenu(view, urls, "");
            }
        }
    }

    private void showImageLongPressMenu(WebView sourceView, List<String> urls, String label) {
        if (isFinishing() || urls == null || urls.isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle(TextUtils.isEmpty(label) ? "Image" : label)
                .setItems(new String[]{"Download"}, (dialog, which) ->
                        showImageFormatMenu(sourceView, urls, label))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showImageFormatMenu(WebView sourceView, List<String> urls, String label) {
        new AlertDialog.Builder(this)
                .setTitle("Download image")
                .setItems(new String[]{"JPG", "PNG", "PDF"}, (dialog, which) -> {
                    String format = which == 0 ? "JPG" : (which == 1 ? "PNG" : "PDF");
                    downloadOriginalImage(sourceView, urls, label, format);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private File fetchOriginalImageCandidate(String url, String userAgent, String cookie,
                                             String referer, DownloadResolvedMeta meta) throws Exception {
        File file = downloadToTemporaryFile(url, userAgent, cookie, referer, meta);
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            file.delete();
            throw new Exception("Not a decodable image");
        }
        return file;
    }

    private String imageBaseName(String headerName, String urlName, String label) {
        String name = sanitizeDownloadName(headerName);
        if (TextUtils.isEmpty(name) || isGenericDownloadName(name)) name = sanitizeDownloadName(urlName);
        if (TextUtils.isEmpty(name) || isGenericDownloadName(name)) name = sanitizeDownloadName(label);
        if (TextUtils.isEmpty(name)) {
            name = "image-" + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
        }
        int dot = name.lastIndexOf('.');
        if (dot > 0) name = name.substring(0, dot);
        name = name.replaceAll("(?i)\\b(download|image|photo|jpg|jpeg|png|pdf)\\b$", "").trim();
        if (TextUtils.isEmpty(name)) name = "image-" +
                new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
        return sanitizeDownloadName(name);
    }

    private void downloadOriginalImage(WebView sourceView, List<String> candidates,
                                       String label, String format) {
        if (candidates == null || candidates.isEmpty()) return;

        String ua = null;
        String referer = null;
        try {
            ua = sourceView == null ? null : sourceView.getSettings().getUserAgentString();
            referer = sourceView == null ? null : sourceView.getUrl();
        } catch (Exception ignored) {}
        final String finalUa = ua;
        final String finalReferer = referer;

        Toast.makeText(this, "Original image download शुरू...", Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            File source = null;
            File generated = null;
            try {
                DownloadResolvedMeta meta = null;
                String usedUrl = null;

                for (String candidate : candidates) {
                    if (TextUtils.isEmpty(candidate) ||
                            !(candidate.startsWith("http://") || candidate.startsWith("https://"))) continue;
                    String cookie = null;
                    try { cookie = CookieManager.getInstance().getCookie(candidate); } catch (Exception ignored) {}
                    try {
                        DownloadResolvedMeta attemptMeta = new DownloadResolvedMeta();
                        source = fetchOriginalImageCandidate(candidate, finalUa, cookie, finalReferer, attemptMeta);
                        meta = attemptMeta;
                        usedUrl = candidate;
                        break;
                    } catch (Exception ignored) {
                        if (source != null) source.delete();
                        source = null;
                    }
                }

                if (source == null || meta == null) throw new Exception("Original image unavailable");

                String actualExt = detectActualExtension(source, meta.contentType);
                String urlName = filenameFromUrl(meta.finalUrl);
                if (TextUtils.isEmpty(urlName)) urlName = filenameFromUrl(usedUrl);
                String base = imageBaseName(meta.headerName, urlName, label);

                String outExt = "JPG".equals(format) ? ".jpg" : ("PNG".equals(format) ? ".png" : ".pdf");
                String outMime = "JPG".equals(format) ? "image/jpeg" :
                        ("PNG".equals(format) ? "image/png" : "application/pdf");
                String outName = base + outExt;

                // If source already matches the requested raster format, copy original bytes unchanged.
                if (("JPG".equals(format) && (".jpg".equalsIgnoreCase(actualExt) || ".jpeg".equalsIgnoreCase(actualExt))) ||
                        ("PNG".equals(format) && ".png".equalsIgnoreCase(actualExt))) {
                    generated = source;
                    source = null;
                } else {
                    Bitmap bitmap = BitmapFactory.decodeFile(source.getAbsolutePath());
                    if (bitmap == null) throw new Exception("Image decode failed");

                    generated = File.createTempFile("sfb-image-", outExt, getCacheDir());
                    if ("JPG".equals(format)) {
                        Bitmap jpgBitmap = bitmap;
                        if (bitmap.hasAlpha()) {
                            jpgBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
                            Canvas canvas = new Canvas(jpgBitmap);
                            canvas.drawColor(Color.WHITE);
                            canvas.drawBitmap(bitmap, 0f, 0f, null);
                        }
                        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(generated))) {
                            if (!jpgBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out)) {
                                throw new Exception("JPEG encode failed");
                            }
                            out.flush();
                        }
                        if (jpgBitmap != bitmap) jpgBitmap.recycle();
                    } else if ("PNG".equals(format)) {
                        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(generated))) {
                            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                                throw new Exception("PNG encode failed");
                            }
                            out.flush();
                        }
                    } else {
                        PdfDocument pdf = new PdfDocument();
                        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(
                                Math.max(1, bitmap.getWidth()), Math.max(1, bitmap.getHeight()), 1).create();
                        PdfDocument.Page page = pdf.startPage(pageInfo);
                        page.getCanvas().drawBitmap(bitmap, 0f, 0f, null);
                        pdf.finishPage(page);
                        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(generated))) {
                            pdf.writeTo(out);
                            out.flush();
                        } finally {
                            pdf.close();
                        }
                    }
                    bitmap.recycle();
                }

                saveGeneratedDownloadFile(generated, outName, outMime);
                final String doneName = outName;
                runOnUiThread(() -> Toast.makeText(
                        this, "Downloaded: " + doneName, Toast.LENGTH_LONG).show());
            } catch (OutOfMemoryError oom) {
                runOnUiThread(() -> Toast.makeText(
                        this, "Image बहुत बड़ी है • full-resolution conversion के लिए memory कम है",
                        Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(
                        this, "Original image download नहीं हुआ", Toast.LENGTH_LONG).show());
            } finally {
                if (source != null) source.delete();
                if (generated != null) generated.delete();
            }
        }, "SFB-OriginalImage").start();
    }

    private Uri saveGeneratedDownloadFile(File source, String fileName, String mimeType) throws Exception {
        if (source == null || !source.exists()) throw new Exception("Generated file missing");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("Downloads insert failed");

            boolean ok = false;
            try (InputStream in = new BufferedInputStream(new FileInputStream(source));
                 OutputStream out = new BufferedOutputStream(getContentResolver().openOutputStream(uri, "w"))) {
                if (out == null) throw new Exception("Downloads output unavailable");
                byte[] buffer = new byte[64 * 1024];
                int read;
                while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                out.flush();
                ok = true;
            } finally {
                if (!ok) {
                    try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
                }
            }
            android.content.ContentValues ready = new android.content.ContentValues();
            ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContentResolver().update(uri, ready, null, null);
            return uri;
        }

        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Downloads folder unavailable");
        File target = new File(dir, fileName);
        if (target.exists()) {
            String ext = fileExtension(fileName);
            String base = fileName.substring(0, fileName.length() - ext.length());
            int i = 1;
            do {
                target = new File(dir, base + " (" + i++ + ")" + ext);
            } while (target.exists());
        }
        try (InputStream in = new BufferedInputStream(new FileInputStream(source));
             OutputStream out = new BufferedOutputStream(new FileOutputStream(target))) {
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            out.flush();
        }
        Intent scan = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        scan.setData(Uri.fromFile(target));
        sendBroadcast(scan);
        return Uri.fromFile(target);
    }

    private void configureWebView(WebView targetWebView) {
        WebSettings s = targetWebView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(true);
        // Website <input type="file"> selections are usually returned as content:// URIs.
        // Keep both file/content access explicitly enabled so WebView can consume the
        // selected item after Android's picker returns it.
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(targetWebView, true);

        installReliablePinchZoomOut(targetWebView);
        installImageLongPressDownload(targetWebView);

        targetWebView.addJavascriptInterface(new PdfBridge(targetWebView), "STSPdf");
        targetWebView.addJavascriptInterface(new PdfBlobBridge(targetWebView), "STSPdfBlob");
        targetWebView.addJavascriptInterface(new RdBridge(), "STSRD");
        targetWebView.addJavascriptInterface(new DownloadBridge(targetWebView), "STSDownload");
        if (targetWebView == webView1) {
            targetWebView.addJavascriptInterface(new DocumentsBridge(), "STSDocuments");
        }

        videoController.attach(targetWebView);
        targetWebView.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                videoController.showCustomView(view, callback);
            }
            @Override public void onHideCustomView() { videoController.exitFullscreen(); }
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                setBrowserLoading(view, newProgress < 100);
            }

            @Override
            public boolean onShowFileChooser(WebView webView,
                                             ValueCallback<Uri[]> filePathCallback,
                                             WebChromeClient.FileChooserParams fileChooserParams) {
                if (filePathCallback == null) return false;

                // A WebView file-input callback is single-use. Cancel any older unfinished
                // request first, then keep the new callback alive until Android returns.
                if (pendingFileChooser != null) {
                    try { pendingFileChooser.onReceiveValue(null); } catch (Exception ignored) {}
                }
                pendingFileChooser = filePathCallback;

                try {
                    Intent pick = buildWebsiteFilePickerIntent(fileChooserParams);
                    Intent chooser = Intent.createChooser(pick, "Select file");
                    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(chooser, REQ_FILE_CHOOSER);
                    return true;
                } catch (Exception first) {
                    try {
                        Intent fallback = buildWebsiteFilePickerIntent(null);
                        Intent chooser = Intent.createChooser(fallback, "Select file");
                        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivityForResult(chooser, REQ_FILE_CHOOSER);
                        return true;
                    } catch (Exception second) {
                        ValueCallback<Uri[]> callback = pendingFileChooser;
                        pendingFileChooser = null;
                        if (callback != null) {
                            try { callback.onReceiveValue(null); } catch (Exception ignored) {}
                        }
                        Toast.makeText(MainActivity.this, "File picker नहीं खुल पाया", Toast.LENGTH_SHORT).show();
                        return false;
                    }
                }
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                requestSiteLocation(targetWebView, origin, callback);
            }

            @Override
            public void onGeolocationPermissionsHidePrompt() {
                if (pendingGeoView == targetWebView) finishSiteLocation(false);
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, android.os.Message resultMsg) {
                WebView child = new WebView(MainActivity.this);
                WebSettings childSettings = child.getSettings();
                childSettings.setJavaScriptEnabled(true);
                childSettings.setDomStorageEnabled(true);
                CookieManager.getInstance().setAcceptCookie(true);
                CookieManager.getInstance().setAcceptThirdPartyCookies(child, true);

                child.addJavascriptInterface(new PdfBlobBridge(child), "STSPdfBlob");
                child.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
                    String mt = mimeType == null ? "" : mimeType.toLowerCase(Locale.ROOT);
                    if (isPdfDownload(url, mt, contentDisposition)) {
                        openPdfTask(url, guessPdfName(url, contentDisposition), child);
                    } else if (isOfficeCandidate(url, mt)) {
                        openOfficeTask(url, guessOfficeName(url, contentDisposition, mt));
                    } else {
                        handleBrowserDownload(url, userAgent, contentDisposition, mimeType, targetWebView);
                    }
                    // blob: URLs must be read in this same WebView before it is destroyed.
                    if (url == null || !url.startsWith("blob:")) child.destroy();
                });

                child.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView v, String url) { injectPdfHook(v); }
                    private boolean handled = false;

                    private boolean handle(String url) {
                        if (handled || url == null) return false;
                        try {
                            Uri popupUri = Uri.parse(url);
                            if ((adBlockEnabled && isBlocked(popupUri)) ||
                                    (hardAdBlockEnabled && isHardAdRequest(popupUri))) {
                                handled = true;
                                child.post(child::destroy);
                                return true;
                            }
                        } catch (Exception ignored) {}
                        if (isPdfCandidate(url, null)) {
                            handled = true;
                            openPdfTask(url, guessPdfName(url, null), child);
                            if (!url.startsWith("blob:")) child.post(child::destroy);
                            return true;
                        }
                        if (isOfficeCandidate(url, null)) {
                            handled = true;
                            openOfficeTask(url, guessOfficeName(url, null, null));
                            child.post(child::destroy);
                            return true;
                        }
                        return false;
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                        String url = request.getUrl().toString();
                        if (handle(url)) return true;
                        if (url.startsWith("http://") || url.startsWith("https://")) {
                            handled = true;
                            loadBrowserUrl(targetWebView, url);
                            child.post(child::destroy);
                            return true;
                        }
                        return true;
                    }

                    @Override
                    public void onPageStarted(WebView v, String url, android.graphics.Bitmap favicon) {
                        if (handle(url)) v.stopLoading();
                    }
                });

                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(child);
                resultMsg.sendToTarget();
                return true;
            }
        });
        targetWebView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            String mt = mimeType == null ? "" : mimeType.toLowerCase(Locale.ROOT);
            if (isPdfDownload(url, mt, contentDisposition)) {
                openPdfTask(url, guessPdfName(url, contentDisposition), targetWebView);
            } else if (isOfficeCandidate(url, mt)) {
                openOfficeTask(url, guessOfficeName(url, contentDisposition, mt));
            } else {
                handleBrowserDownload(url, userAgent, contentDisposition, mimeType, targetWebView);
            }
        });
        targetWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if(videoController != null)videoController.reset(view);
                if (pendingGeoView == view) finishSiteLocation(false);
                updateYouTubeState(view, url);
                if (view == webView2) syncD2AddressBar(url);
                browserPageZoom.put(view, 1.0f);
                applyBrowserPageZoom(view, 1.0f);
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    if (isPdfCandidate(uri.toString(), null)) {
                        openPdfTask(uri.toString(), guessPdfName(uri.toString(), null), view);
                        return true;
                    }
                    if (isOfficeCandidate(uri.toString(), null)) {
                        openOfficeTask(uri.toString(), guessOfficeName(uri.toString(), null, null));
                        return true;
                    }
                    if (view == webView2 && request.isForMainFrame() && "http".equals(scheme)) {
                        if (d2AllowHttpOnce) {
                            d2AllowHttpOnce = false;
                            d2HttpsUpgradeSource = null;
                            d2HttpsUpgradeTarget = null;
                            return false;
                        }
                        String httpUrl = uri.toString();
                        String httpsUrl = toHttpsUrl(httpUrl);
                        if (!TextUtils.isEmpty(httpsUrl)) {
                            d2HttpsUpgradeSource = httpUrl;
                            d2HttpsUpgradeTarget = httpsUrl;
                            view.loadUrl(httpsUrl);
                            return true;
                        }
                    }
                    return false;
                }
                return openExternal(uri.toString());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (videoController != null && !isPhoneDataUrl(url)) videoController.install(view);
                if (view == webView1 && slot1DocumentsHome && isPhoneDataUrl(url)) {
                    // Loading/result/category documents are application screens, not web history.
                    view.clearHistory();
                    setBrowserLoading(view, false);
                    return;
                }
                if (view == webView1 && clearD1WebsiteHistory && !isPhoneDataUrl(url)) {
                    view.clearHistory();
                    clearD1WebsiteHistory = false;
                }
                updateYouTubeState(view, url);
                if (view == webView2) {
                    syncD2AddressBar(url);
                    if (!TextUtils.isEmpty(d2HttpsUpgradeTarget) &&
                            url != null && url.equalsIgnoreCase(d2HttpsUpgradeTarget)) {
                        d2HttpsUpgradeSource = null;
                        d2HttpsUpgradeTarget = null;
                        d2AllowHttpOnce = false;
                    }
                }
                injectPdfHook(view);
                injectDownloadNameHook(view);
                injectBrowserCompatibility(view);
                if (adBlockEnabled) injectNormalAdCleanup(view);
                if (hardAdBlockEnabled) injectHardAdCleanup(view);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && request != null && request.isForMainFrame() &&
                        view == webView2 && retryOriginalHttpAfterHttpsFailure(view, request.getUrl().toString())) {
                    return;
                }
                if (request == null || request.isForMainFrame()) {
                    setBrowserLoading(view, false);
                }
                super.onReceivedError(view, request, error);
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                if (request != null && request.isForMainFrame() && view == webView2 &&
                        errorResponse != null && errorResponse.getStatusCode() >= 400 &&
                        retryOriginalHttpAfterHttpsFailure(view, request.getUrl().toString())) {
                    return;
                }
                if (request == null || request.isForMainFrame()) {
                    setBrowserLoading(view, false);
                }
                super.onReceivedHttpError(view, request, errorResponse);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri requestUri = request.getUrl();
                if ("sts.phone".equalsIgnoreCase(requestUri.getHost()) &&
                        "/thumb".equals(requestUri.getPath())) {
                    WebResourceResponse thumb = phoneDataThumbnailResponse(requestUri);
                    if (thumb != null) return thumb;
                }

                if (!request.isForMainFrame()) {
                    boolean blockNormal = adBlockEnabled && isBlocked(requestUri);
                    boolean blockHard = hardAdBlockEnabled && isHardAdRequest(requestUri);
                    if (blockNormal || blockHard) {
                        return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }
        });
    }

    private void injectBrowserCompatibility(WebView view) {
        String js =
                "(function(){" +
                "try{" +
                "var m=document.querySelector('meta[name=viewport]');" +
                "if(!m){m=document.createElement('meta');m.name='viewport';document.head&&document.head.appendChild(m);}" +
                "if(m){var ct=m.getAttribute('content')||'';" +
                "ct=ct.replace(/user-scalable\\s*=\\s*no/ig,'user-scalable=yes')" +
                ".replace(/maximum-scale\\s*=\\s*1(?:\\.0+)?/ig,'maximum-scale=5.0');" +
                "if(!/user-scalable\\s*=/i.test(ct))ct+=(ct?', ':'')+'user-scalable=yes';" +
                "if(!/maximum-scale\\s*=/i.test(ct))ct+=(ct?', ':'')+'maximum-scale=5.0';" +
                "m.setAttribute('content',ct);}" +
                "}catch(e){}" +
                "if(window.__stsRdBridgeInstalled)return;window.__stsRdBridgeInstalled=true;" +
                "function rd(u,method){try{var a=document.createElement('a');a.href=String(u||'');" +
                "var h=(a.hostname||'').toLowerCase(),p=parseInt(a.port||'80',10);" +
                "return (h==='127.0.0.1'||h==='localhost')&&p>=11100&&p<=11120;}catch(e){return false;}}" +
                "function callNative(method,url,body,ctype){var r=STSRD.request(String(method||'GET'),String(url||'')," +
                "body==null?'':String(body),String(ctype||''));return JSON.parse(r);}" +
                "var of=window.fetch?window.fetch.bind(window):null;" +
                "if(of){window.fetch=function(input,init){var u=(typeof input==='string')?input:(input&&input.url)||'';" +
                "var method=(init&&init.method)||(input&&input.method)||'GET';" +
                "if(!rd(u,method))return of(input,init);" +
                "return new Promise(function(resolve,reject){setTimeout(function(){try{" +
                "var body=init&&init.body!=null?init.body:'';var ct='';" +
                "try{ct=(init&&init.headers&&((init.headers['Content-Type'])||(init.headers['content-type'])))||'';}catch(x){}" +
                "var z=callNative(method,u,body,ct);if(!z||!z.ok){reject(new TypeError((z&&z.error)||'RD Service unavailable'));return;}" +
                "resolve(new Response(z.body||'',{status:z.status||200,statusText:z.statusText||'OK'," +
                "headers:{'Content-Type':z.contentType||'text/xml'}}));}catch(e){reject(e);}},0);});};}" +
                "var O=window.XMLHttpRequest;" +
                "if(O&&window.Proxy){window.XMLHttpRequest=function(){var x=new O();var s={rd:false,method:'GET',url:'',async:true," +
                "body:'',ctype:'',readyState:0,status:0,statusText:'',responseText:'',response:'',responseURL:''," +
                "handlers:{},listeners:{},headers:{}};" +
                "function fire(n){var ev={type:n,target:px,currentTarget:px};" +
                "try{if(typeof s.handlers['on'+n]==='function')s.handlers['on'+n].call(px,ev);}catch(e){}" +
                "var ls=s.listeners[n]||[];for(var i=0;i<ls.length;i++){try{ls[i].call(px,ev);}catch(e){}}}" +
                "function complete(z){if(z&&z.ok){s.status=z.status||200;s.statusText=z.statusText||'OK';s.responseText=z.body||'';" +
                "s.response=s.responseText;s.responseURL=s.url;s.readyState=4;s.headers={'content-type':z.contentType||'text/xml'};" +
                "fire('readystatechange');fire('load');fire('loadend');}else{s.status=0;s.readyState=4;" +
                "fire('readystatechange');fire('error');fire('loadend');}}" +
                "var px=new Proxy(x,{get:function(t,p){if(p==='open')return function(method,url,async,user,password){" +
                "s.method=String(method||'GET').toUpperCase();s.url=String(url||'');s.async=async!==false;s.rd=rd(s.url,s.method);" +
                "if(!s.rd)return t.open(method,url,async,user,password);s.readyState=1;fire('readystatechange');};" +
                "if(p==='send')return function(body){if(!s.rd)return t.send(body);s.body=body==null?'':String(body);" +
                "var run=function(){try{complete(callNative(s.method,s.url,s.body,s.ctype));}catch(e){complete({ok:false,error:String(e)});}};" +
                "if(s.async)setTimeout(run,0);else run();};" +
                "if(p==='setRequestHeader')return function(k,v){if(!s.rd)return t.setRequestHeader(k,v);s.headers[String(k).toLowerCase()]=String(v);" +
                "if(String(k).toLowerCase()==='content-type')s.ctype=String(v);};" +
                "if(p==='getResponseHeader')return function(k){if(!s.rd)return t.getResponseHeader(k);return s.headers[String(k).toLowerCase()]||null;};" +
                "if(p==='getAllResponseHeaders')return function(){if(!s.rd)return t.getAllResponseHeaders();return 'content-type: '+(s.headers['content-type']||'text/xml')+'\\r\\n';};" +
                "if(p==='addEventListener')return function(n,fn){if(!s.listeners[n])s.listeners[n]=[];s.listeners[n].push(fn);try{t.addEventListener(n,fn);}catch(e){}};" +
                "if(p==='removeEventListener')return function(n,fn){var a=s.listeners[n]||[];var q=a.indexOf(fn);if(q>=0)a.splice(q,1);try{t.removeEventListener(n,fn);}catch(e){}};" +
                "if(p==='abort')return function(){if(!s.rd)return t.abort();s.readyState=0;fire('abort');fire('loadend');};" +
                "if(/^on/.test(String(p)))return s.handlers[p];" +
                "if(s.rd&&(p==='readyState'||p==='status'||p==='statusText'||p==='responseText'||p==='response'||p==='responseURL'))return s[p];" +
                "var v=t[p];return typeof v==='function'?v.bind(t):v;}," +
                "set:function(t,p,v){if(/^on/.test(String(p))){s.handlers[p]=v;try{t[p]=v;}catch(e){}return true;}" +
                "if(s.rd&&(p==='responseType'||p==='timeout'||p==='withCredentials')){s[p]=v;return true;}try{t[p]=v;}catch(e){}return true;}});" +
                "return px;};window.XMLHttpRequest.prototype=O.prototype;}" +
                "})();";
        try { view.evaluateJavascript(js, null); } catch (Exception ignored) {}
    }

    private class RdBridge {
        @JavascriptInterface
        public String request(String method, String url, String body, String contentType) {
            JSONObject result = new JSONObject();
            try {
                Uri uri = Uri.parse(url);
                String host = uri.getHost();
                int port = uri.getPort();
                if (host == null ||
                        !(host.equalsIgnoreCase("127.0.0.1") || host.equalsIgnoreCase("localhost")) ||
                        port < 11100 || port > 11120) {
                    result.put("ok", false);
                    result.put("error", "Blocked non-RD address");
                    return result.toString();
                }

                String verb = method == null ? "GET" : method.trim().toUpperCase(Locale.ROOT);
                if (verb.isEmpty()) verb = "GET";
                String target;
                if ("RDSERVICE".equals(verb) || "RDERVICE".equals(verb)) {
                    target = "*";
                } else {
                    target = uri.getEncodedPath();
                    if (target == null || target.isEmpty()) target = "/";
                    if (uri.getEncodedQuery() != null) target += "?" + uri.getEncodedQuery();
                }

                byte[] payload = body == null ? new byte[0] : body.getBytes(StandardCharsets.UTF_8);
                String ct = (contentType == null || contentType.trim().isEmpty()) ? "text/xml" : contentType.trim();

                try (Socket socket = new Socket()) {
                    socket.connect(new InetSocketAddress("127.0.0.1", port), 2500);
                    socket.setSoTimeout(30000);

                    OutputStream out = socket.getOutputStream();
                    StringBuilder req = new StringBuilder();
                    req.append(verb).append(" ").append(target).append(" HTTP/1.1\r\n");
                    req.append("Host: 127.0.0.1:").append(port).append("\r\n");
                    req.append("Connection: close\r\n");
                    req.append("Accept: text/xml, application/xml, */*\r\n");
                    if ("RDSERVICE".equals(verb) || "RDERVICE".equals(verb)) {
                        req.append("EXT: STS Fast Browser\r\n");
                    }
                    if (payload.length > 0 || "POST".equals(verb)) {
                        req.append("Content-Type: ").append(ct).append("\r\n");
                        req.append("Content-Length: ").append(payload.length).append("\r\n");
                    }
                    req.append("\r\n");
                    out.write(req.toString().getBytes(StandardCharsets.ISO_8859_1));
                    if (payload.length > 0) out.write(payload);
                    out.flush();

                    InputStream in = socket.getInputStream();
                    ByteArrayOutputStream all = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) != -1) all.write(buf, 0, n);
                    byte[] raw = all.toByteArray();

                    int split = headerEnd(raw);
                    if (split < 0) throw new IllegalStateException("Invalid RD response");
                    String headers = new String(raw, 0, split, StandardCharsets.ISO_8859_1);
                    byte[] responseBody = Arrays.copyOfRange(raw, split + 4, raw.length);
                    if (headers.toLowerCase(Locale.ROOT).contains("transfer-encoding: chunked")) {
                        responseBody = decodeChunked(responseBody);
                    }

                    String[] lines = headers.split("\\r?\\n");
                    int status = 200;
                    String statusText = "OK";
                    if (lines.length > 0) {
                        String[] p = lines[0].split(" ", 3);
                        if (p.length > 1) {
                            try { status = Integer.parseInt(p[1]); } catch (Exception ignored) {}
                        }
                        if (p.length > 2) statusText = p[2];
                    }

                    String responseCt = "text/xml";
                    for (String line : lines) {
                        int colon = line.indexOf(':');
                        if (colon > 0 && "content-type".equalsIgnoreCase(line.substring(0, colon).trim())) {
                            responseCt = line.substring(colon + 1).trim();
                        }
                    }

                    result.put("ok", status >= 200 && status < 400);
                    result.put("status", status);
                    result.put("statusText", statusText);
                    result.put("contentType", responseCt);
                    result.put("body", new String(responseBody, StandardCharsets.UTF_8));
                    return result.toString();
                }
            } catch (Exception e) {
                try {
                    result.put("ok", false);
                    result.put("status", 0);
                    result.put("error", e.getClass().getSimpleName() + ": " +
                            (e.getMessage() == null ? "RD Service unavailable" : e.getMessage()));
                } catch (Exception ignored) {}
                return result.toString();
            }
        }
    }

    private int headerEnd(byte[] data) {
        for (int i = 0; i + 3 < data.length; i++) {
            if (data[i] == '\r' && data[i + 1] == '\n' &&
                    data[i + 2] == '\r' && data[i + 3] == '\n') return i;
        }
        return -1;
    }

    private byte[] decodeChunked(byte[] data) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int pos = 0;
        while (pos < data.length) {
            int lineEnd = -1;
            for (int i = pos; i + 1 < data.length; i++) {
                if (data[i] == '\r' && data[i + 1] == '\n') {
                    lineEnd = i;
                    break;
                }
            }
            if (lineEnd < 0) break;
            String sizeLine = new String(data, pos, lineEnd - pos, StandardCharsets.US_ASCII).trim();
            int semi = sizeLine.indexOf(';');
            if (semi >= 0) sizeLine = sizeLine.substring(0, semi);
            int size = Integer.parseInt(sizeLine.trim(), 16);
            pos = lineEnd + 2;
            if (size == 0) break;
            if (pos + size > data.length) throw new IllegalStateException("Invalid chunk");
            out.write(data, pos, size);
            pos += size + 2;
        }
        return out.toByteArray();
    }

    private boolean isPdfDownload(String url, String mimeType, String contentDisposition) {
        if (isPdfCandidate(url, mimeType)) return true;
        if (contentDisposition == null || contentDisposition.isEmpty()) return false;
        try {
            String file = URLUtil.guessFileName(url, contentDisposition, mimeType);
            return file != null && file.toLowerCase(Locale.ROOT).endsWith(".pdf");
        } catch (Exception ignored) { return false; }
    }

    private boolean isPdfCandidate(String url, String typeHint) {
        if (typeHint != null && typeHint.toLowerCase(Locale.ROOT).contains("application/pdf")) return true;
        if (url == null) return false;
        String lower = url.toLowerCase(Locale.ROOT);
        String clean = lower;
        int h = clean.indexOf('#');
        if (h >= 0) clean = clean.substring(0, h);
        if (clean.endsWith(".pdf") || clean.contains(".pdf?") || clean.contains(".pdf&")) return true;
        return lower.contains("/pdf/") ||
                lower.contains("format=pdf") ||
                lower.contains("type=pdf") ||
                lower.contains("contenttype=application%2fpdf") ||
                lower.contains("content-type=application%2fpdf") ||
                lower.contains("application/pdf");
    }

    // Capture generated PDF bytes inside the producing WebView, before a site can
    // revoke its short-lived blob: URL. This is important for portals which
    // create a PDF in a click handler, click an ephemeral <a download>, then
    // immediately call URL.revokeObjectURL(...).
    private void injectPdfHook(WebView view) {
        String js = "(function(){"
                + "if(window.__stsPdfHook)return;window.__stsPdfHook=1;"
                + "var saved=new Map(),oldCreate=URL.createObjectURL;"
                + "if(typeof oldCreate==='function'){URL.createObjectURL=function(b){"
                + "var u=oldCreate.apply(URL,arguments);"
                + "try{var t=String((b&&b.type)||'').toLowerCase();"
                + "if(b&&typeof b.size==='number'&&b.size>4&&b.size<=" + MAX_PDF_BLOB_BYTES
                + "&&(t.indexOf('pdf')>=0||t.indexOf('octet-stream')>=0||!t)){"
                + "saved.set(u,b);while(saved.size>3)saved.delete(saved.keys().next().value);"
                + "}}catch(x){}return u;};}"
                + "window.__stsStartPdf=function(u,n){"
                + "var id='p'+Date.now().toString(36)+Math.random().toString(36).slice(2);"
                + "try{if(!STSPdfBlob.begin(id,String(n||'Document.pdf')))return false;}catch(x){return false;}"
                + "var b=saved.get(u);if(b)saved.delete(u);"
                + "var job=b?Promise.resolve(b):fetch(u,{credentials:'include'}).then(function(r){"
                + "if(!r.ok)throw Error('fetch');return r.blob();});"
                + "job.then(function(blob){if(!blob||blob.size<5||blob.size>" + MAX_PDF_BLOB_BYTES + ")throw Error('size');"
                + "return new Promise(function(ok,no){var f=new FileReader();"
                + "f.onload=function(){try{var v=String(f.result||'').split(',')[1]||'';"
                + "for(var i=0;i<v.length;i+=65536){STSPdfBlob.chunk(id,v.slice(i,i+65536));}"
                + "STSPdfBlob.finish(id);ok();}catch(x){no(x);}};"
                + "f.onerror=no;f.readAsDataURL(blob);});"
                + "}).catch(function(){STSPdfBlob.fail(id);});return true;};"
                + "document.addEventListener('click',function(e){"
                + "var a=e.target&&e.target.closest?e.target.closest('a'):null;if(!a)return;"
                + "var h=a.href||'',t=(a.getAttribute('type')||'').toLowerCase();"
                + "var d=(a.getAttribute('download')||'').toLowerCase(),hl=h.toLowerCase();"
                + "var p=t.indexOf('application/pdf')>=0||d.endsWith('.pdf')||/\\.pdf([?#&]|$)/i.test(h)"
                + "||hl.indexOf('format=pdf')>=0||hl.indexOf('type=pdf')>=0;"
                + "if(!p)return;var n=a.getAttribute('download')||'Document.pdf';"
                + "if(h.indexOf('blob:')===0||h.indexOf('data:application/pdf')===0){"
                + "if(window.__stsStartPdf(h,n)){e.preventDefault();e.stopPropagation();}return;}"
                + "if(h.indexOf('http')===0){e.preventDefault();e.stopPropagation();"
                + "try{STSPdf.openPdf(h,n);}catch(x){}}"
                + "},true);"
                + "var es=document.querySelectorAll('embed[type=\\\"application/pdf\\\"],object[type=\\\"application/pdf\\\"],iframe[src*=\\\".pdf\\\"]');"
                + "for(var i=0;i<es.length;i++){var u=es[i].src||es[i].data||'';"
                + "if(u.indexOf('http')===0){try{STSPdf.openPdf(u,'Document.pdf');}catch(x){}break;}}"
                + "})();";
        try { view.evaluateJavascript(js, null); } catch (Exception ignored) {}
    }

    private class PdfBridge {
        private final WebView owner;
        PdfBridge(WebView owner) { this.owner = owner; }
        @JavascriptInterface public void openPdf(String url, String name) {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://")
                    || url.startsWith("blob:") || url.startsWith("data:application/pdf"))) return;
            runOnUiThread(() -> openPdfTask(url, guessPdfName(url, name), owner));
        }
    }

    private String guessPdfName(String url, String contentDisposition) {
        try {
            String guessed = URLUtil.guessFileName(url, contentDisposition, "application/pdf");
            if (guessed != null && !guessed.trim().isEmpty()) return guessed;
        } catch (Exception ignored) {}
        return "Document.pdf";
    }

    private void openPdfTask(String url, String name) {
        openPdfTask(url, name, webView);
    }

    private void openPdfTask(String url, String name, WebView source) {
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(this, "PDF का लिंक उपलब्ध नहीं है", Toast.LENGTH_SHORT).show();
            return;
        }
        if (url.startsWith("blob:") || url.startsWith("data:application/pdf")) {
            if (source != null) openBrowserBlobPdf(source, url, name);
            else Toast.makeText(this, "PDF को वेबसाइट से दोबारा खोलें", Toast.LENGTH_LONG).show();
            return;
        }
        if (!(url.startsWith("https://") || url.startsWith("http://"))) {
            Toast.makeText(this, "यह PDF लिंक समर्थित नहीं है", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent intent = new Intent(this, PdfViewerActivity.class);
            intent.putExtra("pdf_url", url);
            intent.putExtra("pdf_name", name);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) intent.putExtra("pdf_cookie", cookie);
            WebView actual = source != null ? source : webView;
            if (actual != null) {
                intent.putExtra("pdf_user_agent", actual.getSettings().getUserAgentString());
                String referrer = actual.getUrl();
                if (referrer != null && (referrer.startsWith("https://") || referrer.startsWith("http://")))
                    intent.putExtra("pdf_referer", referrer);
            }
            intent.putExtra("pdf_slot", source == webView2 ? 2 : (source == webView1 ? 1 : activeSlot));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "PDF open नहीं हो पाया", Toast.LENGTH_SHORT).show();
        }
    }

    // Android WebView owns blob: documents. HttpURLConnection cannot download them.
    // Copy the actual PDF bytes through a bounded chunk bridge into the app's private
    // PDF cache. Each transfer uses a single-use random token and is not a network API.
    private static final int MAX_PDF_BLOB_BYTES = 64 * 1024 * 1024;
    private final java.util.Map<String, BlobPdfTransfer> pendingPdfBlobs = new java.util.HashMap<>();

    private static final class BlobPdfTransfer {
        final File file;
        final String name;
        java.io.FileOutputStream out;
        int size;
        BlobPdfTransfer(File file, String name) {this.file=file;this.name=name;}
    }

    private void openBrowserBlobPdf(WebView source, String url, String name) {
        if (source == null) return;
        String call = "(window.__stsStartPdf&&window.__stsStartPdf("
                + org.json.JSONObject.quote(url) + "," + org.json.JSONObject.quote(name) + "))||false";
        try {
            source.evaluateJavascript(call, result -> {
                if (!"true".equals(result)) openBrowserBlobPdfFallback(source, url, name);
            });
        } catch (Exception ignored) { openBrowserBlobPdfFallback(source, url, name); }
    }

    private void openBrowserBlobPdfFallback(WebView source, String url, String name) {
        final String token = java.util.UUID.randomUUID().toString();
        try {
            File dir = new File(getCacheDir(), "pdf");
            if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("PDF cache unavailable");
            File file = new File(dir, "browser-" + token + ".pdf");
            BlobPdfTransfer transfer = new BlobPdfTransfer(file, name == null ? "Document.pdf" : name);
            transfer.out = new java.io.FileOutputStream(file);
            synchronized (pendingPdfBlobs) {pendingPdfBlobs.put(token, transfer);}
            String js = "(function(){var id=" + org.json.JSONObject.quote(token)
                    + ",u=" + org.json.JSONObject.quote(url)
                    + ";fetch(u).then(function(r){if(!r.ok)throw Error('read');return r.blob();})"
                    + ".then(function(b){if(b.size>" + MAX_PDF_BLOB_BYTES + ")throw Error('size');"
                    + "var f=new FileReader();f.onload=function(){var s=String(f.result||'');"
                    + "var v=s.substring(s.indexOf(',')+1);for(var i=0;i<v.length;i+=16384)"
                    + "STSPdfBlob.chunk(id,v.substring(i,i+16384));STSPdfBlob.finish(id);};"
                    + "f.onerror=function(){STSPdfBlob.fail(id);};f.readAsDataURL(b);})"
                    + ".catch(function(){STSPdfBlob.fail(id);});})();";
            source.evaluateJavascript(js, null);
            Toast.makeText(this, "PDF लोड हो रही है...", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            synchronized (pendingPdfBlobs) {
                BlobPdfTransfer old = pendingPdfBlobs.remove(token);
                if(old!=null){ try {old.out.close();} catch(Exception ignored){} old.file.delete(); }
            }
            Toast.makeText(this, "PDF पढ़ी नहीं जा सकी", Toast.LENGTH_SHORT).show();
        }
    }

    private class PdfBlobBridge {
        private final WebView owner;
        PdfBlobBridge(WebView owner) {this.owner=owner;}
        @JavascriptInterface public boolean begin(String id, String requestedName) {
            if (id == null || !id.matches("[A-Za-z0-9_-]{8,100}")) return false;
            File file = null;
            try {
                File dir = new File(getCacheDir(), "pdf");
                if (!dir.isDirectory() && !dir.mkdirs()) return false;
                // Do not trust web page filenames or derive storage paths from them.
                String clean = requestedName == null ? "Document.pdf" : requestedName
                        .replaceAll("[\\/\r\n\t]", "_").trim();
                if (clean.isEmpty()) clean="Document.pdf";
                if (clean.length()>140) clean=clean.substring(0,140);
                file = new File(dir,"browser-" + java.util.UUID.randomUUID() + ".pdf");
                BlobPdfTransfer item = new BlobPdfTransfer(file, clean);
                item.out = new java.io.FileOutputStream(file);
                synchronized(pendingPdfBlobs) {
                    if(pendingPdfBlobs.size()>=3||pendingPdfBlobs.containsKey(id)) {
                        item.out.close();file.delete();return false;
                    }
                    pendingPdfBlobs.put(id,item);
                }
                return true;
            } catch(Exception ignored) {if(file!=null)file.delete();return false;}
        }
        @JavascriptInterface public void chunk(String id, String data) {
            synchronized (pendingPdfBlobs) {
                BlobPdfTransfer item = pendingPdfBlobs.get(id);
                if (item == null || item.out == null) return;
                try {
                    byte[] bytes = android.util.Base64.decode(data, android.util.Base64.DEFAULT);
                    if(item.size + bytes.length > MAX_PDF_BLOB_BYTES) throw new java.io.IOException("too large");
                    item.out.write(bytes);item.size+=bytes.length;
                } catch(Exception e){pendingPdfBlobs.remove(id);try{item.out.close();}catch(Exception ignored){}item.file.delete();}
            }
        }
        @JavascriptInterface public void fail(String id) { finishTransfer(id, true); }
        @JavascriptInterface public void finish(String id) { finishTransfer(id, false); }
        private void finishTransfer(String id, boolean failed) {
            final BlobPdfTransfer item;
            synchronized (pendingPdfBlobs) {item=pendingPdfBlobs.remove(id);}
            if(item==null)return;
            try {item.out.close();}catch(Exception ignored){}
            boolean valid=!failed && item.size>8;
            if(valid)try(java.io.FileInputStream in=new java.io.FileInputStream(item.file)){
                byte[] prefix=new byte[5];valid=in.read(prefix)==5 && prefix[0]=='%' && prefix[1]=='P' && prefix[2]=='D' && prefix[3]=='F' && prefix[4]=='-';
            }catch(Exception e){valid=false;}
            final boolean pdfValid=valid;
            final boolean failedTransfer=failed;
            if(!valid)item.file.delete();
            runOnUiThread(()->{
                if(!pdfValid){Toast.makeText(MainActivity.this,
                        failedTransfer ? "PDF लिंक बंद हो गया या डेटा नहीं मिला। Download Again दबाएँ।"
                               : "वेबसाइट ने वैध PDF डेटा नहीं दिया।", Toast.LENGTH_LONG).show();return;}
                try {
                    Uri uri=Uri.parse("content://"+getPackageName()+".pdfshare/"+Uri.encode(item.file.getName()));
                    Intent intent=new Intent(MainActivity.this,PdfViewerActivity.class);
                    intent.setDataAndType(uri,"application/pdf");
                    intent.setClipData(ClipData.newRawUri("STS PDF",uri));
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    intent.putExtra("pdf_name",item.name);
                    intent.putExtra("pdf_slot",owner==webView2?2:1);
                    startActivity(intent);
                }catch(Exception e){Toast.makeText(MainActivity.this,"PDF open नहीं हो पाया",Toast.LENGTH_SHORT).show();}
            });
        }
    }


    private boolean isOfficeCandidate(String url, String typeHint) {
        String type = typeHint == null ? "" : typeHint.toLowerCase(Locale.ROOT);
        if (type.contains("wordprocessingml") || type.contains("spreadsheetml") ||
                type.contains("presentationml") || type.contains("application/msword") ||
                type.contains("application/vnd.ms-word") || type.contains("application/vnd.ms-excel") ||
                type.contains("application/excel") || type.contains("application/vnd.ms-powerpoint") ||
                type.contains("text/csv") || type.contains("text/plain") || type.contains("application/rtf") ||
                type.contains("text/rtf") || type.contains("opendocument") || type.contains("application/ofd")) {
            return true;
        }
        if (url == null) return false;
        String lower = url.toLowerCase(Locale.ROOT);
        int hash = lower.indexOf('#');
        if (hash >= 0) lower = lower.substring(0, hash);
        return lower.endsWith(".docx") || lower.endsWith(".doc") ||
                lower.endsWith(".xlsx") || lower.endsWith(".xls") ||
                lower.endsWith(".pptx") || lower.endsWith(".ppt") ||
                lower.endsWith(".csv") || lower.endsWith(".txt") || lower.endsWith(".rtf") ||
                lower.endsWith(".odt") || lower.endsWith(".ods") || lower.endsWith(".odp") || lower.endsWith(".ofd") ||
                lower.contains(".docx?") || lower.contains(".doc?") ||
                lower.contains(".xlsx?") || lower.contains(".xls?") ||
                lower.contains(".pptx?") || lower.contains(".ppt?") ||
                lower.contains(".csv?") || lower.contains(".txt?") || lower.contains(".rtf?") ||
                lower.contains(".odt?") || lower.contains(".ods?") || lower.contains(".odp?") || lower.contains(".ofd?") ||
                lower.contains(".docx&") || lower.contains(".doc&") ||
                lower.contains(".xlsx&") || lower.contains(".xls&") ||
                lower.contains(".pptx&") || lower.contains(".ppt&") ||
                lower.contains(".csv&") || lower.contains(".txt&") || lower.contains(".rtf&") ||
                lower.contains(".odt&") || lower.contains(".ods&") || lower.contains(".odp&") || lower.contains(".ofd&");
    }

    private String guessOfficeName(String url, String contentDisposition, String mimeType) {
        try {
            String mime = mimeType;
            if (TextUtils.isEmpty(mime)) {
                String l = url == null ? "" : url.toLowerCase(Locale.ROOT);
                if (l.contains(".xlsx")) mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                else if (l.contains(".xls")) mime = "application/vnd.ms-excel";
                else if (l.contains(".docx")) mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                else if (l.contains(".doc")) mime = "application/msword";
                else if (l.contains(".pptx")) mime = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
                else if (l.contains(".ppt")) mime = "application/vnd.ms-powerpoint";
                else if (l.contains(".csv")) mime = "text/csv";
                else if (l.contains(".txt")) mime = "text/plain";
                else if (l.contains(".rtf")) mime = "application/rtf";
                else if (l.contains(".odt")) mime = "application/vnd.oasis.opendocument.text";
                else if (l.contains(".ods")) mime = "application/vnd.oasis.opendocument.spreadsheet";
                else if (l.contains(".odp")) mime = "application/vnd.oasis.opendocument.presentation";
                else if (l.contains(".ofd")) mime = "application/ofd";
                else mime = "application/octet-stream";
            }
            String guessed = URLUtil.guessFileName(url, contentDisposition, mime);
            if (!TextUtils.isEmpty(guessed)) return guessed;
        } catch (Exception ignored) {}
        return "Document.docx";
    }

    private void openOfficeTask(String url, String name) {
        try {
            Intent intent = new Intent(this, OfficeViewerActivity.class);
            intent.putExtra("office_url", url);
            intent.putExtra("office_name", name);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) intent.putExtra("office_cookie", cookie);
            intent.putExtra("office_user_agent", webView.getSettings().getUserAgentString());
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Word/Excel file open नहीं हो पाई", Toast.LENGTH_SHORT).show();
        }
    }

    private void captureDownloadHintAtPoint(WebView view, float rawX, float rawY) {
        if (view == null) return;
        String x = String.format(Locale.US, "%.2f", rawX);
        String y = String.format(Locale.US, "%.2f", rawY);
        String js =
                "(function(){try{" +
                "var d=(window.devicePixelRatio||1),x=" + x + "/d,y=" + y + "/d;" +
                "var e=document.elementFromPoint(x,y),a=e,c=0;" +
                "while(a&&c<8){if(a.matches&&a.matches('a[href],button,[role=link],[role=button]'))break;a=a.parentElement;c++;}" +
                "if(!a)return JSON.stringify({h:'',n:''});" +
                "var h=String(a.href||a.getAttribute&&a.getAttribute('href')||'');" +
                "var n=String((a.getAttribute&&a.getAttribute('download'))||(a.getAttribute&&a.getAttribute('aria-label'))||(a.getAttribute&&a.getAttribute('title'))||a.innerText||a.textContent||'').trim();" +
                "return JSON.stringify({h:h,n:n});" +
                "}catch(e){return JSON.stringify({h:'',n:''});}})()";
        try {
            view.evaluateJavascript(js, value -> {
                try {
                    if (TextUtils.isEmpty(value) || "null".equals(value)) return;
                    JSONArray wrap = new JSONArray("[" + value + "]");
                    String raw = wrap.optString(0, "");
                    if (TextUtils.isEmpty(raw)) return;
                    JSONObject obj = new JSONObject(raw);
                    String href = obj.optString("h", "");
                    String name = filenameFromClickedHref(href);
                    if (TextUtils.isEmpty(name)) name = normalizeClickedDownloadName(obj.optString("n", ""));
                    if (TextUtils.isEmpty(name)) return;
                    synchronized (downloadHints) {
                        downloadHints.put(view, new DownloadHint(href, name, System.currentTimeMillis()));
                    }
                } catch (Exception ignored) {}
            });
        } catch (Exception ignored) {}
    }

    private void injectDownloadNameHook(WebView view) {
        if (view == null) return;
        String js =
                "(function(){" +
                "if(window.__stsDownloadNameHook)return;window.__stsDownloadNameHook=true;" +
                "function clean(v){return String(v||'').replace(/\\s+/g,' ').trim();}" +
                "function fileNameFromExactLink(a){try{if(!a)return '';" +
                "var n=clean(a.getAttribute('download'))||clean(a.getAttribute('aria-label'))||clean(a.getAttribute('title'))||clean(a.textContent);" +
                "if(!n)return '';" +
                "var m=n.match(/([A-Za-z0-9][^\\\\/:*?\"<>|\\n\\r]{0,170}\\.(?:apk|zip|pdf|docx?|xlsx?|pptx?|csv|txt|rtf|odt|ods|odp|jpg|jpeg|png|webp|gif|bmp|heic|heif|mp4|mkv|webm|mov|avi|mp3|m4a|aac|wav|ogg|flac))/i);" +
                "if(m)return m[1].trim();" +
                "var t=n.toLowerCase();" +
                "var ext='';if(/\\bapk\\b/.test(t))ext='.apk';else if(/\\bzip\\b/.test(t))ext='.zip';else if(/\\bpdf\\b/.test(t))ext='.pdf';" +
                "if(!ext)return '';" +
                "n=n.replace(/\\b(download|डाउनलोड|करें|kare|karen)\\b/ig,' ').replace(/\\b(apk|zip|pdf)\\b/ig,' ').replace(/\\s+/g,' ').trim();" +
                "if(!n)n='download';return n+ext;}catch(e){return '';}}" +
                "function exactLink(e){try{" +
                "var p=e.composedPath?e.composedPath():[];" +
                "for(var i=0;i<p.length;i++){var x=p[i];if(x&&x.href)return x;}" +
                "return e.target&&e.target.closest?e.target.closest('[href]'):null;}catch(z){return null;}}" +
                "function remember(e){try{var a=exactLink(e);if(!a)return;var h=String(a.href||a.getAttribute('href')||'');if(!h||/^javascript:/i.test(h))return;" +
                "var n=fileNameFromExactLink(a);window.__stsLastDownloadHref=h;window.__stsLastDownloadName=n;window.__stsLastDownloadAt=Date.now();" +
                "if(n&&window.STSDownload&&STSDownload.remember)STSDownload.remember(h,n);" +
                "}catch(x){}}" +
                "['pointerdown','touchstart','mousedown','click'].forEach(function(t){document.addEventListener(t,remember,true);});" +
                "})();";
        try { view.evaluateJavascript(js, null); } catch (Exception ignored) {}
    }

    private class DownloadBridge {
        private final WebView owner;

        DownloadBridge(WebView owner) {
            this.owner = owner;
        }

        @JavascriptInterface
        public void remember(String href, String name) {
            String clean = filenameFromClickedHref(href);
            if (TextUtils.isEmpty(clean)) clean = normalizeClickedDownloadName(name);
            if (TextUtils.isEmpty(clean)) return;
            synchronized (downloadHints) {
                downloadHints.put(owner, new DownloadHint(href, clean, System.currentTimeMillis()));
            }
        }
    }

    private void handleBrowserDownload(String url, String userAgent, String contentDisposition,
                                       String mimeType, WebView sourceView) {
        if (sourceView == null) {
            enqueueBrowserDownload(url, userAgent, contentDisposition, mimeType, null);
            return;
        }

        try {
            sourceView.evaluateJavascript(
                    "(function(){try{var a=Date.now()-(window.__stsLastDownloadAt||0);" +
                            "return JSON.stringify({h:a<20000?(window.__stsLastDownloadHref||''):''," +
                            "n:a<20000?(window.__stsLastDownloadName||''):''});}catch(e){return '{}';}})()",
                    value -> {
                        try {
                            String raw = "";
                            if (!TextUtils.isEmpty(value) && !"null".equals(value)) {
                                JSONArray wrap = new JSONArray("[" + value + "]");
                                raw = wrap.optString(0, "");
                            }
                            if (!TextUtils.isEmpty(raw)) {
                                JSONObject meta = new JSONObject(raw);
                                String clickedHref = meta.optString("h", "");
                                String clickedName = filenameFromClickedHref(clickedHref);
                                if (TextUtils.isEmpty(clickedName)) {
                                    clickedName = normalizeClickedDownloadName(meta.optString("n", ""));
                                }
                                if (!TextUtils.isEmpty(clickedName)) {
                                    synchronized (downloadHints) {
                                        downloadHints.put(sourceView,
                                                new DownloadHint(clickedHref, clickedName, System.currentTimeMillis()));
                                    }
                                }
                            }
                        } catch (Exception ignored) {}
                        enqueueBrowserDownload(url, userAgent, contentDisposition, mimeType, sourceView);
                    });
        } catch (Exception e) {
            enqueueBrowserDownload(url, userAgent, contentDisposition, mimeType, sourceView);
        }
    }

    private String sanitizeDownloadName(String value) {
        if (TextUtils.isEmpty(value)) return "";
        String name = value.replaceAll("[\\\\/:*?\"<>|\\r\\n]+", "_")
                .replaceAll("\\s+", " ").trim();
        if (name.length() > 180) name = name.substring(0, 180).trim();
        return name;
    }

    private String normalizeClickedDownloadName(String value) {
        String n = sanitizeDownloadName(value);
        if (TextUtils.isEmpty(n)) return "";

        String lower = n.toLowerCase(Locale.ROOT);
        if (lower.matches(".*\\.(apk|zip|pdf|docx?|xlsx?|pptx?|csv|txt|rtf|odt|ods|odp|jpg|jpeg|png|webp|gif|bmp|heic|heif|mp4|mkv|webm|mov|avi|mp3|m4a|aac|wav|ogg|flac|rar|7z|gz|exe|msi)$")) {
            return n;
        }

        String ext = null;
        if (lower.matches(".*\\bapk\\b.*")) ext = ".apk";
        else if (lower.matches(".*\\bzip\\b.*")) ext = ".zip";
        else if (lower.matches(".*\\bpdf\\b.*")) ext = ".pdf";
        else if (lower.matches(".*\\bdocx\\b.*")) ext = ".docx";
        else if (lower.matches(".*\\bxlsx\\b.*")) ext = ".xlsx";
        else if (lower.matches(".*\\bpptx\\b.*")) ext = ".pptx";
        else if (lower.matches(".*\\bjpg\\b.*|.*\\bjpeg\\b.*")) ext = ".jpg";
        else if (lower.matches(".*\\bpng\\b.*")) ext = ".png";
        else if (lower.matches(".*\\bwebp\\b.*")) ext = ".webp";
        else if (lower.matches(".*\\bmp4\\b.*")) ext = ".mp4";
        else if (lower.matches(".*\\bmp3\\b.*")) ext = ".mp3";
        else if (lower.matches(".*\\brar\\b.*")) ext = ".rar";
        else if (lower.matches(".*\\b7z\\b.*")) ext = ".7z";
        if (ext == null) return "";

        n = n.replaceAll("(?i)\\b(download|apk|zip|pdf|docx|xlsx|pptx|jpg|jpeg|png|webp|mp4|mp3|rar|7z|kare|karen)\\b", " ")
                .replace("डाउनलोड", " ")
                .replace("करें", " ")
                .replaceAll("\\s+", " ").trim();
        if (TextUtils.isEmpty(n)) n = "download";
        return sanitizeDownloadName(n + ext);
    }

    private boolean isGenericDownloadName(String name) {
        if (TextUtils.isEmpty(name)) return true;
        String n = name.toLowerCase(Locale.ROOT).trim();
        return n.equals("content.bin") || n.equals("content") ||
                n.equals("download") || n.equals("download.bin") ||
                n.equals("file") || n.equals("file.bin") ||
                n.equals("unknown") || n.equals("unknown.bin") ||
                n.equals("blob") || n.equals("blob.bin");
    }

    private String fileExtension(String name) {
        if (TextUtils.isEmpty(name)) return "";
        String clean = name.toLowerCase(Locale.ROOT);
        int q = clean.indexOf('?');
        if (q >= 0) clean = clean.substring(0, q);
        int dot = clean.lastIndexOf('.');
        if (dot < 0 || dot >= clean.length() - 1) return "";
        String ext = clean.substring(dot);
        return ext.length() <= 9 ? ext : "";
    }

    private String replaceFileExtension(String name, String ext) {
        String clean = sanitizeDownloadName(name);
        if (TextUtils.isEmpty(clean)) clean = "download";
        int dot = clean.lastIndexOf('.');
        if (dot > 0) clean = clean.substring(0, dot);
        return clean + (TextUtils.isEmpty(ext) ? "" : ext);
    }

    private String filenameFromContentDisposition(String contentDisposition, String mimeType) {
        if (TextUtils.isEmpty(contentDisposition)) return "";
        try {
            String guessed = URLUtil.guessFileName("https://download.invalid/file",
                    contentDisposition, mimeType);
            guessed = sanitizeDownloadName(guessed);
            return isGenericDownloadName(guessed) ? "" : guessed;
        } catch (Exception ignored) {
            return "";
        }
    }

    private String filenameFromClickedHref(String href) {
        if (TextUtils.isEmpty(href)) return "";
        try {
            Uri uri = Uri.parse(href);

            // Exact path filename works for https://, sandbox:/, content-like/custom schemes, etc.
            String last = uri.getLastPathSegment();
            if (!TextUtils.isEmpty(last)) {
                last = java.net.URLDecoder.decode(last, "UTF-8");
                last = sanitizeDownloadName(last);
                if (!isGenericDownloadName(last) &&
                        last.matches("(?i).+\\.(apk|zip|pdf|docx?|xlsx?|pptx?|csv|txt|rtf|odt|ods|odp|jpg|jpeg|png|webp|gif|bmp|heic|heif|mp4|mkv|webm|mov|avi|mp3|m4a|aac|wav|ogg|flac|rar|7z|gz|exe|msi)$")) {
                    return last;
                }
            }

            // Common download APIs carry the real name in a query parameter.
            String[] keys = new String[]{"filename", "file_name", "download_name", "name"};
            for (String key : keys) {
                String value = uri.getQueryParameter(key);
                value = sanitizeDownloadName(value);
                if (!TextUtils.isEmpty(value) && !isGenericDownloadName(value) &&
                        value.matches("(?i).+\\.[a-z0-9]{1,8}$")) {
                    return value;
                }
            }
        } catch (Exception ignored) {}
        return "";
    }

    private String filenameFromUrl(String url) {
        if (TextUtils.isEmpty(url)) return "";
        try {
            String last = Uri.parse(url).getLastPathSegment();
            if (TextUtils.isEmpty(last)) return "";
            last = java.net.URLDecoder.decode(last, "UTF-8");
            last = sanitizeDownloadName(last);
            if (isGenericDownloadName(last)) return "";
            if (last.matches("(?i).+\\.[a-z0-9]{1,8}$")) return last;
        } catch (Exception ignored) {}
        return "";
    }

    private String extensionForMime(String mimeType) {
        if (TextUtils.isEmpty(mimeType)) return "";
        String m = mimeType.toLowerCase(Locale.ROOT).split(";")[0].trim();
        if (m.equals("application/vnd.android.package-archive")) return ".apk";
        if (m.equals("application/zip") || m.equals("application/x-zip-compressed")) return ".zip";
        if (m.equals("application/pdf")) return ".pdf";
        if (m.equals("image/jpeg")) return ".jpg";
        if (m.equals("image/png")) return ".png";
        if (m.equals("image/webp")) return ".webp";
        if (m.equals("image/gif")) return ".gif";
        if (m.equals("video/mp4")) return ".mp4";
        if (m.equals("audio/mpeg")) return ".mp3";
        if (m.equals("audio/flac")) return ".flac";
        if (m.equals("audio/ogg")) return ".ogg";
        if (m.contains("wordprocessingml")) return ".docx";
        if (m.contains("spreadsheetml")) return ".xlsx";
        if (m.contains("presentationml")) return ".pptx";
        if (m.equals("text/csv")) return ".csv";
        if (m.equals("text/plain")) return ".txt";
        return "";
    }

    private String mimeForExtension(String ext, String fallback) {
        String e = ext == null ? "" : ext.toLowerCase(Locale.ROOT);
        if (e.equals(".apk")) return "application/vnd.android.package-archive";
        if (e.equals(".zip")) return "application/zip";
        if (e.equals(".pdf")) return "application/pdf";
        if (e.equals(".jpg") || e.equals(".jpeg")) return "image/jpeg";
        if (e.equals(".png")) return "image/png";
        if (e.equals(".webp")) return "image/webp";
        if (e.equals(".gif")) return "image/gif";
        if (e.equals(".mp4")) return "video/mp4";
        if (e.equals(".mkv")) return "video/x-matroska";
        if (e.equals(".mp3")) return "audio/mpeg";
        if (e.equals(".wav")) return "audio/wav";
        if (e.equals(".flac")) return "audio/flac";
        if (e.equals(".ogg")) return "audio/ogg";
        if (e.equals(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        if (e.equals(".xlsx")) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        if (e.equals(".pptx")) return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
        if (e.equals(".csv")) return "text/csv";
        if (e.equals(".txt")) return "text/plain";
        if (e.equals(".rar")) return "application/vnd.rar";
        if (e.equals(".7z")) return "application/x-7z-compressed";
        if (e.equals(".gz")) return "application/gzip";
        if (e.equals(".exe")) return "application/vnd.microsoft.portable-executable";
        return TextUtils.isEmpty(fallback) ? "application/octet-stream" : fallback;
    }

    private String consumeDownloadHint(WebView sourceView) {
        if (sourceView == null) return "";
        synchronized (downloadHints) {
            DownloadHint hint = downloadHints.get(sourceView);
            if (hint == null) return "";
            if (System.currentTimeMillis() - hint.timeMs > 20000L) {
                downloadHints.remove(sourceView);
                return "";
            }
            downloadHints.remove(sourceView);
            return normalizeClickedDownloadName(hint.name);
        }
    }

    private String detectZipContainerType(File file) {
        boolean manifest = false;
        boolean dex = false;
        boolean resources = false;
        boolean contentTypes = false;
        boolean word = false;
        boolean xl = false;
        boolean ppt = false;
        try (ZipFile zip = new ZipFile(file)) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            int checked = 0;
            while (entries.hasMoreElements() && checked++ < 3000) {
                String n = entries.nextElement().getName();
                if ("AndroidManifest.xml".equals(n)) manifest = true;
                else if ("classes.dex".equals(n) || n.matches("classes\\d+\\.dex")) dex = true;
                else if ("resources.arsc".equals(n)) resources = true;
                else if ("[Content_Types].xml".equals(n)) contentTypes = true;
                else if (n.startsWith("word/")) word = true;
                else if (n.startsWith("xl/")) xl = true;
                else if (n.startsWith("ppt/")) ppt = true;
            }
        } catch (Exception ignored) {}

        if (manifest && (dex || resources)) return ".apk";
        if (contentTypes && word) return ".docx";
        if (contentTypes && xl) return ".xlsx";
        if (contentTypes && ppt) return ".pptx";
        return ".zip";
    }

    private String detectActualExtension(File file, String serverMime) {
        byte[] h = new byte[32];
        int n = 0;
        try (InputStream in = new FileInputStream(file)) {
            n = in.read(h);
        } catch (Exception ignored) {}

        if (n >= 4 && h[0] == 0x25 && h[1] == 0x50 && h[2] == 0x44 && h[3] == 0x46) return ".pdf";
        if (n >= 8 && (h[0] & 0xff) == 0x89 && h[1] == 0x50 && h[2] == 0x4e && h[3] == 0x47) return ".png";
        if (n >= 3 && (h[0] & 0xff) == 0xff && (h[1] & 0xff) == 0xd8 && (h[2] & 0xff) == 0xff) return ".jpg";
        if (n >= 6 && h[0] == 'G' && h[1] == 'I' && h[2] == 'F' && h[3] == '8') return ".gif";
        if (n >= 12 && h[0] == 'R' && h[1] == 'I' && h[2] == 'F' && h[3] == 'F' &&
                h[8] == 'W' && h[9] == 'E' && h[10] == 'B' && h[11] == 'P') return ".webp";
        if (n >= 12 && h[4] == 'f' && h[5] == 't' && h[6] == 'y' && h[7] == 'p') return ".mp4";
        if (n >= 4 && h[0] == 'O' && h[1] == 'g' && h[2] == 'g' && h[3] == 'S') return ".ogg";
        if (n >= 4 && h[0] == 'f' && h[1] == 'L' && h[2] == 'a' && h[3] == 'C') return ".flac";
        if (n >= 12 && h[0] == 'R' && h[1] == 'I' && h[2] == 'F' && h[3] == 'F' &&
                h[8] == 'W' && h[9] == 'A' && h[10] == 'V' && h[11] == 'E') return ".wav";
        if (n >= 3 && h[0] == 'I' && h[1] == 'D' && h[2] == '3') return ".mp3";
        if (n >= 4 && (h[0] & 0xff) == 0x1a && (h[1] & 0xff) == 0x45 &&
                (h[2] & 0xff) == 0xdf && (h[3] & 0xff) == 0xa3) return ".mkv";
        if (n >= 4 && h[0] == 'P' && h[1] == 'K' &&
                ((h[2] == 3 && h[3] == 4) || (h[2] == 5 && h[3] == 6) || (h[2] == 7 && h[3] == 8))) {
            return detectZipContainerType(file);
        }
        if (n >= 7 && (h[0] & 0xff) == 0x52 && (h[1] & 0xff) == 0x61 &&
                (h[2] & 0xff) == 0x72 && (h[3] & 0xff) == 0x21) return ".rar";
        if (n >= 6 && (h[0] & 0xff) == 0x37 && (h[1] & 0xff) == 0x7a &&
                (h[2] & 0xff) == 0xbc && (h[3] & 0xff) == 0xaf) return ".7z";
        if (n >= 2 && (h[0] & 0xff) == 0x1f && (h[1] & 0xff) == 0x8b) return ".gz";
        if (n >= 2 && h[0] == 'M' && h[1] == 'Z') return ".exe";

        return extensionForMime(serverMime);
    }

    private boolean extensionMatches(String name, String actualExt) {
        if (TextUtils.isEmpty(name)) return false;
        if (TextUtils.isEmpty(actualExt)) return true;
        String ext = fileExtension(name);
        if (TextUtils.isEmpty(ext)) return true;
        if (ext.equalsIgnoreCase(actualExt)) return true;
        if (actualExt.equals(".jpg") && ext.equalsIgnoreCase(".jpeg")) return true;
        return false;
    }

    private String chooseResolvedDownloadName(String headerName, String clickedName,
                                              String urlName, String actualExt) {
        // The filename the user actually tapped is the primary name.
        // Server/CDN names are often temporary artifact names even when the bytes are correct.
        String[] candidates = new String[]{clickedName, headerName, urlName};
        for (String candidate : candidates) {
            String clean = sanitizeDownloadName(candidate);
            if (TextUtils.isEmpty(clean) || isGenericDownloadName(clean)) continue;
            if (!extensionMatches(clean, actualExt)) continue;
            if (TextUtils.isEmpty(fileExtension(clean)) && !TextUtils.isEmpty(actualExt)) {
                clean += actualExt;
            }
            return clean;
        }

        // If the server supplied a useful base name but a wrong/generic extension,
        // keep the base and replace only the extension with the type verified from bytes.
        String usefulBase = sanitizeDownloadName(headerName);
        if (!TextUtils.isEmpty(usefulBase) && !isGenericDownloadName(usefulBase) && !TextUtils.isEmpty(actualExt)) {
            return replaceFileExtension(usefulBase, actualExt);
        }

        return "download-" + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date()) +
                (TextUtils.isEmpty(actualExt) ? "" : actualExt);
    }

    private File downloadToTemporaryFile(String startUrl, String userAgent, String cookie,
                                         String referer, DownloadResolvedMeta meta) throws Exception {
        File tmp = File.createTempFile("sfb-real-download-", ".tmp", getCacheDir());
        SafeHttpDownload.Result result = SafeHttpDownload.download(startUrl, tmp, userAgent,
                cookie, referer, address -> CookieManager.getInstance().getCookie(address));
        meta.finalUrl = result.url;
        meta.contentDisposition = result.contentDisposition;
        meta.contentType = result.contentType;
        meta.headerName = filenameFromContentDisposition(meta.contentDisposition, meta.contentType);
        return tmp;
    }

    private Uri saveVerifiedFileToDownloads(File temp, String fileName, String mimeType,
                                            String sourceUrl, String userAgent, String cookie,
                                            String referer) throws Exception {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            values.put(MediaStore.MediaColumns.MIME_TYPE,
                    TextUtils.isEmpty(mimeType) ? "application/octet-stream" : mimeType);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);

            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("Downloads insert failed");
            boolean ok = false;
            try (InputStream in = new BufferedInputStream(new FileInputStream(temp));
                 OutputStream out = new BufferedOutputStream(getContentResolver().openOutputStream(uri, "w"))) {
                if (out == null) throw new Exception("Downloads output unavailable");
                byte[] buffer = new byte[64 * 1024];
                int read;
                while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                out.flush();
                ok = true;
            } finally {
                if (!ok) {
                    try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
                }
            }

            android.content.ContentValues ready = new android.content.ContentValues();
            ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContentResolver().update(uri, ready, null, null);
            return uri;
        }

        // Android 7-9: after resolving the real name/type, let the system DownloadManager
        // perform the final public-Downloads write so legacy storage permissions are not required.
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(sourceUrl));
        request.setTitle(fileName);
        request.setDescription("STS Fast Browser");
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
        if (!TextUtils.isEmpty(mimeType)) request.setMimeType(mimeType);
        if (!TextUtils.isEmpty(userAgent)) request.addRequestHeader("User-Agent", userAgent);
        if (!TextUtils.isEmpty(cookie)) request.addRequestHeader("Cookie", cookie);
        if (!TextUtils.isEmpty(referer)) request.addRequestHeader("Referer", referer);
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        if (dm == null) throw new Exception("DownloadManager unavailable");
        dm.enqueue(request);
        return Uri.parse("content://downloads/my_downloads");
    }

    private void enqueueBrowserDownload(String url, String userAgent, String contentDisposition,
                                        String mimeType, WebView sourceView) {
        if (TextUtils.isEmpty(url)) {
            Toast.makeText(this, "Download link नहीं मिला", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!(url.startsWith("http://") || url.startsWith("https://"))) {
            Toast.makeText(this, "यह download link direct save नहीं हो पा रहा", Toast.LENGTH_SHORT).show();
            return;
        }

        final String clickedName = consumeDownloadHint(sourceView);

        String ua = userAgent;
        if (TextUtils.isEmpty(ua) && sourceView != null) {
            try { ua = sourceView.getSettings().getUserAgentString(); } catch (Exception ignored) {}
        }
        final String finalUa = ua;

        String cookie = null;
        try { cookie = CookieManager.getInstance().getCookie(url); } catch (Exception ignored) {}
        if (TextUtils.isEmpty(cookie) && sourceView != null) {
            try {
                String pageUrl = sourceView.getUrl();
                if (!TextUtils.isEmpty(pageUrl)) cookie = CookieManager.getInstance().getCookie(pageUrl);
            } catch (Exception ignored) {}
        }
        final String finalCookie = cookie;

        String referer = null;
        if (sourceView != null) {
            try {
                String pageUrl = sourceView.getUrl();
                if (!TextUtils.isEmpty(pageUrl) &&
                        (pageUrl.startsWith("http://") || pageUrl.startsWith("https://"))) {
                    referer = pageUrl;
                }
            } catch (Exception ignored) {}
        }
        final String finalReferer = referer;
        final String listenerDisposition = contentDisposition;
        final String listenerMime = mimeType;

        Toast.makeText(this, "Download शुरू...", Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            File temp = null;
            try {
                DownloadResolvedMeta meta = new DownloadResolvedMeta();
                temp = downloadToTemporaryFile(url, finalUa, finalCookie, finalReferer, meta);

                String serverMime = !TextUtils.isEmpty(meta.contentType) ? meta.contentType : listenerMime;
                String actualExt = detectActualExtension(temp, serverMime);
                String headerName = !TextUtils.isEmpty(meta.headerName)
                        ? meta.headerName
                        : filenameFromContentDisposition(listenerDisposition, serverMime);
                String urlName = filenameFromUrl(meta.finalUrl);
                if (TextUtils.isEmpty(urlName)) urlName = filenameFromUrl(url);

                String finalName = chooseResolvedDownloadName(headerName, clickedName, urlName, actualExt);
                String finalMime = mimeForExtension(actualExt, serverMime);

                saveVerifiedFileToDownloads(temp, finalName, finalMime,
                        meta.finalUrl, finalUa, finalCookie, finalReferer);

                final String doneName = finalName;
                final String doneType = finalMime;
                runOnUiThread(() -> Toast.makeText(
                        this,
                        "Downloaded: " + doneName + "\n" + doneType,
                        Toast.LENGTH_LONG
                ).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(
                        this,
                        "Download नहीं हुआ • server/file verification failed",
                        Toast.LENGTH_LONG
                ).show());
            } finally {
                if (temp != null) temp.delete();
            }
        }, "SFB-RealDownload").start();
    }

    private boolean openExternal(String url) {
        try {
            if (url.startsWith("intent:")) {
                Intent parsed = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                try {
                    startActivity(parsed);
                    return true;
                } catch (ActivityNotFoundException e) {
                    String fallback = parsed.getStringExtra("browser_fallback_url");
                    if (fallback != null) webView.loadUrl(fallback);
                    return true;
                }
            }
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
            return true;
        } catch (Exception e) {
            Toast.makeText(this, "Link open नहीं हो पाया", Toast.LENGTH_SHORT).show();
            return true;
        }
    }

    private void injectNormalAdCleanup(WebView view) {
        if (view == null) return;
        String js =
                "(function(){" +
                "if(window.__stsNormalAdBlockInstalled){try{window.__stsNormalAdClean&&window.__stsNormalAdClean();}catch(e){}return;}" +
                "window.__stsNormalAdBlockInstalled=true;" +
                "var sel=[" +
                "'ins.adsbygoogle','.adsbygoogle','[id^=\"google_ads_\"]','[id^=\"div-gpt-ad\"]'," +
                "'iframe[src*=\"doubleclick.net\"]','iframe[src*=\"googlesyndication.com\"]'," +
                "'iframe[src*=\"googleadservices.com\"]','[data-ad-client]','[data-ad-slot]'," +
                "'amp-ad','.advertisement','.ad-container','.ad-banner','.ad-wrapper'" +
                "];" +
                "window.__stsNormalAdClean=function(){for(var i=0;i<sel.length;i++){var n=[];try{n=document.querySelectorAll(sel[i]);}catch(e){}" +
                "for(var j=0;j<n.length;j++){try{n[j].style.setProperty('display','none','important');" +
                "n[j].style.setProperty('visibility','hidden','important');}catch(e){}}}};" +
                "window.__stsNormalAdClean();" +
                "try{var __stsNormalPending=false;new MutationObserver(function(){if(__stsNormalPending)return;__stsNormalPending=true;" +
                "setTimeout(function(){__stsNormalPending=false;window.__stsNormalAdClean();},180);}).observe(document.documentElement||document," +
                "{childList:true,subtree:true});}catch(e){}" +
                "})();";
        try { view.evaluateJavascript(js, null); } catch (Exception ignored) {}
    }

    private void injectHardAdCleanup(WebView view) {
        if (view == null) return;
        String js =
                "(function(){" +
                "if(window.__stsHardAdBlockInstalled){try{window.__stsHardAdClean&&window.__stsHardAdClean();}catch(e){}return;}" +
                "window.__stsHardAdBlockInstalled=true;" +
                "var sel=[" +
                "'amp-embed[type=\"taboola\"]','.sponsored','.promoted','.promoted-content'," +
                "'#player-ads','ytd-ad-slot-renderer','ytd-display-ad-renderer','ytd-promoted-sparkles-web-renderer'," +
                "'ytd-in-feed-ad-layout-renderer','ytd-promoted-video-renderer','ytm-promoted-video-renderer'," +
                "'ytm-companion-ad-renderer','ytm-display-ad-renderer','ytm-ad-slot-renderer','tp-yt-paper-dialog ytd-mealbar-promo-renderer'" +
                "];" +
                "function hideAds(){for(var i=0;i<sel.length;i++){var n=[];try{n=document.querySelectorAll(sel[i]);}catch(e){}" +
                "for(var j=0;j<n.length;j++){try{n[j].style.setProperty('display','none','important');" +
                "n[j].style.setProperty('visibility','hidden','important');n[j].setAttribute('aria-hidden','true');}catch(e){}}}}" +
                "function clickSkip(){var q=['.ytp-ad-skip-button-modern','.ytp-ad-skip-button','.ytp-skip-ad-button'," +
                "'button.ytp-ad-skip-button','button[id*=skip]'];for(var i=0;i<q.length;i++){var b=null;try{b=document.querySelector(q[i]);}catch(e){}" +
                "if(b&&b.offsetParent!==null){try{b.click();return true;}catch(e){}}}return false;}" +
                "function youtube(){try{" +
                "var p=document.querySelector('.html5-video-player');if(!p)return;" +
                "var ad=p.classList.contains('ad-showing')||p.classList.contains('ad-interrupting');" +
                "var v=p.querySelector('video');" +
                "if(ad&&v){" +
                "if(!window.__stsYtAdActive){window.__stsYtAdActive=true;window.__stsYtPrevMuted=!!v.muted;" +
                "window.__stsYtPrevRate=(v.playbackRate&&isFinite(v.playbackRate))?v.playbackRate:1;}" +
                "clickSkip();" +
                "try{v.muted=true;}catch(e){}" +
                "try{if(v.playbackRate<8)v.playbackRate=8;}catch(e){}" +
                "}else if(window.__stsYtAdActive&&v){" +
                "window.__stsYtAdActive=false;" +
                "try{v.playbackRate=window.__stsYtPrevRate||1;}catch(e){}" +
                "try{v.muted=!!window.__stsYtPrevMuted;}catch(e){}" +
                "}" +
                "}catch(e){}}" +
                "window.__stsHardAdClean=function(){hideAds();youtube();};" +
                "window.__stsHardAdClean();" +
                "try{var __stsAdPending=false,__stsSchedule=function(){if(__stsAdPending||document.hidden)return;__stsAdPending=true;" +
                "setTimeout(function(){__stsAdPending=false;if(!document.hidden)window.__stsHardAdClean();},180);};" +
                "new MutationObserver(__stsSchedule).observe(document.documentElement||document,{childList:true,subtree:true,attributes:true,attributeFilter:['class']});" +
                "document.addEventListener('play',__stsSchedule,true);document.addEventListener('loadedmetadata',__stsSchedule,true);" +
                "document.addEventListener('ended',__stsSchedule,true);document.addEventListener('visibilitychange',__stsSchedule,true);}catch(e){}" +
                
                "})();";
        try { view.evaluateJavascript(js, null); } catch (Exception ignored) {}
    }

    private boolean isHardAdRequest(Uri uri) {
        if (uri == null) return false;

        String host = uri.getHost();
        String path = uri.getEncodedPath();
        String query = uri.getEncodedQuery();
        host = host == null ? "" : host.toLowerCase(Locale.ROOT);
        path = path == null ? "" : path.toLowerCase(Locale.ROOT);
        query = query == null ? "" : query.toLowerCase(Locale.ROOT);

        // YouTube can keep the player waiting on a black frame when its own
        // ad endpoints are cancelled. Let YouTube requests complete and handle
        // its web ads in-page by auto-skip + safe fast playback instead.
        if (host.endsWith("googlevideo.com") ||
                host.equals("youtube.com") || host.endsWith(".youtube.com") ||
                host.equals("youtu.be") || host.endsWith(".youtu.be")) {
            return false;
        }

        // Aggressive same-host filtering remains enabled for other websites.
        return path.contains("/gampad/") ||
                path.contains("/pagead/") ||
                path.contains("/adserver/") ||
                path.contains("/adservice/") ||
                path.contains("/prebid/") ||
                path.contains("/vast/") ||
                path.contains("/vmap/") ||
                query.contains("google_ad_client=") ||
                query.contains("ad_slot=") ||
                query.contains("adunit=");
    }

    private boolean isBlocked(Uri uri) {
        String host = uri.getHost();
        if (host == null) return false;
        host = host.toLowerCase(Locale.ROOT);
        for (String blocked : blockedHosts) {
            if (blocked.endsWith(".")) {
                if (host.startsWith(blocked)) return true;
            } else if (host.equals(blocked) || host.endsWith("." + blocked)) {
                return true;
            }
        }
        return false;
    }

    private void showSitePopup(View anchor, int slot) {

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(4), dp(5), dp(4), dp(5));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(14));
        box.setBackground(bg);

        int popupWidth = Math.max(anchor.getWidth(), dp(180));
        android.widget.ScrollView popupScroll = new android.widget.ScrollView(this);
        popupScroll.setFillViewport(false);
        popupScroll.setVerticalScrollBarEnabled(false);
        popupScroll.addView(box);
        PopupWindow popup = new PopupWindow(popupScroll, popupWidth, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(true);
        popup.setElevation(dp(12));
        popup.setAnimationStyle(android.R.style.Animation_Dialog);

        {
            TextView phoneData = makePopupItem("Phone Data");
            phoneData.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            phoneData.setOnClickListener(v -> {
                popup.dismiss();
                finishAddressEditing();
                showDocumentsHome();
            });
            box.addView(phoneData, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
        }

        List<Site> entries = new ArrayList<>();
        entries.add(sitesD2.get(0));
        entries.addAll(orderedCustomSites());
        for (Site site : entries) {
            final int owner = siteOwner(site);
                TextView item = makePopupItem(site.name + (site.hasPassword() ? "  🔒" : ""));
                boolean selected = activeSlot == owner && site.url.equals(owner == 2 ? slot2Url : slot1Url)
                        && !(owner == 1 && slot1DocumentsHome) && !(owner == 2 && manualD2Address);
                if (selected) {
                    item.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                    item.setBackground(makeRipple(Color.parseColor("#D9E9E3")));
                }
                item.setOnClickListener(v -> {
                    popup.dismiss();
                    finishAddressEditing();
                    selectSite(owner, site);
                });
                box.addView(item, new LinearLayout.LayoutParams(-1, dp(48)));
        }

        fitPopupHeight(popup, box, anchor, popupWidth);
        android.graphics.Rect visibleFrame = new android.graphics.Rect();
        anchor.getWindowVisibleDisplayFrame(visibleFrame);
        int[] anchorPosition = new int[2];
        anchor.getLocationOnScreen(anchorPosition);
        popup.showAsDropDown(anchor, visibleFrame.left - anchorPosition[0], dp(2), Gravity.LEFT);
    }

    private void fitPopupHeight(PopupWindow popup, View content, View anchor, int width) {
        android.graphics.Rect frame = new android.graphics.Rect();
        anchor.getWindowVisibleDisplayFrame(frame);
        int[] location = new int[2];
        anchor.getLocationOnScreen(location);
        int available = Math.max(dp(48), frame.bottom - location[1] - anchor.getHeight() - dp(8));
        content.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        popup.setHeight(Math.min(available, content.getMeasuredHeight()));
        popup.setClippingEnabled(true);
    }

    private TextView makePopupItem(String text) {
        TextView item = new TextView(this);
        item.setText(text);
        item.setTextSize(14);
        item.setSingleLine(true);
        item.setEllipsize(TextUtils.TruncateAt.END);
        item.setContentDescription(text);
        item.setTextColor(Color.parseColor("#172326"));
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(12), 0, dp(8), 0);
        GradientDrawable base = new GradientDrawable();
        base.setColor(Color.WHITE);
        base.setCornerRadius(dp(10));
        item.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.parseColor("#334F8F8B")), base, null));
        applyPressAnimation(item);
        return item;
    }

    private void selectSite(int slot, Site site) {
        if (site == null) return;
        if (site.hasPassword()) {
            showSitePasswordDialog(site, () -> performSelectSite(slot, site));
        } else {
            performSelectSite(slot, site);
        }
    }

    private WebView webViewForSlot(int slot) {
        return slot == 2 ? webView2 : webView1;
    }

    private void setBrowserLoading(WebView view, boolean loading) {
        if (view == webView1) {
            webView1Loading = loading;
        } else if (view == webView2) {
            webView2Loading = loading;
        } else {
            return;
        }
        if (view == webView) updateLoadingOverlayForActiveSlot();
    }

    private boolean activityResumed;

    private void updateLoadingOverlayForActiveSlot() {
        if (loadingOverlay == null || loadingLogo == null) return;
        boolean loading = activityResumed && (activeSlot == 2 ? webView2Loading : webView1Loading);

        loadingOverlay.animate().cancel();
        if (loading) {
            if (loadingOverlay.getVisibility() != View.VISIBLE) {
                loadingOverlay.setAlpha(0f);
                loadingOverlay.setVisibility(View.VISIBLE);
            }
            startLoadingLogoAnimation();
            loadingOverlay.animate().alpha(1f).setDuration(120).start();
        } else {
            stopLoadingLogoAnimation();
            if (loadingOverlay.getVisibility() == View.VISIBLE) {
                loadingOverlay.animate().alpha(0f).setDuration(150).withEndAction(() -> {
                    if (loadingOverlay != null && !(activeSlot == 2 ? webView2Loading : webView1Loading)) {
                        loadingOverlay.setVisibility(View.GONE);
                    }
                }).start();
            }
        }
    }

    private void startLoadingLogoAnimation() {
        if (loadingLogo == null) return;
        if (loadingLogoAnimator != null && loadingLogoAnimator.isRunning()) return;

        loadingLogo.setScaleX(0.86f);
        loadingLogo.setScaleY(0.86f);
        loadingLogo.setAlpha(0.62f);

        android.animation.ObjectAnimator sx = android.animation.ObjectAnimator.ofFloat(loadingLogo, View.SCALE_X, 0.86f, 1.08f);
        android.animation.ObjectAnimator sy = android.animation.ObjectAnimator.ofFloat(loadingLogo, View.SCALE_Y, 0.86f, 1.08f);
        android.animation.ObjectAnimator alpha = android.animation.ObjectAnimator.ofFloat(loadingLogo, View.ALPHA, 0.62f, 1f);
        sx.setDuration(620);
        sy.setDuration(620);
        alpha.setDuration(620);
        sx.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        sy.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        alpha.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        sx.setRepeatMode(android.animation.ValueAnimator.REVERSE);
        sy.setRepeatMode(android.animation.ValueAnimator.REVERSE);
        alpha.setRepeatMode(android.animation.ValueAnimator.REVERSE);

        loadingLogoAnimator = new android.animation.AnimatorSet();
        loadingLogoAnimator.playTogether(sx, sy, alpha);
        loadingLogoAnimator.start();
    }

    private void stopLoadingLogoAnimation() {
        if (loadingLogoAnimator != null) {
            loadingLogoAnimator.cancel();
            loadingLogoAnimator = null;
        }
        if (loadingLogo != null) {
            loadingLogo.setScaleX(1f);
            loadingLogo.setScaleY(1f);
            loadingLogo.setAlpha(1f);
        }
    }

    private void showWebView(int slot) {
        activeSlot = slot == 2 ? 2 : 1;
        webView = webViewForSlot(activeSlot);
        if (webView != null && activityResumed) webView.onResume();
        if (webView1 != null) webView1.setVisibility(activeSlot == 1 ? View.VISIBLE : View.GONE);
        if (webView2 != null) webView2.setVisibility(activeSlot == 2 ? View.VISIBLE : View.GONE);
        if (slot1DocumentsHome && webView1 != null) {
            boolean visible = activeSlot == 1 && activityResumed;
            webView1.evaluateJavascript(visible
                    ? "window.__stsUiPaused=false;if(typeof loadAllGradually==='function'&&(pendingSort||document.getElementById('q').value))loadAllGradually();"
                    : "window.__stsUiPaused=true;if(window.__stsLoadTimer){clearTimeout(window.__stsLoadTimer);window.__stsLoadTimer=null;}", null);
        }
        updateSlotLabels();
        updateLoadingOverlayForActiveSlot();
        updatePictureInPictureParams();
    }

    private void ensureSlotPageLoaded(int slot) {
        WebView target = webViewForSlot(slot);
        if (target == null || target.getUrl() != null) return;

        String selectedUrl = slot == 2 ? slot2Url : slot1Url;
        Site selected = findSiteByUrl(slot, selectedUrl);
        Runnable load = () -> {
            if (target.getUrl() == null) loadBrowserUrl(target, selectedUrl);
        };
        if (selected != null && selected.hasPassword()) {
            showSitePasswordDialog(selected, load);
        } else {
            load.run();
        }
    }

    private void performSelectSite(int slot, Site site) {
        boolean wasManual = slot == 2 && manualD2Address;
        if (slot == 2) manualD2Address = false;
        finishAddressEditing();
        String previousSelectedUrl = slot == 2 ? slot2Url : slot1Url;
        boolean sameSelection = previousSelectedUrl != null &&
                previousSelectedUrl.equalsIgnoreCase(site.url);
        boolean wasDocumentsHome = slot == 1 && slot1DocumentsHome;
        if (wasDocumentsHome) clearD1WebsiteHistory = true;

        if (slot == 1) {
            slot1DocumentsHome = false;
            documentsLoadGeneration++;
            slot1Name = site.name;
            slot1Url = site.url;
        } else {
            slot2Name = site.name;
            slot2Url = site.url;

        }
        saveSlots();
        showWebView(slot);

        WebView target = webViewForSlot(slot);
        // Selecting the same dropdown site is only a slot switch: keep its exact live page,
        // history, forms and scroll state. A different site selection is an explicit navigation.
        if (wasManual || wasDocumentsHome || !sameSelection || target.getUrl() == null) {
            target.animate().alpha(0.82f).setDuration(80).setListener(new AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(Animator animation) {
                    if (slot == 2) loadBrowserUrl(target, site.url);
                    else target.loadUrl(site.url);
                    target.animate().alpha(1f).setDuration(160).setListener(null).start();
                }
            }).start();
        }
    }

    private void loadInitialPage() {
        showDocumentsHome();
    }

    private void showSitePasswordDialog(Site site, Runnable onSuccess) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(22), dp(18), dp(22), dp(12));

        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(Color.parseColor("#F7FAF9"));
        panelBg.setCornerRadius(dp(18));
        panelBg.setStroke(dp(1), Color.parseColor("#B7CBC8"));
        body.setBackground(panelBg);

        TextView lockBadge = new TextView(this);
        lockBadge.setText("SECURE WEBSITE");
        lockBadge.setTextColor(Color.parseColor("#355C62"));
        lockBadge.setTextSize(11);
        lockBadge.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        lockBadge.setGravity(Gravity.CENTER);
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setColor(Color.parseColor("#D9F0EE"));
        badgeBg.setCornerRadius(dp(12));
        lockBadge.setBackground(badgeBg);
        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(dp(142), dp(28));
        badgeLp.gravity = Gravity.CENTER_HORIZONTAL;
        body.addView(lockBadge, badgeLp);

        TextView title = new TextView(this);
        title.setText(site.name);
        title.setTextColor(Color.parseColor("#172326"));
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(12), 0, dp(4));
        body.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView subtitle = new TextView(this);
        subtitle.setText("Website खोलने के लिए password डालें");
        subtitle.setTextColor(Color.parseColor("#5B676A"));
        subtitle.setTextSize(13);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, dp(14));
        body.addView(subtitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout passRow = new LinearLayout(this);
        passRow.setOrientation(LinearLayout.HORIZONTAL);
        passRow.setGravity(Gravity.CENTER_VERTICAL);
        passRow.setPadding(dp(4), 0, dp(4), 0);
        GradientDrawable passBg = new GradientDrawable();
        passBg.setColor(Color.WHITE);
        passBg.setCornerRadius(dp(12));
        passBg.setStroke(dp(1), Color.parseColor("#8FB5B1"));
        passRow.setBackground(passBg);

        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Password");
        input.setTextColor(Color.parseColor("#172326"));
        input.setHintTextColor(Color.parseColor("#7A8587"));
        input.setTextSize(16);
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setPadding(dp(14), 0, dp(8), 0);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setTransformationMethod(PasswordTransformationMethod.getInstance());

        TextView show = new TextView(this);
        show.setText("SHOW");
        show.setTextColor(Color.parseColor("#4F8F8B"));
        show.setTextSize(12);
        show.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        show.setGravity(Gravity.CENTER);
        show.setPadding(dp(10), 0, dp(10), 0);
        show.setClickable(true);
        show.setFocusable(true);

        final boolean[] visible = {false};
        show.setOnClickListener(v -> {
            int pos = input.getSelectionStart();
            visible[0] = !visible[0];
            if (visible[0]) {
                input.setTransformationMethod(null);
                show.setText("HIDE");
            } else {
                input.setTransformationMethod(PasswordTransformationMethod.getInstance());
                show.setText("SHOW");
            }
            if (pos >= 0) input.setSelection(Math.min(pos, input.length()));
        });

        passRow.addView(input, new LinearLayout.LayoutParams(0, dp(56), 1f));
        passRow.addView(show, new LinearLayout.LayoutParams(dp(66), dp(56)));
        body.addView(passRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

        TextView error = new TextView(this);
        error.setTextColor(Color.parseColor("#8B3D3D"));
        error.setTextSize(12);
        error.setPadding(dp(4), dp(5), dp(4), 0);
        error.setVisibility(View.GONE);
        body.addView(error, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        actions.setPadding(0, dp(6), 0, 0);

        TextView cancel = makePasswordAction("CANCEL", false);
        TextView open = makePasswordAction("OPEN", true);
        LinearLayout.LayoutParams actionLp1 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        actionLp1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams actionLp2 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        actionLp2.setMargins(dp(6), 0, 0, 0);
        actions.addView(cancel, actionLp1);
        actions.addView(open, actionLp2);
        body.addView(actions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(body)
                .create();

        cancel.setOnClickListener(v -> dialog.dismiss());
        open.setOnClickListener(v -> {
            String entered = input.getText().toString();
            if (site.passwordHash.equals(hashPassword(entered))) {
                dialog.dismiss();
                if (onSuccess != null) onSuccess.run();
            } else {
                error.setText("Password गलत है");
                error.setVisibility(View.VISIBLE);
                input.requestFocus();
            }
        });
        input.setOnEditorActionListener((v, actionId, event) -> {
            open.performClick();
            return true;
        });

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
            input.requestFocus();
        });
        dialog.show();
    }

    private TextView makePasswordAction(String text, boolean primary) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setTextColor(primary ? Color.WHITE : Color.parseColor("#355C62"));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(primary ? Color.parseColor("#4F8F8B") : Color.parseColor("#E7EFEE"));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), primary ? Color.parseColor("#3D7774") : Color.parseColor("#AEC7C4"));
        button.setBackground(new RippleDrawable(
                ColorStateList.valueOf(primary ? 0x33FFFFFF : 0x22355C62), bg, null));
        button.setClickable(true);
        button.setFocusable(true);
        return button;
    }

    private boolean handleBrowserIntent(Intent intent) {
        if (intent == null) return false;
        String url = intent.getStringExtra("browser_open_url");
        // Default Browser: ACTION_VIEW BROWSABLE https/http URI, delivered by Android.
        // Keep the existing internal browser_open_url flow and D1 unchanged.
        boolean externalWebLink = Intent.ACTION_VIEW.equals(intent.getAction());
        if (TextUtils.isEmpty(url) && externalWebLink && intent.getData() != null) {
            url = intent.getData().toString();
        }
        if (TextUtils.isEmpty(url)) return false;

        Uri uri;
        try {
            uri = Uri.parse(url);
        } catch (Exception e) {
            return false;
        }
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        if (!"http".equals(scheme) && !"https".equals(scheme)) return false;

        int slot = externalWebLink ? 2 : intent.getIntExtra("browser_slot", activeSlot);
        if (slot != 2) slot = 1;
        if (slot == 1) {
            if (slot1DocumentsHome) clearD1WebsiteHistory = true;
            slot1DocumentsHome = false;
            documentsLoadGeneration++;
        }
        showWebView(slot);
        WebView target = webViewForSlot(slot);
        loadBrowserUrl(target, url);
        return true;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleBrowserIntent(intent);
    }

    private void goHome(int slot) {
        if (slot == 1) {
            showDocumentsHome();
            return;
        }
        showWebView(2);
        WebView target = webViewForSlot(2);
        loadBrowserUrl(target, slot2Url);
    }

    private void refreshSlot(int slot) {
        if (slot == 1 && slot1DocumentsHome) {
            showDocumentsHome();
            return;
        }
        showWebView(slot);
        WebView target = webViewForSlot(slot);
        if (target.getUrl() == null) {
            ensureSlotPageLoaded(slot);
        } else {
            target.reload();
        }
    }

    private void openDownloadsFolder() {
        try {
            Intent intent = new Intent(this, DownloadsActivity.class);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Downloads नहीं खुल पाया", Toast.LENGTH_SHORT).show();
        }
    }

    private void showMainMenu(View anchor) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(2), dp(4), dp(2), dp(4));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), Color.parseColor("#D5DDDC"));
        box.setBackground(bg);

        int popupWidth = measureMainMenuWidth("Ad Blocker", "Download", "Manage Websites", "Close Incognito", "Clear Data", "About");
        android.widget.ScrollView popupScroll = new android.widget.ScrollView(this);
        popupScroll.setFillViewport(false);
        popupScroll.setVerticalScrollBarEnabled(false);
        popupScroll.addView(box);
        PopupWindow popup = new PopupWindow(popupScroll, popupWidth, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(true);
        popup.setElevation(dp(14));
        popup.setAnimationStyle(android.R.style.Animation_Dialog);

        LinearLayout navRow = new LinearLayout(this);
        navRow.setOrientation(LinearLayout.HORIZONTAL);
        navRow.setGravity(Gravity.CENTER_VERTICAL);
        navRow.setPadding(0, dp(1), 0, dp(2));

        ImageButton back = makeHistoryButton(R.drawable.ic_back, "Back");
        ImageButton forward = makeHistoryButton(R.drawable.ic_forward, "Forward");

        WebView active = webView;
        boolean d1Home = activeSlot == 1 && slot1DocumentsHome;
        boolean canBack = !d1Home && active != null && active.canGoBack();
        boolean canForward = !d1Home && active != null && active.canGoForward();
        setHistoryButtonEnabled(back, canBack);
        setHistoryButtonEnabled(forward, canForward);

        back.setOnClickListener(v -> {
            popup.dismiss();
            WebView current = webView;
            if (!(activeSlot == 1 && slot1DocumentsHome) && current != null && current.canGoBack()) {
                current.goBack();
            }
        });
        forward.setOnClickListener(v -> {
            popup.dismiss();
            WebView current = webView;
            if (!(activeSlot == 1 && slot1DocumentsHome) && current != null && current.canGoForward()) {
                current.goForward();
            }
        });

        LinearLayout.LayoutParams navLp1 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        LinearLayout.LayoutParams navLp2 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        navRow.addView(back, navLp1);
        navRow.addView(forward, navLp2);
        box.addView(navRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));

        addMainMenuAction(box, (activeSlot == 2 ? webView2Loading : webView1Loading) ? "Stop loading" : "Refresh", () -> {
            popup.dismiss();
            if (webView != null && (activeSlot == 2 ? webView2Loading : webView1Loading)) {
                webView.stopLoading();
                setBrowserLoading(webView, false);
            } else refreshSlot(activeSlot);
        });
        addMainMenuAction(box, "Ad Blocker", () -> { popup.dismiss(); showAdBlockerDialog(); });
        addMainMenuAction(box, "Download", () -> {
            popup.dismiss();
            openDownloadsFolder();
        });
        addMainMenuAction(box, "Manage Websites", () -> {
            popup.dismiss();
            showManageSitesDialog();
        });
        addMainMenuAction(box, "Incognito", () -> {
            popup.dismiss();
            if (Build.VERSION.SDK_INT >= 28) {
                startActivity(new Intent(this, PrivateBrowserActivity.class));
            } else {
                new AlertDialog.Builder(this).setTitle("Incognito")
                        .setMessage("अलग सुरक्षित private profile के लिए Android 9 या नया version चाहिए। सामान्य login को बदले बिना इस फोन पर Incognito उपलब्ध नहीं है।")
                        .setPositiveButton("OK", null).show();
            }
        });
        addMainMenuAction(box, "Clear Data", () -> {
            popup.dismiss();
            showClearDataDialog();
        });
        addMainMenuAction(box, "About", () -> {
            popup.dismiss();
            showAboutDialog();
        });

        int xOff = anchor.getWidth() - popupWidth;
        fitPopupHeight(popup, box, anchor, popupWidth);
        popup.showAsDropDown(anchor, xOff, dp(2));
    }

    private int measureMainMenuWidth(String... labels) {
        TextView probe = new TextView(this);
        probe.setTextSize(15);
        probe.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));

        float widest = 0f;
        if (labels != null) {
            for (String label : labels) {
                if (label == null) continue;
                widest = Math.max(widest, probe.getPaint().measureText(label));
            }
        }

        // 10dp left text inset + 2dp outer padding on each side + tiny rounding safety.
        // The longest label therefore finishes almost at the popup's right edge.
        return Math.max(dp(96), (int) Math.ceil(widest) + dp(16));
    }

    private ImageButton makeHistoryButton(int iconRes, String description) {
        ImageButton button = new ImageButton(this);
        button.setImageResource(iconRes);
        button.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        button.setPadding(dp(10), dp(2), dp(10), dp(2));
        button.setScaleType(ImageView.ScaleType.FIT_CENTER);
        button.setColorFilter(Color.parseColor("#263C40"));
        button.setContentDescription(description);
        button.setBackground(new RippleDrawable(
                ColorStateList.valueOf(Color.parseColor("#18000000")),
                new ColorDrawable(Color.TRANSPARENT),
                null));
        applyPressAnimation(button);
        return button;
    }

    private void setHistoryButtonEnabled(ImageButton button, boolean enabled) {
        button.setEnabled(enabled);
        button.setAlpha(enabled ? 1f : 0.55f);
    }

    private void addMainMenuAction(LinearLayout box, String label, Runnable action) {
        TextView item = new TextView(this);
        item.setText(label);
        item.setTextColor(Color.parseColor("#172326"));
        item.setTextSize(15);
        item.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        item.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_START);
        item.setSingleLine(true);
        item.setMaxLines(1);
        item.setHorizontallyScrolling(true);
        item.setEllipsize(null);
        item.setPadding(dp(10), 0, 0, 0);
        item.setBackground(new RippleDrawable(
                ColorStateList.valueOf(Color.parseColor("#224F8F8B")),
                new ColorDrawable(Color.TRANSPARENT),
                null));
        item.setClickable(true);
        item.setFocusable(true);
        item.setOnClickListener(v -> {
            if (action != null) action.run();
        });
        applyPressAnimation(item);
        box.addView(item, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
    }

    private void showAddWebsiteDialog(int slot) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20), dp(8), dp(20), 0);

        EditText name = new EditText(this);
        name.setHint("Website name");
        name.setSingleLine(true);
        EditText url = new EditText(this);
        url.setHint("URL (example.com)");
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        body.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        body.addView(url, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Add Website")
                .setView(body)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            String u = normalizeUrl(url.getText().toString().trim());
            if (n.isEmpty() || u == null) {
                Toast.makeText(this, "Name और सही URL डालें", Toast.LENGTH_SHORT).show();
                return;
            }
            Site s = new Site(n, u, "");
            List<Site> target = getSites(slot);
            if (containsUrl(sitesD1, u) || containsUrl(sitesD2, u)) {
                Toast.makeText(this, "यह website इस dropdown में पहले से है", Toast.LENGTH_SHORT).show();
                return;
            }
            target.add(s);
            saveSites(slot);
            dialog.dismiss();
            selectSite(slot, s);
        }));
        dialog.show();
    }

    private void showAdBlockerDialog() {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20), dp(8), dp(20), dp(8));
        android.widget.Switch normal = new android.widget.Switch(this);
        normal.setText("Normal"); normal.setChecked(adBlockEnabled);
        android.widget.Switch hard = new android.widget.Switch(this);
        hard.setText("Hard"); hard.setChecked(hardAdBlockEnabled);
        body.addView(normal, new LinearLayout.LayoutParams(-1, dp(52)));
        body.addView(hard, new LinearLayout.LayoutParams(-1, dp(52)));
        normal.setOnCheckedChangeListener((button, enabled) -> setAdBlockEnabled(enabled, true));
        hard.setOnCheckedChangeListener((button, enabled) -> setHardAdBlockEnabled(enabled, true));
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Ad Blocker")
                .setView(body).setPositiveButton("Close", null).create();
        
        dialog.show();
    }

    private void showManageSitesDialog() {
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(10), dp(8), dp(10), dp(8));

        addManageSection(list);

        ScrollView sc = new ScrollView(this);
        sc.addView(list);
        if (manageSitesDialog != null && manageSitesDialog.isShowing()) {
            manageSitesDialog.dismiss();
        }
        manageSitesDialog = new AlertDialog.Builder(this)
                .setTitle("Manage Websites")
                .setNeutralButton("Add Website", (d, which) -> showAddWebsiteDialog(2))
                .setView(sc)
                .setPositiveButton("Close", null)
                .create();
        manageSitesDialog.setOnDismissListener(d -> { if (manageSitesDialog == d) manageSitesDialog = null; });
        manageSitesDialog.show();
    }

    private List<Site> orderedCustomSites() {
        List<Site> result = new ArrayList<>();
        result.addAll(sitesD1.subList(Math.min(1, sitesD1.size()), sitesD1.size()));
        result.addAll(sitesD2.subList(Math.min(1, sitesD2.size()), sitesD2.size()));
        java.util.Collections.sort(result, (a, b) -> Integer.compare(a.order, b.order));
        return result;
    }

    private int siteOwner(Site site) { return sitesD1.contains(site) ? 1 : 2; }

    private void addManageSection(LinearLayout list) {
        List<Site> source = orderedCustomSites();
        if (source.isEmpty()) {
            TextView none = new TextView(this);
            none.setText("Custom website अभी add नहीं है");
            none.setTextColor(Color.DKGRAY);
            none.setTextSize(13);
            none.setPadding(dp(12), dp(6), dp(8), dp(10));
            list.addView(none, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
            return;
        }

        for (int i = 0; i < source.size(); i++) {
            Site s = source.get(i);
            final int slot = siteOwner(s);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(2), dp(2), dp(2), dp(2));

            TextView title = new TextView(this);
            title.setText(s.name + (s.hasPassword() ? "  🔒" : ""));
            title.setTextColor(Color.parseColor("#172326"));
            title.setTextSize(13);
            title.setPadding(dp(8), dp(4), dp(6), dp(4));

            ImageButton more = new ImageButton(this);
            more.setImageResource(R.drawable.ic_more);
            more.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            more.setPadding(dp(10), dp(10), dp(10), dp(10));
            more.setBackgroundColor(Color.TRANSPARENT);
            more.setContentDescription("Website options");

            row.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1f));
            row.addView(more, new LinearLayout.LayoutParams(dp(48), dp(48)));
            more.setOnClickListener(v -> showManagedSiteMenu(v, s, slot, title));

            list.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        }
    }

    private void showManagedSiteMenu(View anchor, Site site, int slot, TextView titleView) {
        CompactPopupMenu pm = new CompactPopupMenu(this, anchor, Gravity.END);
        pm.getMenu().add("Open Website");
        pm.getMenu().add("Edit");
        pm.getMenu().add(site.hasPassword() ? "Change Password" : "Set Password");

        List<Site> currentSites = orderedCustomSites();
        int currentIndex = currentSites.indexOf(site);
        android.view.MenuItem moveUp = pm.getMenu().add("Move Up");
        android.view.MenuItem moveDown = pm.getMenu().add("Move Down");
        moveUp.setEnabled(currentIndex > 0);
        moveDown.setEnabled(currentIndex >= 0 && currentIndex < currentSites.size() - 1);

        pm.getMenu().add("Remove Website");
        pm.setOnMenuItemClickListener(item -> {
            String t = String.valueOf(item.getTitle());
            if (t.equals("Open Website")) {
                if (manageSitesDialog != null) manageSitesDialog.dismiss();
                selectSite(slot, site);
                return true;
            }
            if (t.equals("Edit")) {
                Runnable openEditor = () -> showEditWebsiteDialog(site, slot, titleView);
                if (site.hasPassword()) {
                    showSitePasswordDialog(site, openEditor);
                } else {
                    openEditor.run();
                }
                return true;
            }
            if (t.equals("Set Password") || t.equals("Change Password")) {
                Runnable change = () -> showSetSitePasswordDialog(site, slot);
                if (site.hasPassword()) showSitePasswordDialog(site, change); else change.run();
                return true;
            }
            if (t.equals("Move Up")) {
                reorderSite(site, slot, -1);
                return true;
            }
            if (t.equals("Move Down")) {
                reorderSite(site, slot, 1);
                return true;
            }
            if (t.equals("Remove Website")) {
                confirmDeleteSite(site, slot);
                return true;
            }
            return false;
        });
        pm.show();
    }

    private void showEditWebsiteDialog(Site site, int slot, TextView titleView) {
        if (site == null) return;

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20), dp(8), dp(20), 0);

        EditText name = new EditText(this);
        name.setHint("Website name");
        name.setSingleLine(true);
        name.setText(site.name);

        EditText url = new EditText(this);
        url.setHint("URL (example.com)");
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setText(site.url);

        body.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        body.addView(url, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit Website")
                .setView(body)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String newName = name.getText().toString().trim();
            String newUrl = normalizeUrl(url.getText().toString().trim());
            if (newName.isEmpty() || newUrl == null) {
                Toast.makeText(this, "Name और सही URL डालें", Toast.LENGTH_SHORT).show();
                return;
            }

            List<Site> allSites = new ArrayList<>(sitesD1);
            allSites.addAll(sitesD2);
            for (Site other : allSites) {
                if (!newUrl.equalsIgnoreCase(site.url) && other != site && newUrl.equalsIgnoreCase(other.url)) {
                    Toast.makeText(this, "यह website इस dropdown में पहले से है", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            String oldUrl = site.url;
            site.name = newName;
            site.url = newUrl;
            saveSites(slot);

            if (slot == 1 && oldUrl.equals(slot1Url)) {
                slot1Name = newName;
                slot1Url = newUrl;
            } else if (slot == 2 && oldUrl.equals(slot2Url)) {
                slot2Name = newName;
                slot2Url = newUrl;
            }
            saveSlots();
            updateSlotLabels();

            if (titleView != null) {
                titleView.setText(site.name + (site.hasPassword() ? "  🔒" : ""));
            }

            dialog.dismiss();
            Toast.makeText(this, "Website updated", Toast.LENGTH_SHORT).show();
        }));
        dialog.show();
    }

    private void showSetSitePasswordDialog(Site site, int slot) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(4), dp(18), 0);

        EditText pass1 = new EditText(this);
        pass1.setHint("New password");
        pass1.setSingleLine(true);
        pass1.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText pass2 = new EditText(this);
        pass2.setHint("Confirm password");
        pass2.setSingleLine(true);
        pass2.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        body.addView(pass1, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        body.addView(pass2, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(site.hasPassword() ? "Change Password" : "Set Password")
                .setView(body)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String p1 = pass1.getText().toString();
            String p2 = pass2.getText().toString();
            if (p1.length() < 4) {
                pass1.setError("कम से कम 4 अक्षर");
                return;
            }
            if (!p1.equals(p2)) {
                pass2.setError("Password match नहीं है");
                return;
            }
            site.passwordHash = hashPassword(p1);
            saveSites(slot);
            dialog.dismiss();
            if (manageSitesDialog != null) showManageSitesDialog();
            Toast.makeText(this, "Password saved", Toast.LENGTH_SHORT).show();
        }));
        dialog.show();
    }

    private void reorderSite(Site site, int slot, int direction) {
        List<Site> sites = orderedCustomSites();
        int from = sites.indexOf(site), to = from + direction;
        if (from < 0 || to < 0 || to >= sites.size()) return;
        java.util.Collections.swap(sites, from, to);
        for (int i = 0; i < sites.size(); i++) sites.get(i).order = i;
        saveSites(1);
        saveSites(2);
        showManageSitesDialog();
    }

    private void confirmDeleteSite(Site site, int slot) {
        new AlertDialog.Builder(this)
                .setTitle("Remove " + site.name + "?")
                .setMessage("इस website को list से हटाना है?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Remove", (d, w) -> {
                    getSites(slot).remove(site);
                    if (slot == 1 && slot1Url.equals(site.url)) {
                        slot1Name = GOOGLE_NAME;
                        slot1Url = GOOGLE_URL;
                    }
                    if (slot == 2 && slot2Url.equals(site.url)) {
                        slot2Name = GOOGLE_NAME;
                        slot2Url = GOOGLE_URL;
                    }
                    saveSites(slot);
                    saveSlots();
                    updateSlotLabels();
                    if (manageSitesDialog != null) showManageSitesDialog();
                    Toast.makeText(this, "Website removed", Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void showClearDataDialog() {
        String[] options = new String[] {
                "Clear Cache / Temporary Data",
                "Clear All Browser Data"
        };

        new AlertDialog.Builder(this)
                .setTitle("Clear Data")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        clearBrowserCacheKeepLogin();
                    } else if (which == 1) {
                        confirmClearAllBrowserData();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void clearBrowserCacheKeepLogin() {
        try {
            if (webView1 != null) webView1.clearCache(true);
            if (webView2 != null) webView2.clearCache(true);
            synchronized (phoneDataThumbCache) {
                phoneDataThumbCache.evictAll();
            }
            // Deliberately do NOT clear cookies, WebStorage, IndexedDB or session/site storage.
            CookieManager.getInstance().flush();
            Toast.makeText(this, "Cache cleared • Login saved", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Cache clear नहीं हो पाया", Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmClearAllBrowserData() {
        new AlertDialog.Builder(this)
                .setTitle("Clear All Browser Data?")
                .setMessage("इससे cache के साथ cookies, login/session और website storage भी हट जाएगा। Websites से logout हो सकते हैं।")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear All", (dialog, which) -> clearAllBrowserData())
                .show();
    }

    private void clearAllBrowserData() {
        try {
            if (webView1 != null) {
                webView1.stopLoading();
                webView1.clearCache(true);
                webView1.clearHistory();
                webView1.clearFormData();
                webView1.clearSslPreferences();
            }
            if (webView2 != null) {
                webView2.stopLoading();
                webView2.clearCache(true);
                webView2.clearHistory();
                webView2.clearFormData();
                webView2.clearSslPreferences();
            }

            WebStorage.getInstance().deleteAllData();

            WebViewDatabase db = WebViewDatabase.getInstance(this);
            if (db != null) {
                db.clearFormData();
                db.clearHttpAuthUsernamePassword();
                db.clearUsernamePassword();
            }

            CookieManager cookies = CookieManager.getInstance();
            cookies.removeSessionCookies(null);
            cookies.removeAllCookies(value -> {
                try { cookies.flush(); } catch (Exception ignored) {}
                runOnUiThread(() -> {
                    if (webView1 != null) webView1.loadUrl("about:blank");
                    if (webView2 != null) webView2.loadUrl("about:blank");
                    webView1Loading = false;
                    webView2Loading = false;
                    updateLoadingOverlayForActiveSlot();
                    Toast.makeText(this, "All browser data cleared", Toast.LENGTH_SHORT).show();
                });
            });

            synchronized (phoneDataThumbCache) {
                phoneDataThumbCache.evictAll();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Browser data clear नहीं हो पाया", Toast.LENGTH_SHORT).show();
        }
    }

    private String currentAppVersion() {
        try {
            android.content.pm.PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            return info.versionName == null ? "" : info.versionName;
        } catch (Exception e) {
            return "";
        }
    }

    private void showAboutDialog() {
        String webViewVersion = prefs == null ? "" : prefs.getString(KEY_LAST_HEALTH_WEBVIEW, "");
        String health = TextUtils.isEmpty(webViewVersion)
                ? "WebView health: available"
                : "WebView: " + webViewVersion;
        new AlertDialog.Builder(this)
                .setTitle("STS Fast Browser")
                .setMessage("Version " + currentAppVersion() +
                        "\n\nSimple • Fast • Two Quick Slots" +
                        "\nLong-Life protection: ON" +
                        "\n" + health +
                        "\n\nAd Blocker opens Normal and Hard ON/OFF controls." +
                        "\n\nCreated by Sanchit Kumar" +
                        "\n© 2026 STS Fast Browser. All Rights Reserved.")
                .setPositiveButton("OK", null)
                .show();
    }

    private String buildBackupJson() {
        try {
            JSONObject root = new JSONObject();
            root.put("format", "STS_FAST_BROWSER_BACKUP");
            root.put("schema", 1);
            root.put("appVersion", currentAppVersion());
            root.put("sitesD1", new JSONArray(prefs.getString(KEY_SITES_D1, "[]")));
            root.put("sitesD2", new JSONArray(prefs.getString(KEY_SITES_D2, "[]")));
            root.put("slot1Name", prefs.getString(KEY_SLOT1_NAME, GOOGLE_NAME));
            root.put("slot1Url", prefs.getString(KEY_SLOT1_URL, GOOGLE_URL));
            root.put("slot2Name", prefs.getString(KEY_SLOT2_NAME, GOOGLE_NAME));
            root.put("slot2Url", prefs.getString(KEY_SLOT2_URL, GOOGLE_URL));
            root.put("adBlock", prefs.getBoolean(KEY_ADBLOCK, true));
            root.put("hardAdBlock", prefs.getBoolean(KEY_HARD_ADBLOCK, true));
            return root.toString(2);
        } catch (Exception e) {
            return "";
        }
    }

    private JSONArray sanitizeBackupSites(JSONArray input) {
        JSONArray clean = new JSONArray();
        if (input == null) return clean;
        int limit = Math.min(input.length(), 500);
        for (int i = 0; i < limit; i++) {
            JSONObject item = input.optJSONObject(i);
            if (item == null) continue;
            String name = item.optString("name", "").trim();
            String url = normalizeUrl(item.optString("url", "").trim());
            String passwordHash = item.optString("passwordHash", "");
            if (name.length() > 120) name = name.substring(0, 120);
            if (passwordHash.length() > 256) passwordHash = "";
            if (name.isEmpty() || url == null || GOOGLE_URL.equalsIgnoreCase(url)) continue;
            try {
                JSONObject safe = new JSONObject();
                safe.put("name", name);
                safe.put("url", url);
                safe.put("passwordHash", passwordHash);
                clean.put(safe);
            } catch (Exception ignored) {}
        }
        return clean;
    }

    private boolean applyBackupJsonToPrefs(String json) {
        if (prefs == null || TextUtils.isEmpty(json)) return false;
        try {
            JSONObject root = new JSONObject(json);
            if (!"STS_FAST_BROWSER_BACKUP".equals(root.optString("format", ""))) return false;
            if (root.optInt("schema", 0) < 1) return false;

            JSONArray d1 = sanitizeBackupSites(root.optJSONArray("sitesD1"));
            JSONArray d2 = sanitizeBackupSites(root.optJSONArray("sitesD2"));

            String s1Name = root.optString("slot1Name", GOOGLE_NAME).trim();
            String s2Name = root.optString("slot2Name", GOOGLE_NAME).trim();
            if (s1Name.isEmpty() || s1Name.length() > 120) s1Name = GOOGLE_NAME;
            if (s2Name.isEmpty() || s2Name.length() > 120) s2Name = GOOGLE_NAME;

            String s1Url = normalizeUrl(root.optString("slot1Url", GOOGLE_URL));
            String s2Url = normalizeUrl(root.optString("slot2Url", GOOGLE_URL));
            if (s1Url == null) s1Url = GOOGLE_URL;
            if (s2Url == null) s2Url = GOOGLE_URL;

            prefs.edit()
                    .putString(KEY_SITES_D1, d1.toString())
                    .putString(KEY_SITES_D2, d2.toString())
                    .putString(KEY_SLOT1_NAME, s1Name)
                    .putString(KEY_SLOT1_URL, s1Url)
                    .putString(KEY_SLOT2_NAME, s2Name)
                    .putString(KEY_SLOT2_URL, s2Url)
                    .putBoolean(KEY_ADBLOCK, root.optBoolean("adBlock", true))
                    .putBoolean(KEY_HARD_ADBLOCK, root.optBoolean("hardAdBlock", true))
                    .putBoolean(KEY_SITES_MIGRATED, true)
                    .commit();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void markStartupHealthy() {
        String backup = buildBackupJson();
        SharedPreferences.Editor editor = prefs.edit().putBoolean(KEY_STARTUP_PENDING, false);
        if (!TextUtils.isEmpty(backup)) {
            editor.putString(KEY_LAST_GOOD_CONFIG, backup);
        }
        editor.apply();
    }

    private void runSilentHealthCheck() {
        new Thread(() -> {
            String webViewInfo = "available";
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    android.content.pm.PackageInfo info = WebView.getCurrentWebViewPackage();
                    if (info != null) {
                        webViewInfo = info.packageName + " " + info.versionName;
                    }
                }
            } catch (Exception ignored) {}

            try {
                long usable = getFilesDir().getUsableSpace();
                String finalWebViewInfo = usable < (20L * 1024L * 1024L)
                        ? webViewInfo + " • low storage"
                        : webViewInfo;
                prefs.edit()
                        .putString(KEY_LAST_HEALTH_WEBVIEW, finalWebViewInfo)
                        .putLong(KEY_LAST_HEALTH_TIME, System.currentTimeMillis())
                        .apply();
            } catch (Exception ignored) {}
        }, "SFB-Health").start();
    }

    private void showSafeStartupScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(28), dp(28), dp(28));
        root.setBackgroundColor(Color.parseColor("#F2F5F4"));

        TextView title = new TextView(this);
        title.setText("STS Fast Browser");
        title.setTextSize(24);
        title.setTextColor(Color.parseColor("#172326"));
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView message = new TextView(this);
        message.setText("Browser component अभी start नहीं हो पाया। App data delete नहीं किया गया है। Retry करने पर last known good settings के साथ फिर से start होगा।");
        message.setTextSize(14);
        message.setTextColor(Color.parseColor("#39484B"));
        message.setGravity(Gravity.CENTER);
        message.setPadding(0, dp(16), 0, dp(18));
        root.addView(message, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView retry = makeTopButton("Retry", Color.parseColor("#BFE3DF"));
        retry.setOnClickListener(v -> recreate());
        LinearLayout.LayoutParams retryLp = new LinearLayout.LayoutParams(dp(150), dp(48));
        retryLp.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(retry, retryLp);
        setContentView(root);
    }

    private void exportSettingsBackup() {
        try {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE, "STS-Fast-Browser-Backup.json");
            startActivityForResult(intent, REQ_EXPORT_SETTINGS);
        } catch (Exception e) {
            Toast.makeText(this, "Backup file नहीं बन पाई", Toast.LENGTH_SHORT).show();
        }
    }

    private void importSettingsBackup() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            startActivityForResult(intent, REQ_IMPORT_SETTINGS);
        } catch (Exception e) {
            Toast.makeText(this, "Backup file open नहीं हो पाई", Toast.LENGTH_SHORT).show();
        }
    }

    private String readSmallUtf8File(Uri uri, int maxBytes) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new Exception("Missing input");
            byte[] buffer = new byte[8192];
            int total = 0;
            int n;
            while ((n = in.read(buffer)) > 0) {
                total += n;
                if (total > maxBytes) throw new Exception("Backup too large");
                out.write(buffer, 0, n);
            }
            return out.toString("UTF-8");
        }
    }

    private void writeSettingsBackup(Uri uri) {
        new Thread(() -> {
            try {
                String json = buildBackupJson();
                if (TextUtils.isEmpty(json)) throw new Exception("Empty backup");
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                    if (out == null) throw new Exception("Missing output");
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
                runOnUiThread(() -> Toast.makeText(
                        this, "Settings backup save हो गया", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(
                        this, "Settings backup नहीं हो पाया", Toast.LENGTH_SHORT).show());
            }
        }, "SFB-Backup").start();
    }

    private void restoreSettingsBackup(Uri uri) {
        new Thread(() -> {
            try {
                String json = readSmallUtf8File(uri, 2 * 1024 * 1024);
                if (!applyBackupJsonToPrefs(json)) throw new Exception("Invalid backup");

                runOnUiThread(() -> {
                    try {
                        adBlockEnabled = prefs.getBoolean(KEY_ADBLOCK, true);
                        hardAdBlockEnabled = prefs.getBoolean(KEY_HARD_ADBLOCK, true);
                        loadSites();
                        loadSlots();
                        if (webView2 != null) {
                            webView2.loadUrl(slot2Url);
                        }
                        slot1DocumentsHome = true;
                        phoneDataMode = "Documents";
                        showDocumentsHome();
                        updateSlotLabels();
                        markStartupHealthy();
                        Toast.makeText(this, "Settings restore हो गई", Toast.LENGTH_LONG).show();
                    } catch (Exception e) {
                        Toast.makeText(this, "Restore apply नहीं हो पाया", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(
                        this, "यह valid STS Fast Browser backup नहीं है", Toast.LENGTH_LONG).show());
            }
        }, "SFB-Restore").start();
    }

    private void setAdBlockEnabled(boolean enabled, boolean showToast) {
        adBlockEnabled = enabled;
        prefs.edit().putBoolean(KEY_ADBLOCK, enabled).apply();

        if (enabled) {
            if (webView1 != null) injectNormalAdCleanup(webView1);
            if (webView2 != null) injectNormalAdCleanup(webView2);
        }

        if (showToast) {
            Toast.makeText(this,
                    enabled ? "Ad Blocker ON" : "Ad Blocker OFF",
                    Toast.LENGTH_SHORT).show();
        }

        // The toggle is an explicit user action. Reload only the visible slot so
        // network-level blocking starts immediately without disturbing hidden D1/D2 state.
        if (webView != null) webView.reload();
    }

    private void setHardAdBlockEnabled(boolean enabled, boolean showToast) {
        hardAdBlockEnabled = enabled;
        prefs.edit().putBoolean(KEY_HARD_ADBLOCK, enabled).apply();

        if (enabled) {
            if (webView1 != null) injectHardAdCleanup(webView1);
            if (webView2 != null) injectHardAdCleanup(webView2);
        }

        if (showToast) {
            Toast.makeText(this,
                    enabled ? "Hard Ad Blocker ON" : "Hard Ad Blocker OFF",
                    Toast.LENGTH_SHORT).show();
        }

        if (webView != null) webView.reload();
    }

    private void updateSlotLabels() {
        if (slot1Button != null) {
            String label = activeSlot == 1 ? (slot1DocumentsHome ? "Phone Data" : slot1Name)
                    : (manualD2Address ? "Websites" : slot2Name);
            slot1Button.setText(label);
            slot1Button.setContentDescription("Websites: " + label);
        }
        syncD2AddressBar(null);
    }

    private boolean shouldShowAddressSearch() {
        return slot2Button != null && slot2Button.hasFocus() && addressEdited
                && !slot2Button.getText().toString().trim().isEmpty();
    }

    private void updateAddressAction() {
        if (slot1RefreshIcon == null) return;
        boolean search = shouldShowAddressSearch();
        slot1RefreshIcon.setImageResource(search ? R.drawable.ic_search : R.drawable.ic_refresh);
        slot1RefreshIcon.setContentDescription(search ? "Open address or search" : "Refresh current page");
    }

    private void performAddressAction() {
        if (shouldShowAddressSearch()) navigateD2Address(slot2Button.getText().toString());
        else {
            finishAddressEditing();
            refreshSlot(activeSlot);
        }
    }

    private void finishAddressEditing() {
        if (slot2Button == null) return;
        android.view.inputmethod.InputMethodManager keyboard =
                (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (keyboard != null) keyboard.hideSoftInputFromWindow(slot2Button.getWindowToken(), 0);
        addressEdited = false;
        slot2Button.clearFocus();
        updateAddressAction();
    }

    private String toHttpsUrl(String url) {
        if (TextUtils.isEmpty(url) || !url.regionMatches(true, 0, "http://", 0, 7)) return null;
        return "https://" + url.substring(7);
    }

    private void loadBrowserUrl(WebView target, String url) {
        if (target == null || TextUtils.isEmpty(url)) return;
        if (target == webView2 && url.regionMatches(true, 0, "http://", 0, 7)) {
            String httpsUrl = toHttpsUrl(url);
            if (!TextUtils.isEmpty(httpsUrl)) {
                d2HttpsUpgradeSource = url;
                d2HttpsUpgradeTarget = httpsUrl;
                d2AllowHttpOnce = false;
                target.loadUrl(httpsUrl);
                return;
            }
        }
        target.loadUrl(url);
    }

    private boolean retryOriginalHttpAfterHttpsFailure(WebView view, String failedUrl) {
        if (view != webView2 || TextUtils.isEmpty(failedUrl) ||
                TextUtils.isEmpty(d2HttpsUpgradeTarget) || TextUtils.isEmpty(d2HttpsUpgradeSource) ||
                !failedUrl.equalsIgnoreCase(d2HttpsUpgradeTarget)) {
            return false;
        }

        String fallback = d2HttpsUpgradeSource;
        d2HttpsUpgradeTarget = null;
        d2HttpsUpgradeSource = null;
        d2AllowHttpOnce = true;
        view.post(() -> view.loadUrl(fallback));
        return true;
    }

    private void syncD2AddressBar(String url) {
        if (slot2Button == null || slot2Button.hasFocus()) return;
        if (activeSlot != 2 || !manualD2Address) {
            slot2Button.setText("");
            return;
        }
        if (!TextUtils.isEmpty(url)) manualAddressShown = url;
        slot2Button.setText(manualAddressShown);
        slot2Button.setSelection(0);
    }

    private void navigateD2Address(String raw) {
        if (raw == null) return;
        String input = raw.trim();
        if (input.isEmpty()) return;

        String destination = null;
        boolean looksLikeUrl =
                input.matches("(?i)^[a-z][a-z0-9+.-]*://.+$") ||
                input.matches("(?i)^localhost(?::\\d+)?(?:/.*)?$") ||
                input.matches("(?i)^\\d{1,3}(?:\\.\\d{1,3}){3}(?::\\d+)?(?:/.*)?$") ||
                (!input.contains(" ") && input.contains("."));

        if (looksLikeUrl) destination = normalizeUrl(input);
        if (destination == null) {
            destination = "https://www.google.com/search?q=" + Uri.encode(input);
        }

        manualAddressShown = destination;
        manualD2Address = true;
        finishAddressEditing();
        showWebView(2);
        if (webView2 != null) loadBrowserUrl(webView2, destination);
    }

    private List<Site> getSites(int slot) {
        return slot == 2 ? sitesD2 : sitesD1;
    }

    private boolean containsUrl(List<Site> list, String url) {
        for (Site s : list) {
            if (s.url.equalsIgnoreCase(url)) return true;
        }
        return false;
    }

    private Site findSiteByUrl(int slot, String url) {
        if (url == null) return null;
        for (Site s : getSites(slot)) {
            if (s.url.equalsIgnoreCase(url)) return s;
        }
        return null;
    }

    private void loadSites() {
        sitesD1.clear();
        sitesD2.clear();
        sitesD1.add(new Site(GOOGLE_NAME, GOOGLE_URL, ""));
        sitesD2.add(new Site(GOOGLE_NAME, GOOGLE_URL, ""));

        boolean splitExists = prefs.contains(KEY_SITES_D1) || prefs.contains(KEY_SITES_D2);
        if (splitExists) {
            loadSiteList(KEY_SITES_D1, sitesD1);
            loadSiteList(KEY_SITES_D2, sitesD2);
            return;
        }

        // One-time migration from the old shared website list.
        String legacy = prefs.getString(KEY_SITES, "[]");
        try {
            JSONArray arr = new JSONArray(legacy);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String n = o.optString("name", "").trim();
                String u = normalizeUrl(o.optString("url", "").trim());
                if (!n.isEmpty() && u != null && !GOOGLE_URL.equalsIgnoreCase(u)) {
                    sitesD1.add(new Site(n, u, ""));
                    sitesD2.add(new Site(n, u, ""));
                }
            }
        } catch (Exception ignored) {}
        saveSites(1);
        saveSites(2);
        prefs.edit().putBoolean(KEY_SITES_MIGRATED, true).apply();
    }

    private void loadSiteList(String key, List<Site> target) {
        String json = prefs.getString(key, "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String n = o.optString("name", "").trim();
                String u = normalizeUrl(o.optString("url", "").trim());
                String p = o.optString("passwordHash", "");
                if (!n.isEmpty() && u != null && !GOOGLE_URL.equalsIgnoreCase(u)) {
                    Site site = new Site(n, u, p);
                    site.order = o.optInt("order", Integer.MAX_VALUE);
                    target.add(site);
                }
            }
        } catch (Exception ignored) {}
    }

    private void saveSites(int slot) {
        JSONArray arr = new JSONArray();
        List<Site> source = getSites(slot);
        try {
            for (int i = 1; i < source.size(); i++) {
                Site s = source.get(i);
                JSONObject o = new JSONObject();
                o.put("order", s.order);
                o.put("name", s.name);
                o.put("url", s.url);
                o.put("passwordHash", s.passwordHash == null ? "" : s.passwordHash);
                arr.put(o);
            }
        } catch (Exception ignored) {}
        prefs.edit().putString(slot == 2 ? KEY_SITES_D2 : KEY_SITES_D1, arr.toString()).apply();
    }

    private String hashPassword(String raw) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] out = digest.digest((raw == null ? "" : raw).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : out) sb.append(String.format(Locale.ROOT, "%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return raw == null ? "" : raw;
        }
    }

    private void loadSlots() {
        slot1Name = prefs.getString(KEY_SLOT1_NAME, GOOGLE_NAME);
        slot1Url = prefs.getString(KEY_SLOT1_URL, GOOGLE_URL);
        slot2Name = prefs.getString(KEY_SLOT2_NAME, GOOGLE_NAME);
        slot2Url = prefs.getString(KEY_SLOT2_URL, GOOGLE_URL);
    }

    private void saveSlots() {
        prefs.edit()
                .putString(KEY_SLOT1_NAME, slot1Name).putString(KEY_SLOT1_URL, slot1Url)
                .putString(KEY_SLOT2_NAME, slot2Name).putString(KEY_SLOT2_URL, slot2Url)
                .apply();
    }

    private String normalizeUrl(String raw) {
        if (raw == null) return null;
        raw = raw.trim();
        if (raw.isEmpty()) return null;
        if (!raw.matches("(?i)^[a-z][a-z0-9+.-]*://.*$")) raw = "https://" + raw;
        try {
            Uri u = Uri.parse(raw);
            String scheme = u.getScheme();
            String host = u.getHost();
            if (scheme == null || host == null) return null;
            if (!(scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https"))) return null;
            return u.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }

    private int darken(int color, float amount) {
        int r = Math.max(0, (int)(Color.red(color) * (1f - amount)));
        int g = Math.max(0, (int)(Color.green(color) * (1f - amount)));
        int b = Math.max(0, (int)(Color.blue(color) * (1f - amount)));
        return Color.rgb(r, g, b);
    }


    // ---------------- Built-in D1 Documents home ----------------

    private void showDocumentsHome() {
        phoneBackPending = false;
        clearD1WebsiteHistory = false;
        slot1DocumentsHome = true;
        showWebView(1);
        updateSlotLabels();
        final int generation = ++documentsLoadGeneration;
        final String selectedMode = phoneDataMode;

        String loading = documentsShellHtml(
                "<div class='center'><div class='spinner'></div><div>" + escapeDocsHtml(selectedMode) + " loading...</div></div>",
                0, false, selectedMode);
        webView1.loadDataWithBaseURL("https://sts.documents/", loading, "text/html", "UTF-8", null);

        new Thread(() -> {
            String htmlResult;
            try {
            if (!hasDocumentAccess()) {
                phoneDataSnapshot = new ArrayList<>();
                phoneDataSnapshotGeneration = generation;
                phoneDataSnapshotMode = selectedMode;
                htmlResult = documentsShellHtml(
                        "<div class='permission'><div class='folder'>▣</div>" +
                        "<h2>Phone Data</h2>" +
                        "<p>Documents, photos, videos और other files दिखाने के लिए file access Allow करें।</p>" +
                        "<button onclick='STSDocuments.requestAccess()'>Allow File Access</button></div>",
                        0, true, selectedMode);
            } else {
                List<DocumentEntry> entries = queryPhoneData(selectedMode, generation);
                if (generation != documentsLoadGeneration || !selectedMode.equals(phoneDataMode)) return;
                phoneDataSnapshot = entries;
                phoneDataSnapshotGeneration = generation;
                phoneDataSnapshotMode = selectedMode;
                htmlResult = buildPhoneDataHtml(entries, selectedMode);
            }

            } catch (Exception error) {
                htmlResult = documentsShellHtml(
                        "<div class='empty'>Files load नहीं हो पाईं। ऊपर Refresh दबाकर फिर कोशिश करें।</div>",
                        0, false, selectedMode);
            }
            final String html = htmlResult;
            runOnUiThread(() -> {
                if (!slot1DocumentsHome || generation != documentsLoadGeneration || isFinishing() || isDestroyed() ||
                        !selectedMode.equals(phoneDataMode)) return;
                webView1.loadDataWithBaseURL("https://sts.documents/", html, "text/html", "UTF-8", null);
            });
        }, "SFB-Phone-Data").start();
    }

    private boolean hasDocumentAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return Environment.isExternalStorageManager();
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private boolean isYouTubeUrl(String url) {
        if (TextUtils.isEmpty(url)) return false;
        try {
            Uri u = Uri.parse(url);
            String host = u.getHost();
            if (!TextUtils.isEmpty(host)) {
                host = host.toLowerCase(Locale.ROOT);
                if ("youtube.com".equals(host) ||
                        host.endsWith(".youtube.com") ||
                        "youtu.be".equals(host) ||
                        host.endsWith(".youtu.be")) {
                    return true;
                }
            }

            // Google/search redirect URLs can temporarily remain visible while YouTube is loading.
            String lower = url.toLowerCase(Locale.ROOT);
            return lower.contains("youtube.com%2f") ||
                    lower.contains("youtube.com/watch") ||
                    lower.contains("youtu.be%2f");
        } catch (Exception ignored) {
            return false;
        }
    }

    private void updateYouTubeState(WebView view, String url) {
        boolean youtube = isYouTubeUrl(url);
        if (view == webView1) webView1YouTube = youtube;
        else if (view == webView2) webView2YouTube = youtube;

        if (view == webView) {
            updatePictureInPictureParams();
        }
    }

    private boolean isCurrentYouTubePage() {
        if (webView == null) return false;
        if (activeSlot == 1 && slot1DocumentsHome) return false;

        boolean tracked = activeSlot == 2 ? webView2YouTube : webView1YouTube;
        if (tracked) return true;

        String url = webView.getUrl();
        if (isYouTubeUrl(url)) return true;
        try {
            return isYouTubeUrl(webView.getOriginalUrl());
        } catch (Exception ignored) {
            return false;
        }
    }

    private void updatePictureInPictureParams() {
        if (videoController != null) videoController.updatePip();
    }

    @Override protected void onUserLeaveHint() {
        if (videoController != null) videoController.enterPip(true);
        super.onUserLeaveHint();
    }

    @Override public void onPictureInPictureUiStateChanged(android.app.PictureInPictureUiState state) {
        super.onPictureInPictureUiStateChanged(state);
        if (Build.VERSION.SDK_INT >= 35 && state.isTransitioningToPip() && videoController != null)
            videoController.preparePipContent();
    }

    @Override public void onPictureInPictureModeChanged(boolean pip, Configuration config) {
        super.onPictureInPictureModeChanged(pip, config);
        if (videoController != null) videoController.pipChanged(pip);
        if (pip && loadingOverlay != null) loadingOverlay.setVisibility(View.GONE);
        if (webStage != null) webStage.requestLayout();
    }

    private void requestDocumentAccess() {
        runOnUiThread(() -> {
            try {
                documentAccessRequested = true;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_DOCUMENT_ACCESS);
                } else {
                    documentAccessRequested = false;
                    showDocumentsHome();
                }
            } catch (Exception first) {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                    } else {
                        documentAccessRequested = false;
                    }
                } catch (Exception ignored) {
                    documentAccessRequested = false;
                    Toast.makeText(this, "File access settings नहीं खुल पाई", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onPause() {
        activityResumed = false;
        stopLoadingLogoAnimation();
        if (loadingOverlay != null) loadingOverlay.animate().cancel();
        if (slot1DocumentsHome && webView1 != null) {
            webView1.evaluateJavascript("window.__stsUiPaused=true;if(window.__stsLoadTimer){clearTimeout(window.__stsLoadTimer);window.__stsLoadTimer=null;}", null);
            webView1.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        activityResumed = true;
        if (webView1 != null && slot1DocumentsHome && activeSlot == 1) {
            webView1.onResume();
            webView1.evaluateJavascript("window.__stsUiPaused=false;if(typeof loadAllGradually==='function'&&(pendingSort||(document.getElementById('q')&&document.getElementById('q').value)))loadAllGradually();", null);
        }
        updateLoadingOverlayForActiveSlot();
        if (browserTopBar != null && !isInPictureInPictureMode() && (videoController == null || !videoController.isFullscreen())) {
            browserTopBar.setVisibility(View.VISIBLE);
        }
        updatePictureInPictureParams();
        if (documentAccessRequested && slot1DocumentsHome && webView1 != null) {
            documentAccessRequested = false;
            webView1.postDelayed(this::showDocumentsHome, 250);
        }
    }

    private List<DocumentEntry> queryPhoneData(String mode, int generation) {
        List<DocumentEntry> out = new ArrayList<>();
        Cursor cursor = null;
        try {
            Uri collection;
            if ("Photo".equals(mode)) {
                collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            } else if ("Audio".equals(mode)) {
                collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            } else if ("Video".equals(mode)) {
                collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
            } else {
                collection = MediaStore.Files.getContentUri("external");
            }
            String[] projection = new String[] {
                    MediaStore.Files.FileColumns._ID,
                    MediaStore.Files.FileColumns.DISPLAY_NAME,
                    MediaStore.Files.FileColumns.MIME_TYPE,
                    MediaStore.Files.FileColumns.SIZE,
                    MediaStore.Files.FileColumns.DATE_MODIFIED
            };

            cursor = getContentResolver().query(
                    collection,
                    projection,
                    null,
                    null,
                    MediaStore.Files.FileColumns.DATE_MODIFIED + " DESC"
            );
            if (cursor == null) return out;

            int idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID);
            int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME);
            int mimeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE);
            int sizeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.SIZE);
            int dateCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATE_MODIFIED);

            int scanned = 0;
            while (cursor.moveToNext()) {
                if ((scanned++ & 255) == 0 &&
                        (generation != documentsLoadGeneration || !mode.equals(phoneDataMode))) {
                    break;
                }
                String name = cursor.getString(nameCol);
                if (TextUtils.isEmpty(name)) continue;
                String mime = mimeCol >= 0 ? cursor.getString(mimeCol) : null;
                String category = categoryForPhoneData(mode, name, mime);
                if (category == null) continue;
                String filterType = filterTypeForPhoneData(mode, name, mime);
                if (filterType == null) continue;

                long id = cursor.getLong(idCol);
                long size = sizeCol >= 0 ? cursor.getLong(sizeCol) : 0L;
                long modifiedSec = dateCol >= 0 ? cursor.getLong(dateCol) : 0L;

                // Skip folder-like MediaStore rows from All Data / Other Data.
                if (("All Data".equals(mode) || "Other Data".equals(mode)) &&
                        TextUtils.isEmpty(mime) && size <= 0L && name.indexOf('.') < 0) {
                    continue;
                }

                Uri itemCollection = collection;
                if ("All Data".equals(mode)) {
                    if ("PHOTO".equals(category)) {
                        itemCollection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    } else if ("VIDEO".equals(category)) {
                        itemCollection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    } else if ("AUDIO".equals(category)) {
                        itemCollection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                    }
                }
                Uri uri = ContentUris.withAppendedId(itemCollection, id);
                out.add(new DocumentEntry(
                        uri.toString(),
                        name,
                        TextUtils.isEmpty(mime) ? mimeForPhoneDataName(name) : mime,
                        category,
                        filterType,
                        Math.max(0L, size),
                        Math.max(0L, modifiedSec) * 1000L
                ));
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return out;
    }

    private String categoryForPhoneData(String mode, String name, String mime) {
        if ("All Data".equals(mode)) {
            String document = documentCategory(name);
            if (document != null) return document;
            if (isPhotoCandidate(name, mime)) return "PHOTO";
            if (isAudioCandidate(name, mime)) return "AUDIO";
            if (isVideoFileCandidate(name, mime)) return "VIDEO";
            return otherDataCategory(name, mime);
        }
        if ("Documents".equals(mode)) return documentCategory(name);
        if ("Photo".equals(mode)) return isPhotoCandidate(name, mime) ? "PHOTO" : null;
        if ("Audio".equals(mode)) return isAudioCandidate(name, mime) ? "AUDIO" : null;
        if ("Video".equals(mode)) return isVideoFileCandidate(name, mime) ? "VIDEO" : null;
        if ("Other Data".equals(mode)) {
            if (documentCategory(name) != null || isPhotoCandidate(name, mime) ||
                    isAudioCandidate(name, mime) || isVideoFileCandidate(name, mime)) {
                return null;
            }
            return otherDataCategory(name, mime);
        }
        return null;
    }

    private String filterTypeForPhoneData(String mode, String name, String mime) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);

        if ("All Data".equals(mode)) {
            if (documentCategory(name) != null) return "Documents";
            if (isPhotoCandidate(name, mime)) return "Photo";
            if (isAudioCandidate(name, mime)) return "Audio";
            if (isVideoFileCandidate(name, mime)) return "Video";
            return "Other Data";
        }

        if ("Documents".equals(mode)) {
            if (n.endsWith(".pdf")) return "PDF";
            if (n.endsWith(".docx")) return "DOCX";
            if (n.endsWith(".xlsx")) return "XLSX";
            if (n.endsWith(".pptx")) return "PPTX";
            if (n.endsWith(".doc")) return "DOC";
            if (n.endsWith(".xls")) return "XLS";
            if (n.endsWith(".ppt")) return "PPT";
            if (n.endsWith(".txt")) return "TXT";
            if (n.endsWith(".csv")) return "CSV";
            if (n.endsWith(".rtf")) return "RTF";
            if (n.endsWith(".odt")) return "ODT";
            if (n.endsWith(".ods")) return "ODS";
            if (n.endsWith(".odp")) return "ODP";
            if (n.endsWith(".ofd")) return "OFD";
            return null;
        }

        if ("Photo".equals(mode)) {
            if (n.endsWith(".jpg") || n.endsWith(".jpeg") || "image/jpeg".equals(m)) return "JPG";
            if (n.endsWith(".png") || "image/png".equals(m)) return "PNG";
            if (n.endsWith(".webp") || "image/webp".equals(m)) return "WEBP";
            if (n.endsWith(".heic") || n.endsWith(".heif") || m.contains("heic") || m.contains("heif")) return "HEIC";
            if (n.endsWith(".gif") || "image/gif".equals(m)) return "GIF";
            if (n.endsWith(".bmp") || "image/bmp".equals(m)) return "BMP";
            if (n.endsWith(".avif") || "image/avif".equals(m)) return "AVIF";
            return null;
        }

        if ("Audio".equals(mode)) {
            if (n.endsWith(".mp3") || "audio/mpeg".equals(m)) return "MP3";
            if (n.endsWith(".m4a") || m.contains("mp4a") || "audio/mp4".equals(m)) return "M4A";
            if (n.endsWith(".aac") || "audio/aac".equals(m)) return "AAC";
            if (n.endsWith(".wav") || "audio/wav".equals(m) || "audio/x-wav".equals(m)) return "WAV";
            if (n.endsWith(".ogg") || "audio/ogg".equals(m)) return "OGG";
            if (n.endsWith(".flac") || "audio/flac".equals(m)) return "FLAC";
            return "OTHER";
        }

        if ("Video".equals(mode)) {
            if (n.endsWith(".mp4") || "video/mp4".equals(m)) return "MP4";
            if (n.endsWith(".mkv") || m.contains("matroska")) return "MKV";
            if (n.endsWith(".webm") || "video/webm".equals(m)) return "WEBM";
            if (n.endsWith(".3gp") || "video/3gpp".equals(m)) return "3GP";
            if (n.endsWith(".mov") || "video/quicktime".equals(m)) return "MOV";
            if (n.endsWith(".avi") || m.contains("msvideo")) return "AVI";
            if (n.endsWith(".wmv") || m.contains("ms-wmv")) return "WMV";
            if (n.endsWith(".m4v")) return "M4V";
            if (n.endsWith(".mpeg") || n.endsWith(".mpg") || "video/mpeg".equals(m)) return "MPEG/MPG";
            return null;
        }

        if ("Other Data".equals(mode)) {
            if (n.endsWith(".apk")) return "APK";
            if (n.endsWith(".zip")) return "ZIP";
            if (n.endsWith(".rar")) return "RAR";
            if (n.endsWith(".7z")) return "7Z";
            if (n.endsWith(".tar") || n.endsWith(".gz") || n.endsWith(".tgz")) return "TAR/GZ";
            return "OTHER";
        }
        return null;
    }

    private String documentCategory(String name) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".pdf")) return "PDF";
        if (n.endsWith(".doc") || n.endsWith(".docx") || n.endsWith(".odt") || n.endsWith(".rtf")) return "DOC";
        if (n.endsWith(".xls") || n.endsWith(".xlsx") || n.endsWith(".csv") || n.endsWith(".ods")) return "XLS";
        if (n.endsWith(".ppt") || n.endsWith(".pptx") || n.endsWith(".odp")) return "PPT";
        if (n.endsWith(".ofd")) return "OFD";
        if (n.endsWith(".txt")) return "TXT";
        return null;
    }

    private boolean isPhotoCandidate(String name, String mime) {
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        if (m.startsWith("image/")) return true;
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") ||
                n.endsWith(".webp") || n.endsWith(".gif") || n.endsWith(".bmp") ||
                n.endsWith(".heic") || n.endsWith(".heif") || n.endsWith(".avif");
    }

    private boolean isAudioCandidate(String name, String mime) {
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        if (m.startsWith("audio/")) return true;
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        return n.endsWith(".mp3") || n.endsWith(".m4a") || n.endsWith(".aac") ||
                n.endsWith(".wav") || n.endsWith(".ogg") || n.endsWith(".flac");
    }

    private boolean isVideoFileCandidate(String name, String mime) {
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        if (m.startsWith("video/")) return true;
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        return n.endsWith(".mp4") || n.endsWith(".mkv") || n.endsWith(".webm") ||
                n.endsWith(".3gp") || n.endsWith(".mov") || n.endsWith(".avi") ||
                n.endsWith(".wmv") || n.endsWith(".m4v") || n.endsWith(".mpeg") ||
                n.endsWith(".mpg");
    }

    private String otherDataCategory(String name, String mime) {
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".apk")) return "APK";
        if (n.endsWith(".zip") || n.endsWith(".rar") || n.endsWith(".7z") ||
                n.endsWith(".tar") || n.endsWith(".gz")) return "ZIP";
        return "FILE";
    }

    private String mimeForPhoneDataName(String name) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".pdf")) return "application/pdf";
        if (n.endsWith(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        if (n.endsWith(".doc")) return "application/msword";
        if (n.endsWith(".xlsx")) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        if (n.endsWith(".xls")) return "application/vnd.ms-excel";
        if (n.endsWith(".pptx")) return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
        if (n.endsWith(".ppt")) return "application/vnd.ms-powerpoint";
        if (n.endsWith(".csv")) return "text/csv";
        if (n.endsWith(".txt")) return "text/plain";
        if (n.endsWith(".rtf")) return "application/rtf";
        if (n.endsWith(".odt")) return "application/vnd.oasis.opendocument.text";
        if (n.endsWith(".ods")) return "application/vnd.oasis.opendocument.spreadsheet";
        if (n.endsWith(".odp")) return "application/vnd.oasis.opendocument.presentation";
        if (n.endsWith(".ofd")) return "application/ofd";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".bmp")) return "image/bmp";
        if (n.endsWith(".heic") || n.endsWith(".heif")) return "image/heic";
        if (n.endsWith(".avif")) return "image/avif";
        if (n.endsWith(".mp4") || n.endsWith(".m4v")) return "video/mp4";
        if (n.endsWith(".webm")) return "video/webm";
        if (n.endsWith(".3gp")) return "video/3gpp";
        if (n.endsWith(".mkv")) return "video/x-matroska";
        if (n.endsWith(".mov")) return "video/quicktime";
        if (n.endsWith(".mp3")) return "audio/mpeg";
        if (n.endsWith(".m4a")) return "audio/mp4";
        if (n.endsWith(".aac")) return "audio/aac";
        if (n.endsWith(".wav")) return "audio/wav";
        if (n.endsWith(".ogg")) return "audio/ogg";
        if (n.endsWith(".flac")) return "audio/flac";
        if (n.endsWith(".apk")) return "application/vnd.android.package-archive";
        if (n.endsWith(".zip")) return "application/zip";
        return "application/octet-stream";
    }

    private String buildPhoneDataHtml(List<DocumentEntry> docs, String mode) {
        int initialCount = Math.min(docs.size(), PHONE_DATA_BATCH_SIZE);
        String rows = buildPhoneDataRows(docs, 0, initialCount);

        String body = "<div class='doc-list' id='docList'>" + rows + "</div>" +
                (docs.size() > initialCount
                        ? "<div id='loadMoreSentinel' class='load-more'>Scroll करने पर और files load होंगी…</div>"
                        : "") +
                (docs.isEmpty()
                        ? "<div class='empty'>कोई " + escapeDocsHtml(mode) + " data नहीं मिला।</div>"
                        : "");
        return documentsShellHtml(body, docs.size(), false, mode);
    }

    private String buildPhoneDataRows(List<DocumentEntry> docs, int start, int end) {
        if (docs == null || docs.isEmpty()) return "";
        int safeStart = Math.max(0, Math.min(start, docs.size()));
        int safeEnd = Math.max(safeStart, Math.min(end, docs.size()));

        StringBuilder rows = new StringBuilder(Math.max(4096, (safeEnd - safeStart) * 340));
        SimpleDateFormat groupFmt = new SimpleDateFormat("yyyy/MM/dd", Locale.getDefault());
        SimpleDateFormat itemFmt = new SimpleDateFormat("d MMMM", Locale.getDefault());

        String lastGroup = "";
        if (safeStart > 0) {
            DocumentEntry previous = docs.get(safeStart - 1);
            lastGroup = previous.modified > 0
                    ? groupFmt.format(new Date(previous.modified))
                    : "Unknown date";
        }

        for (int index = safeStart; index < safeEnd; index++) {
            DocumentEntry d = docs.get(index);
            String group = d.modified > 0 ? groupFmt.format(new Date(d.modified)) : "Unknown date";
            if (!group.equals(lastGroup)) {
                rows.append("<div class='date-group' data-group='").append(escapeDocsAttr(group)).append("'>")
                        .append(escapeDocsHtml(group)).append("</div>");
                lastGroup = group;
            }

            String size = formatDocumentSize(d.size);
            String itemDate = d.modified > 0 ? itemFmt.format(new Date(d.modified)) : "";
            String sub = size;
            if (!TextUtils.isEmpty(itemDate)) sub += "  |  " + itemDate;

            rows.append("<div class='doc-item' data-cat='").append(d.filterType)
                    .append("' data-name='").append(escapeDocsAttr(d.name.toLowerCase(Locale.ROOT))).append("'")
                    .append(" data-size='").append(d.size).append("'")
                    .append(" data-modified='").append(d.modified).append("' onclick='handleItemTap(this,event)'")
                    .append(" data-uri='").append(escapeDocsAttr(d.uri)).append("'")
                    .append(" data-filename='").append(escapeDocsAttr(d.name)).append("'")
                    .append(" data-mime='").append(escapeDocsAttr(d.mime)).append("'>");

            if ("PHOTO".equals(d.category) || "VIDEO".equals(d.category)) {
                String thumb = "https://sts.phone/thumb?u=" + Uri.encode(d.uri) +
                        "&k=" + ("VIDEO".equals(d.category) ? "video" : "photo");
                rows.append("<div class='media-thumb-wrap'><img class='media-thumb' loading='lazy' src='")
                        .append(escapeDocsAttr(thumb)).append("'>");
                if ("VIDEO".equals(d.category)) rows.append("<div class='play-badge'>▶</div>");
                rows.append("</div>");
            } else {
                rows.append("<div class='file-icon ").append(d.category.toLowerCase(Locale.ROOT)).append("'><span>")
                        .append(escapeDocsHtml(iconText(d.category))).append("</span></div>");
            }

            rows.append("<div class='file-body'><div class='file-name'>").append(escapeDocsHtml(d.name)).append("</div>")
                    .append("<div class='file-meta'>").append(escapeDocsHtml(sub)).append("</div></div></div>");
        }
        return rows.toString();
    }

    private String documentsShellHtml(String body, int count, boolean permissionPage, String mode) {
        return "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,user-scalable=no'>" +
                "<style>" +
                "*{box-sizing:border-box}html,body{margin:0;background:#050505;color:#f4f4f4;font-family:Arial,sans-serif;min-height:100%}" +
                ".header{position:sticky;top:0;z-index:10;background:#050505;padding:16px 16px 0;border-bottom:1px solid #111}" +
                ".title-row{display:flex;align-items:center;height:48px}.mode-title{flex:1;border:0;background:transparent;color:#fff;text-align:left;font-size:25px;font-weight:700;padding:0;white-space:nowrap}.top-count{font-size:13px;color:#a8a8a8;white-space:nowrap;margin-right:4px}.selected-count{display:none;font-size:13px;color:#fff;white-space:nowrap;margin-right:4px;font-weight:700}.mode-menu{display:none;position:fixed;left:12px;top:58px;z-index:55;width:max-content;min-width:150px;background:#1a1a1a;border:1px solid #3a3a3a;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(0,0,0,.55)}.mode-menu.show{display:block}.mode-option{display:block;width:100%;border:0;border-bottom:1px solid #2d2d2d;background:#1a1a1a;color:#fff;text-align:left;padding:12px 16px;font-size:15px;white-space:nowrap}.mode-option:active{background:#303030}" +
                ".head-btn{width:44px;height:44px;border:0;background:transparent;color:#fff;font-size:28px;border-radius:22px}" +
                ".head-btn:active{background:#242424}.tabs{display:flex;overflow-x:auto;gap:4px;height:58px;align-items:flex-end;padding:0 4px}" +
                ".tab{border:0;background:transparent;color:#8c8c8c;font-size:18px;padding:16px 13px 13px;white-space:nowrap;border-bottom:3px solid transparent}" +
                ".tab.active{color:#fff;border-bottom-color:#fff;font-weight:700}.search{display:none;padding:0 0 12px}.search.show{display:block}" +
                ".search input{width:100%;height:42px;border-radius:10px;border:1px solid #555;background:#171717;color:#fff;padding:0 12px;font-size:16px}" +
                ".doc-menu{display:none;position:fixed;right:12px;top:58px;z-index:50;width:max-content;max-width:72vw;background:#1a1a1a;border:1px solid #3a3a3a;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(0,0,0,.55)}.doc-menu.show{display:block}.selection-menu{display:none}.menu-item,.sort-option{display:block;width:100%;min-width:0;border:0;border-bottom:1px solid #2d2d2d;background:#1a1a1a;color:#fff;text-align:left;padding:12px 16px;font-size:15px;white-space:nowrap}.menu-item:active,.sort-option:active{background:#303030}.sort-sub{display:none;background:#121212}.sort-sub.show{display:block}.sort-sub .sort-option{padding-left:28px;color:#ddd}" +
                ".date-group{font-size:22px;font-weight:700;padding:14px 16px 10px;content-visibility:auto;contain-intrinsic-size:52px}.doc-list{padding-bottom:28px}" +
                ".doc-item{position:relative;display:flex;align-items:center;min-height:100px;padding:10px 16px;border-bottom:1px solid #202020;content-visibility:auto;contain-intrinsic-size:100px}.doc-item.selected{outline:2px solid #4F8F8B;outline-offset:-2px;background:#16302e}.doc-item.selected:after{content:'✓';position:absolute;right:7px;top:7px;width:22px;height:22px;border-radius:50%;background:#4F8F8B;color:#fff;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;z-index:4}" +
                ".doc-item:active{background:#181818}.file-icon{width:54px;height:66px;margin-right:16px;display:flex;align-items:center;justify-content:center;" +
                "border-radius:4px 4px 3px 3px;color:#fff;font-weight:700;font-size:18px;clip-path:polygon(0 0,76% 0,100% 20%,100% 100%,0 100%)}" +
                ".file-icon.pdf{background:#e34d4d}.file-icon.doc{background:#3778c2}.file-icon.xls{background:#388e4a}" +
                ".file-icon.ppt{background:#f05b23}.file-icon.ofd{background:#7856a8}.file-icon.txt{background:#6f7780}.file-icon.photo{background:#5B7FA3}.file-icon.video{background:#7C7399}.file-icon.audio{background:#4F8F8B}.file-icon.apk{background:#7E9B76}.file-icon.zip{background:#B39B7A}.file-icon.file{background:#6f7780}" +
                ".file-body{min-width:0;flex:1}.file-name{font-size:18px;font-weight:700;line-height:1.28;word-break:break-word}" +
                ".file-meta{font-size:14px;color:#8f8f8f;margin-top:5px}.media-thumb-wrap{position:relative;overflow:hidden;background:#181818}.media-thumb{display:block;width:100%;height:100%;object-fit:cover}.play-badge{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:30px;height:30px;border-radius:50%;background:rgba(0,0,0,.62);color:#fff;display:flex;align-items:center;justify-content:center;font-size:14px;padding-left:2px}" +
                "body.media-grid .doc-list{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:2px;padding:0 2px 24px}body.media-grid .date-group{grid-column:1/-1;font-size:16px;padding:10px 8px 6px}" +
                "body.media-grid .doc-item{display:block;min-height:0;padding:0 0 7px;border:0;text-align:left;overflow:hidden}body.media-grid .media-thumb-wrap{width:100%;aspect-ratio:1/1;margin:0}" +
                "body.media-grid .file-body{padding:5px 4px 1px;display:block;width:100%}body.media-grid .file-name{display:block;width:100%;font-size:10px;font-weight:600;line-height:1.2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:left}body.media-grid .file-meta{display:none}" +
                "body.all-data-grid .doc-list{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;padding:6px 6px 24px}" +
                "body.all-data-grid .date-group{grid-column:1/-1;font-size:16px;padding:10px 6px 4px}" +
                "body.all-data-grid .doc-item{display:block;min-width:0;min-height:0;padding:0 0 8px;border:1px solid #1f1f1f;border-radius:8px;text-align:left;overflow:hidden;background:#0d0d0d}" +
                "body.all-data-grid .media-thumb-wrap{display:block;width:100%;aspect-ratio:1/1;margin:0}" +
                "body.all-data-grid .file-icon{width:54px;height:66px;margin:14px auto 10px}" +
                "body.all-data-grid .file-body{display:block;width:100%;min-width:0;padding:5px 6px 3px;text-align:left}" +
                "body.all-data-grid .file-name{display:block;width:100%;font-size:10px;font-weight:600;line-height:1.2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:left;word-break:normal}" +
                "body.all-data-grid .file-meta{display:block;width:100%;font-size:9px;line-height:1.2;margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}" +
                ".load-more{text-align:center;padding:18px 16px 30px;color:#777;font-size:13px}.empty,.center,.permission{text-align:center;padding:70px 24px;color:#aaa}" +
                ".permission{padding-top:100px}.permission h2{color:#fff}.permission p{line-height:1.5}.permission button{margin-top:14px;border:0;" +
                "border-radius:10px;padding:13px 20px;background:#4F8F8B;color:#fff;font-size:16px;font-weight:700}.folder{font-size:54px;color:#f0a348}" +
                ".spinner{width:34px;height:34px;border:4px solid #333;border-top-color:#eee;border-radius:50%;margin:0 auto 14px;animation:r 1s linear infinite}" +
                "@keyframes r{to{transform:rotate(360deg)}}body.grid:not(.media-grid) .doc-list{display:grid;grid-template-columns:1fr 1fr;gap:1px}" +
                "body.grid:not(.media-grid) .date-group{grid-column:1/-1}body.grid:not(.media-grid) .doc-item{display:block;min-height:170px;text-align:center;padding:16px 8px}" +
                "body.grid:not(.media-grid) .file-icon{margin:0 auto 10px}.hide{display:none!important}" +
                "html,body{background:#101918;color:#e4eeec}.header{background:#152321;border-color:#30413e;padding:8px 12px 0}.title-row{flex-wrap:wrap;height:auto;min-height:48px;gap:2px}.mode-title{font-size:20px;min-width:100px;overflow:hidden;text-overflow:ellipsis}.selected-count{font-size:12px}.head-btn{flex-shrink:0}.tabs{height:48px;scrollbar-width:none}.tabs::-webkit-scrollbar{display:none}.tab{font-size:15px;padding:12px 10px}.tab.active{color:#bfe3df;border-color:#7faeaa}.date-group{font-size:17px;color:#b7ceca}.file-name{font-size:16px;font-weight:600}.file-meta{color:#a7b8b4}.doc-item{border-color:#293b36}.doc-item:active{background:#29433e}.mode-menu,.doc-menu{max-height:calc(100vh - 82px);overflow-y:auto;overscroll-behavior:contain;scrollbar-width:none;background:#20312d;border-color:#49635b}.mode-option,.menu-item,.sort-option{background:#20312d;border-color:#3b5048;min-height:48px}.mode-menu{max-width:calc(100vw - 24px)}.search{position:relative}.search input{padding-right:44px;background:#20312d;border-color:#49635b}.clear-search{position:absolute;right:0;top:0;width:44px;height:42px;border:0;background:transparent;color:#dae9e4;font-size:24px}.search input::-webkit-search-cancel-button{display:none}button{touch-action:manipulation;-webkit-tap-highlight-color:rgba(127,174,170,.25)}button:focus-visible{outline:2px solid #bfe3df;outline-offset:-2px}body.all-data-grid .doc-item{background:#192722;border-color:#354b40}body.media-grid .file-name,body.all-data-grid .file-name{font-size:11px}body.all-data-grid .doc-item.selected{background:#29433e;outline:2px solid #7faeaa}.doc-menu .menu-item{text-align:right}@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}" +
                "</style></head><body class='" + ("All Data".equals(mode) ? "all-data-grid" : (isMediaMode(mode) ? "grid media-grid" : "")) + "'>" +
                "<div class='header'><div class='title-row'>" +
                "<button id='modeButton' class='mode-title' onclick='toggleModeMenu(event)'>" + escapeDocsHtml(mode) + " ▾</button>" +
                "<div class='top-count'><span id='shownCount'>" + count + "</span> items</div>" +
                "<div id='selectedCount' class='selected-count'>0 selected</div>" +
                "<button class='head-btn' onclick='toggleSearch()'>⌕</button>" +
                "<button id='menuButton' class='head-btn' onclick='toggleDocMenu(event)'>⋮</button></div>" +
                "<div id='searchBox' class='search'><button class='clear-search' aria-label='Clear search' onclick='clearSearch()'>×</button><input id='q' type='search' aria-label='Search files' placeholder='Search " + escapeDocsAttr(mode.toLowerCase(Locale.ROOT)) + "' oninput='scheduleFilter()'></div>" +
                "<div class='tabs'>" + phoneDataTabsHtml(mode) + "</div></div>" +
                "<div id='modeMenu' class='mode-menu'>" +
                modeOptionHtml("All Data", mode) + modeOptionHtml("Documents", mode) + modeOptionHtml("Photo", mode) +
                modeOptionHtml("Audio", mode) + modeOptionHtml("Video", mode) +
                modeOptionHtml("Other Data", mode) +
                "</div>" +
                "<div id='docMenu' class='doc-menu'>" +
                "<div id='normalMenu'>" +
                "<button class='menu-item' onclick='STSDocuments.refresh()'>Refresh</button>" +
                "<button id='gridMenuItem' class='menu-item' onclick='toggleGridFromMenu()'>" +
                (("All Data".equals(mode) || isMediaMode(mode)) ? "List view" : "Grid view") + "</button>" +
                "<button class='menu-item' onclick='toggleSortSub(event)'>Sort by ▸</button>" +
                "<div id='sortSub' class='sort-sub'>" +
                "<button class='sort-option' onclick=\"sortDocs('dateDesc')\">Date modified</button>" +
                "<button class='sort-option' onclick=\"sortDocs('dateAsc')\">Oldest first</button>" +
                "<button class='sort-option' onclick=\"sortDocs('nameAsc')\">Name A–Z</button>" +
                "<button class='sort-option' onclick=\"sortDocs('nameDesc')\">Name Z–A</button>" +
                "<button class='sort-option' onclick=\"sortDocs('sizeDesc')\">Largest first</button>" +
                "<button class='sort-option' onclick=\"sortDocs('sizeAsc')\">Smallest first</button>" +
                "</div></div>" +
                "<div id='selectionMenu' class='selection-menu'>" +
                "<button class='menu-item' onclick='clearSelection()'>Clear selection</button>" +
                "<button class='menu-item' onclick='selectVisible()'>Select visible items</button>" +
                "<button class='menu-item' onclick='shareSelected()'>Share</button>" +
                "<button class='menu-item' onclick='deleteSelected()'>Delete</button>" +
                "</div></div>" +
                body +
                "<script>" +
                "var cat='All',selected=new Set(),pressTimer=null,startX=0,startY=0,filterTimer=null,loadingMore=false,pendingSort=null;" +
                "var allDataMode=" + ("All Data".equals(mode) ? "true" : "false") + ",majorCat='';" +
                "var loadedCount=document.querySelectorAll('.doc-item').length,totalCount=" + count + ";" +
                "function clearSearch(){document.getElementById('q').value='';if(!pendingSort&&window.__stsLoadTimer){clearTimeout(window.__stsLoadTimer);window.__stsLoadTimer=null;}scheduleFilter();document.getElementById('q').focus();}function scheduleFilter(){if(filterTimer)clearTimeout(filterTimer);filterTimer=setTimeout(function(){filterTimer=null;applyFilter();var q=(document.getElementById('q').value||'').trim();if(q&&loadedCount<totalCount)loadAllGradually();},120);}" +
                "function toggleSearch(){document.getElementById('searchBox').classList.toggle('show');var q=document.getElementById('q');if(document.getElementById('searchBox').classList.contains('show'))q.focus();}" +
                "function toggleModeMenu(e){if(e)e.stopPropagation();document.getElementById('docMenu').classList.remove('show');document.getElementById('sortSub').classList.remove('show');document.getElementById('modeMenu').classList.toggle('show');}" +
                "function chooseMode(v){document.getElementById('modeMenu').classList.remove('show');STSDocuments.selectMode(v);}" +
                "function syncSelectionUi(){var n=selected.size,s=document.getElementById('selectedCount'),normal=document.getElementById('normalMenu'),sel=document.getElementById('selectionMenu');if(s){s.textContent=n+' selected';s.style.display=n?'block':'none';}if(normal)normal.style.display=n?'none':'block';if(sel)sel.style.display=n?'block':'none';var sub=document.getElementById('sortSub');if(n&&sub)sub.classList.remove('show');}" +
                "function setSelected(x,on){if(on){selected.add(x);x.classList.add('selected');}else{selected.delete(x);x.classList.remove('selected');}syncSelectionUi();}" +
                "function toggleSelected(x,forceOn){setSelected(x,forceOn===true?true:!selected.has(x));}" +
                "function handleItemTap(x,e){if(x.dataset.longpress==='1'){x.dataset.longpress='';return;}if(selected.size){toggleSelected(x,false);return;}openDoc(x);}" +
                "function clearPress(){if(pressTimer){clearTimeout(pressTimer);pressTimer=null;}}" +
                "function installSelection(root){(root||document).querySelectorAll('.doc-item:not([data-bound])').forEach(function(x){x.dataset.bound='1';x.addEventListener('touchstart',function(e){if(!e.touches||e.touches.length!==1)return;startX=e.touches[0].clientX;startY=e.touches[0].clientY;clearTimeout(pressTimer);pressTimer=setTimeout(function(){x.dataset.longpress='1';toggleSelected(x,true);pressTimer=null;},520);},{passive:true});x.addEventListener('touchmove',function(e){if(!pressTimer||!e.touches||!e.touches.length)return;var dx=e.touches[0].clientX-startX,dy=e.touches[0].clientY-startY;if(dx*dx+dy*dy>100)clearPress();},{passive:true});x.addEventListener('touchend',clearPress,{passive:true});x.addEventListener('touchcancel',clearPress,{passive:true});x.addEventListener('contextmenu',function(e){e.preventDefault();if(x.dataset.longpress!=='1'){x.dataset.longpress='1';toggleSelected(x,true);}return false;});});}" +
                "function ensureLoadSentinel(text){var s=document.getElementById('loadMoreSentinel');if(!s){s=document.createElement('div');s.id='loadMoreSentinel';s.className='load-more';document.getElementById('docList').after(s);}s.textContent=text||'Scroll करने पर और files load होंगी…';return s;}" +
                "function loadMajorMore(){if(!allDataMode||!majorCat||loadingMore||loadedCount>=totalCount&&totalCount>0)return false;loadingMore=true;try{var raw=STSDocuments.loadMajorCategory(majorCat,loadedCount);var o=raw?JSON.parse(raw):null;var list=document.getElementById('docList');if(o){totalCount=Number(o.total)||0;if(o.html){var box=document.createElement('div');box.innerHTML=o.html;var fragment=document.createDocumentFragment();while(box.firstChild)fragment.appendChild(box.firstChild);list.appendChild(fragment);installSelection(list);}loadedCount=Number(o.loaded)||list.querySelectorAll('.doc-item').length;var oldEmpty=document.getElementById('majorEmpty');if(oldEmpty)oldEmpty.remove();if(totalCount===0){var empty=document.createElement('div');empty.id='majorEmpty';empty.className='empty';empty.textContent='कोई '+majorCat+' data नहीं मिला।';list.after(empty);}if(loadedCount<totalCount)ensureLoadSentinel('Scroll करने पर और '+majorCat+' files load होंगी…');else{var s=document.getElementById('loadMoreSentinel');if(s)s.remove();}applyFilter();}}catch(e){}loadingMore=false;return loadedCount<totalCount;}" +
                "function switchMajorCategory(v){if(window.__stsLoadTimer){clearTimeout(window.__stsLoadTimer);window.__stsLoadTimer=null;}pendingSort=null;majorCat=v;cat=v;selected.clear();syncSelectionUi();" +
                "document.body.classList.remove('all-data-grid');var media=(v==='Photo'||v==='Video');document.body.classList.toggle('media-grid',media);document.body.classList.toggle('grid',media);" +
                "var gm=document.getElementById('gridMenuItem');if(gm)gm.textContent=media?'List view':'Grid view';" +
                "var list=document.getElementById('docList');list.innerHTML='';var s=document.getElementById('loadMoreSentinel');if(s)s.remove();var empty=document.getElementById('majorEmpty');if(empty)empty.remove();loadedCount=0;totalCount=0;ensureLoadSentinel(v+' loading...');loadMajorMore();}" +
                "function loadMoreNow(){if(allDataMode&&majorCat)return loadMajorMore();if(loadingMore||loadedCount>=totalCount)return false;loadingMore=true;try{var html=STSDocuments.loadMore(loadedCount);if(html){var box=document.createElement('div');box.innerHTML=html;var list=document.getElementById('docList');var fragment=document.createDocumentFragment();while(box.firstChild)fragment.appendChild(box.firstChild);list.appendChild(fragment);loadedCount=list.querySelectorAll('.doc-item').length;installSelection(list);applyFilter();}if(loadedCount>=totalCount){var s=document.getElementById('loadMoreSentinel');if(s)s.remove();}}catch(e){}loadingMore=false;return loadedCount<totalCount;}" +
                "function loadAllGradually(){if(window.__stsLoadTimer||window.__stsUiPaused)return;if(loadedCount>=totalCount){if(pendingSort){var m=pendingSort;pendingSort=null;sortDocs(m);}return;}var before=loadedCount;loadMoreNow();if(loadedCount<=before)return;window.__stsLoadTimer=setTimeout(function(){window.__stsLoadTimer=null;loadAllGradually();},80);}" +
                "window.addEventListener('scroll',function(){if(window.innerHeight+window.scrollY>document.body.scrollHeight-900)loadMoreNow();},{passive:true});" +
                "function clearSelection(){selected.forEach(function(x){x.classList.remove('selected');});selected.clear();syncSelectionUi();document.getElementById('docMenu').classList.remove('show');}" +
                "function selectVisible(){document.querySelectorAll('.doc-item:not(.hide)').forEach(function(x){selected.add(x);x.classList.add('selected');});syncSelectionUi();document.getElementById('docMenu').classList.remove('show');}" +
                "function selectedUris(){return Array.from(selected).map(function(x){return x.dataset.uri;});}" +
                "function shareSelected(){var a=selectedUris();document.getElementById('docMenu').classList.remove('show');if(a.length)STSDocuments.shareSelected(JSON.stringify(a));}" +
                "function deleteSelected(){var a=selectedUris();document.getElementById('docMenu').classList.remove('show');if(a.length)STSDocuments.removeSelected(JSON.stringify(a));}" +
                "function toggleDocMenu(e){if(e)e.stopPropagation();document.getElementById('modeMenu').classList.remove('show');var m=document.getElementById('docMenu');m.classList.toggle('show');if(!m.classList.contains('show'))document.getElementById('sortSub').classList.remove('show');}" +
                "function toggleGridFromMenu(){var allGrid=document.body.classList.contains('all-data-grid');var media=document.body.classList.contains('media-grid');if(allGrid){document.body.classList.remove('all-data-grid');}else if(allDataMode&&!majorCat&&!document.body.classList.contains('grid')){document.body.classList.add('all-data-grid');}else if(media){document.body.classList.toggle('media-grid');document.body.classList.toggle('grid',document.body.classList.contains('media-grid'));}else{document.body.classList.toggle('grid');}" +
                "var b=document.getElementById('gridMenuItem');if(b)b.textContent=(document.body.classList.contains('all-data-grid')||document.body.classList.contains('grid')||document.body.classList.contains('media-grid'))?'List view':'Grid view';document.getElementById('docMenu').classList.remove('show');}" +
                "function toggleSortSub(e){if(e)e.stopPropagation();document.getElementById('sortSub').classList.toggle('show');}" +
                "function dateGroup(ms){var d=new Date(Number(ms)||0);if(!d.getTime())return 'Unknown date';" +
                "var y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');return y+'/'+m+'/'+day;}" +
                "function sortDocs(mode){if(loadedCount<totalCount){pendingSort=mode;loadAllGradually();return;}var list=document.getElementById('docList');if(!list)return;" +
                "var items=Array.from(list.querySelectorAll('.doc-item'));list.querySelectorAll('.date-group').forEach(function(x){x.remove();});" +
                "items.sort(function(a,b){if(mode==='nameAsc'||mode==='nameDesc'){var x=a.dataset.name||'',y=b.dataset.name||'';var r=x.localeCompare(y);return mode==='nameAsc'?r:-r;}" +
                "if(mode==='sizeDesc'||mode==='sizeAsc'){var x=Number(a.dataset.size)||0,y=Number(b.dataset.size)||0;return mode==='sizeDesc'?(y-x):(x-y);}" +
                "var x=Number(a.dataset.modified)||0,y=Number(b.dataset.modified)||0;return mode==='dateAsc'?(x-y):(y-x);});" +
                "var dateMode=(mode==='dateDesc'||mode==='dateAsc'),last='';items.forEach(function(x){if(dateMode){var g=dateGroup(x.dataset.modified);" +
                "if(g!==last){var h=document.createElement('div');h.className='date-group';h.textContent=g;list.appendChild(h);last=g;}}list.appendChild(x);});" +
                "document.getElementById('sortSub').classList.remove('show');document.getElementById('docMenu').classList.remove('show');applyFilter();}" +
                "document.addEventListener('click',function(e){var m=document.getElementById('docMenu'),b=document.getElementById('menuButton');if(m&&b&&!m.contains(e.target)&&e.target!==b){m.classList.remove('show');document.getElementById('sortSub').classList.remove('show');}" +
                "var mm=document.getElementById('modeMenu'),mb=document.getElementById('modeButton');if(mm&&mb&&!mm.contains(e.target)&&e.target!==mb)mm.classList.remove('show');});" +
                "function setCat(v,b){cat=v;document.querySelectorAll('.tab').forEach(function(x){x.classList.remove('active')});b.classList.add('active');if(allDataMode){switchMajorCategory(v);return;}applyFilter();}" +
                "function applyFilter(){var q=(document.getElementById('q').value||'').toLowerCase();var n=0;" +
                "document.querySelectorAll('.doc-item').forEach(function(x){var ok=(cat==='All'||x.dataset.cat===cat)&&(!q||x.dataset.name.indexOf(q)>=0);x.classList.toggle('hide',!ok);if(ok)n++;});" +
                "document.getElementById('shownCount').textContent=(allDataMode&&majorCat&&!q?totalCount:n);document.querySelectorAll('.date-group').forEach(function(g){var x=g.nextElementSibling;var any=false;" +
                "while(x&&!x.classList.contains('date-group')){if(x.classList.contains('doc-item')&&!x.classList.contains('hide')){any=true;break;}x=x.nextElementSibling;}g.classList.toggle('hide',!any);});}" +
                "function openDoc(x){STSDocuments.open(x.dataset.uri,x.dataset.filename,x.dataset.mime);}" +
                "function stsHandleBack(){var closed=false;['sortSub','docMenu','modeMenu'].forEach(function(id){var e=document.getElementById(id);if(e&&e.classList.contains('show')){e.classList.remove('show');closed=true;}});if(closed)return true;if(selected.size){clearSelection();return true;}var box=document.getElementById('searchBox');if(box&&box.classList.contains('show')){var q=document.getElementById('q');q.value='';q.blur();box.classList.remove('show');if(filterTimer){clearTimeout(filterTimer);filterTimer=null;}if(!pendingSort&&window.__stsLoadTimer){clearTimeout(window.__stsLoadTimer);window.__stsLoadTimer=null;}applyFilter();return true;}return false;}" +
                "installSelection();syncSelectionUi();" +
                "</script></body></html>";
    }

    private boolean isMediaMode(String mode) {
        return "Photo".equals(mode) || "Video".equals(mode);
    }

    private WebResourceResponse phoneDataThumbnailResponse(Uri requestUri) {
        try {
            String encoded = requestUri.getQueryParameter("u");
            if (TextUtils.isEmpty(encoded)) return null;
            String kind = requestUri.getQueryParameter("k");
            String cacheKey = (kind == null ? "" : kind) + "|" + encoded;
            byte[] cached;
            synchronized (phoneDataThumbCache) {
                cached = phoneDataThumbCache.get(cacheKey);
            }
            if (cached != null) {
                return new WebResourceResponse(
                        "image/jpeg", null,
                        new ByteArrayInputStream(cached)
                );
            }

            Uri mediaUri = Uri.parse(encoded);
            Bitmap bitmap;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                bitmap = getContentResolver().loadThumbnail(mediaUri, new Size(300, 300), null);
            } else {
                long id = ContentUris.parseId(mediaUri);
                if ("video".equals(kind)) {
                    bitmap = MediaStore.Video.Thumbnails.getThumbnail(
                            getContentResolver(), id, MediaStore.Video.Thumbnails.MINI_KIND, null);
                } else {
                    bitmap = MediaStore.Images.Thumbnails.getThumbnail(
                            getContentResolver(), id, MediaStore.Images.Thumbnails.MINI_KIND, null);
                }
            }

            if (bitmap == null) return null;
            ByteArrayOutputStream out = new ByteArrayOutputStream(24 * 1024);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, out);
            if (!bitmap.isRecycled()) bitmap.recycle();
            byte[] data = out.toByteArray();
            synchronized (phoneDataThumbCache) {
                phoneDataThumbCache.put(cacheKey, data);
            }
            return new WebResourceResponse(
                    "image/jpeg", null,
                    new ByteArrayInputStream(data)
            );
        } catch (Exception e) {
            return new WebResourceResponse(
                    "image/gif", null,
                    new ByteArrayInputStream(new byte[0])
            );
        }
    }

    private String phoneDataTabsHtml(String mode) {
        if ("All Data".equals(mode)) {
            return tabHtml("Documents", false) +
                    tabHtml("Photo", false) +
                    tabHtml("Audio", false) +
                    tabHtml("Video", false) +
                    tabHtml("Other Data", false);
        }
        if ("Documents".equals(mode)) {
            return tabHtml("All", true) +
                    tabHtml("PDF", false) +
                    tabHtml("DOCX", false) +
                    tabHtml("XLSX", false) +
                    tabHtml("PPTX", false) +
                    tabHtml("DOC", false) +
                    tabHtml("XLS", false) +
                    tabHtml("PPT", false) +
                    tabHtml("TXT", false) +
                    tabHtml("CSV", false) +
                    tabHtml("RTF", false) +
                    tabHtml("ODT", false) +
                    tabHtml("ODS", false) +
                    tabHtml("ODP", false) +
                    tabHtml("OFD", false);
        }
        if ("Photo".equals(mode)) {
            return tabHtml("All", true) +
                    tabHtml("JPG", false) +
                    tabHtml("PNG", false) +
                    tabHtml("WEBP", false) +
                    tabHtml("HEIC", false) +
                    tabHtml("GIF", false) +
                    tabHtml("BMP", false) +
                    tabHtml("AVIF", false);
        }
        if ("Audio".equals(mode)) {
            return tabHtml("All", true) +
                    tabHtml("MP3", false) +
                    tabHtml("M4A", false) +
                    tabHtml("AAC", false) +
                    tabHtml("WAV", false) +
                    tabHtml("OGG", false) +
                    tabHtml("FLAC", false) +
                    tabHtml("OTHER", false);
        }
        if ("Video".equals(mode)) {
            return tabHtml("All", true) +
                    tabHtml("MP4", false) +
                    tabHtml("MKV", false) +
                    tabHtml("WEBM", false) +
                    tabHtml("3GP", false) +
                    tabHtml("MOV", false) +
                    tabHtml("AVI", false) +
                    tabHtml("WMV", false) +
                    tabHtml("M4V", false) +
                    tabHtml("MPEG/MPG", false);
        }
        if ("Other Data".equals(mode)) {
            return tabHtml("All", true) +
                    tabHtml("APK", false) +
                    tabHtml("ZIP", false) +
                    tabHtml("RAR", false) +
                    tabHtml("7Z", false) +
                    tabHtml("TAR/GZ", false) +
                    tabHtml("OTHER", false);
        }
        return tabHtml("All", true);
    }

    private String modeOptionHtml(String label, String selected) {
        String shown = label.equals(selected) ? "✓ " + label : label;
        return "<button class='mode-option' onclick=\"chooseMode('" + escapeDocsAttr(label) + "')\">" +
                escapeDocsHtml(shown) + "</button>";
    }

    private String tabHtml(String label, boolean active) {
        return "<button class='tab" + (active ? " active" : "") + "' onclick=\"setCat('" +
                label + "',this)\">" + label + "</button>";
    }

    private String iconText(String category) {
        if ("PDF".equals(category)) return "PDF";
        if ("DOC".equals(category)) return "W";
        if ("XLS".equals(category)) return "X";
        if ("PPT".equals(category)) return "P";
        if ("OFD".equals(category)) return "O";
        if ("TXT".equals(category)) return "TXT";
        if ("PHOTO".equals(category)) return "IMG";
        if ("VIDEO".equals(category)) return "VID";
        if ("AUDIO".equals(category)) return "AUD";
        if ("APK".equals(category)) return "APK";
        if ("ZIP".equals(category)) return "ZIP";
        return "FILE";
    }

    private String formatDocumentSize(long bytes) {
        if (bytes < 1024L) return bytes + " B";
        double kb = bytes / 1024.0;
        if (kb < 1024.0) return String.format(Locale.getDefault(), "%.0f KB", kb);
        double mb = kb / 1024.0;
        if (mb < 1024.0) return String.format(Locale.getDefault(), "%.1f MB", mb);
        return String.format(Locale.getDefault(), "%.1f GB", mb / 1024.0);
    }

    private String escapeDocsHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }

    private String escapeDocsAttr(String s) {
        return escapeDocsHtml(s);
    }

    private void openDocumentFromHome(String uriString, String name, String mime) {
        runOnUiThread(() -> {
            if (!slot1DocumentsHome) return;
            try {
                Uri uri = Uri.parse(uriString);
                String lower = name == null ? "" : name.toLowerCase(Locale.ROOT);
                Intent intent;

                if (lower.endsWith(".apk") ||
                        "application/vnd.android.package-archive".equalsIgnoreCase(mime)) {
                    intent = new Intent(this, IntentRouterActivity.class);
                    intent.setAction(Intent.ACTION_VIEW);
                    intent.setDataAndType(uri, "application/vnd.android.package-archive");
                } else if (isPhotoCandidate(name, mime)) {
                    intent = new Intent(this, ImageViewerActivity.class);
                    intent.setData(uri);
                } else if (isAudioCandidate(name, mime) || isVideoFileCandidate(name, mime)) {
                    intent = new Intent(this, MediaPlayerActivity.class);
                    intent.setData(uri);
                    intent.putExtra("media_name", name);
                    intent.putExtra("media_mime", TextUtils.isEmpty(mime) ? mimeForPhoneDataName(name) : mime);
                    intent.putExtra("media_mode", isVideoFileCandidate(name, mime) ? "video" : "audio");
                } else if (lower.endsWith(".pdf") || "application/pdf".equalsIgnoreCase(mime)) {
                    intent = new Intent(this, PdfViewerActivity.class);
                    intent.putExtra("pdf_name", name);
                    intent.putExtra("pdf_slot", 1);
                    intent.setData(uri);
                } else if (lower.endsWith(".zip") || lower.endsWith(".jar") || lower.endsWith(".cbz") ||
                        "application/zip".equalsIgnoreCase(mime) ||
                        "application/x-zip-compressed".equalsIgnoreCase(mime)) {
                    // Phone Data ZIP opens inside STS rather than being sent to Office viewer.
                    intent = new Intent(this, ZipViewerActivity.class);
                    intent.putExtra("archive_name", name);
                    intent.setData(uri);
                } else if (documentCategory(name) != null) {
                    intent = new Intent(this, OfficeViewerActivity.class);
                    intent.putExtra("office_name", name);
                    intent.setData(uri);
                } else {
                    intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(uri, TextUtils.isEmpty(mime) ? mimeForPhoneDataName(name) : mime);
                }

                if(uri!=null && "content".equalsIgnoreCase(uri.getScheme()))
                    intent.setClipData(ClipData.newRawUri("STS document", uri));
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                        Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                startActivity(intent);
            } catch (ActivityNotFoundException e) {
                openExternalFileFallback(uriString, name, mime);
            } catch (Exception e) {
                openExternalFileFallback(uriString, name, mime);
            }
        });
    }

    private void openExternalFileFallback(String uriString, String name, String mime) {
        try {
            Uri uri = Uri.parse(uriString);
            Intent fallback = new Intent(Intent.ACTION_VIEW);
            fallback.setDataAndType(uri,
                    TextUtils.isEmpty(mime) ? mimeForPhoneDataName(name) : mime);
            fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            startActivity(fallback);
        } catch (Exception ignored) {
            Toast.makeText(this, "File open नहीं हो पाई", Toast.LENGTH_SHORT).show();
        }
    }

    private ArrayList<Uri> parsePhoneDataUris(String json) {
        ArrayList<Uri> uris = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(json == null ? "[]" : json);
            for (int i = 0; i < arr.length(); i++) {
                String raw = arr.optString(i, "");
                if (TextUtils.isEmpty(raw)) continue;
                Uri uri = Uri.parse(raw);
                if ("content".equalsIgnoreCase(uri.getScheme())) uris.add(uri);
            }
        } catch (Exception ignored) {}
        return uris;
    }

    private void shareSelectedPhoneData(String json) {
        runOnUiThread(() -> {
            ArrayList<Uri> uris = parsePhoneDataUris(json);
            if (uris.isEmpty()) return;
            try {
                Intent share = new Intent(uris.size() == 1 ? Intent.ACTION_SEND : Intent.ACTION_SEND_MULTIPLE);
                share.setType("*/*");
                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                if (uris.size() == 1) {
                    share.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                } else {
                    share.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                }
                ClipData clip = ClipData.newRawUri("Phone Data", uris.get(0));
                for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
                share.setClipData(clip);
                startActivity(Intent.createChooser(share, "Share selected"));
            } catch (Exception e) {
                Toast.makeText(this, "Share नहीं हो पाया", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void requestDeleteSelectedPhoneData(String json) {
        final ArrayList<Uri> uris = parsePhoneDataUris(json);
        if (uris.isEmpty()) return;
        runOnUiThread(() -> new AlertDialog.Builder(this)
                .setTitle("Delete selected")
                .setMessage(uris.size() + (uris.size() == 1 ? " item delete करना है?" : " items delete करने हैं?"))
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, w) -> performDeleteSelectedPhoneData(uris))
                .show());
    }

    private void performDeleteSelectedPhoneData(ArrayList<Uri> uris) {
        new Thread(() -> {
            ArrayList<Uri> needApproval = new ArrayList<>();
            int deleted = 0;
            for (Uri uri : uris) {
                try {
                    int result = getContentResolver().delete(uri, null, null);
                    if (result > 0) deleted++;
                    else needApproval.add(uri);
                } catch (Exception e) {
                    needApproval.add(uri);
                }
            }

            final int deletedNow = deleted;
            if (!needApproval.isEmpty() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                runOnUiThread(() -> {
                    try {
                        android.app.PendingIntent request = MediaStore.createDeleteRequest(
                                getContentResolver(), needApproval);
                        startIntentSenderForResult(request.getIntentSender(), REQ_PHONE_DATA_DELETE,
                                null, 0, 0, 0);
                    } catch (Exception e) {
                        if (deletedNow > 0 && slot1DocumentsHome) showDocumentsHome();
                        Toast.makeText(this, "कुछ files delete नहीं हो पाईं", Toast.LENGTH_SHORT).show();
                    }
                });
                return;
            }

            runOnUiThread(() -> {
                if (slot1DocumentsHome) showDocumentsHome();
                if (!needApproval.isEmpty()) {
                    Toast.makeText(this, "कुछ files delete नहीं हो पाईं", Toast.LENGTH_SHORT).show();
                }
            });
        }, "SFB-Phone-Data-Delete").start();
    }

    private class DocumentsBridge {
        @JavascriptInterface
        public void open(String uri, String name, String mime) {
            if (!slot1DocumentsHome) return;
            openDocumentFromHome(uri, name, mime);
        }

        @JavascriptInterface
        public String loadMore(int offset) {
            if (!slot1DocumentsHome) return "";
            List<DocumentEntry> snapshot = phoneDataSnapshot;
            if (snapshot == null || phoneDataSnapshotGeneration != documentsLoadGeneration ||
                    !phoneDataSnapshotMode.equals(phoneDataMode)) return "";
            int start = Math.max(0, Math.min(offset, snapshot.size()));
            int end = Math.min(snapshot.size(), start + PHONE_DATA_BATCH_SIZE);
            return buildPhoneDataRows(snapshot, start, end);
        }

        @JavascriptInterface
        public String loadMajorCategory(String category, int offset) {
            if (!slot1DocumentsHome || !"All Data".equals(phoneDataMode)) return "";
            if (!"Documents".equals(category) && !"Photo".equals(category) &&
                    !"Audio".equals(category) && !"Video".equals(category) &&
                    !"Other Data".equals(category)) return "";

            List<DocumentEntry> snapshot = phoneDataSnapshot;
            if (snapshot == null || phoneDataSnapshotGeneration != documentsLoadGeneration ||
                    !phoneDataSnapshotMode.equals(phoneDataMode)) return "";

            List<DocumentEntry> filtered = new ArrayList<>();
            for (DocumentEntry item : snapshot) {
                if (category.equals(item.filterType)) filtered.add(item);
            }

            int start = Math.max(0, Math.min(offset, filtered.size()));
            int end = Math.min(filtered.size(), start + PHONE_DATA_BATCH_SIZE);
            try {
                JSONObject out = new JSONObject();
                out.put("html", buildPhoneDataRows(filtered, start, end));
                out.put("loaded", end);
                out.put("total", filtered.size());
                return out.toString();
            } catch (Exception ignored) {
                return "";
            }
        }

        @JavascriptInterface
        public void selectMode(String mode) {
            if (!slot1DocumentsHome) return;
            if (!"All Data".equals(mode) && !"Documents".equals(mode) && !"Photo".equals(mode) &&
                    !"Audio".equals(mode) && !"Video".equals(mode) &&
                    !"Other Data".equals(mode)) return;
            phoneDataMode = mode;
            runOnUiThread(MainActivity.this::showDocumentsHome);
        }

        @JavascriptInterface
        public void shareSelected(String json) {
            if (!slot1DocumentsHome) return;
            shareSelectedPhoneData(json);
        }

        @JavascriptInterface
        public void removeSelected(String json) {
            if (!slot1DocumentsHome) return;
            requestDeleteSelectedPhoneData(json);
        }

        @JavascriptInterface
        public void requestAccess() {
            if (!slot1DocumentsHome) return;
            requestDocumentAccess();
        }

        @JavascriptInterface
        public void refresh() {
            if (!slot1DocumentsHome) return;
            runOnUiThread(MainActivity.this::showDocumentsHome);
        }
    }

    private Intent buildWebsiteFilePickerIntent(WebChromeClient.FileChooserParams params) {
        Intent pick = null;
        if (params != null) {
            try {
                pick = params.createIntent();
            } catch (Exception ignored) {
                pick = null;
            }
        }

        if (pick == null) {
            pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.setType("*/*");
        }

        if (TextUtils.isEmpty(pick.getType())) {
            pick.setType("*/*");
        }

        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            pick.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        }

        boolean multiple = params != null &&
                params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE;
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);

        // Some OEM pickers ignore the MIME type in FileChooserParams#createIntent().
        // Carry the site's accept= list explicitly when it contains usable MIME types.
        if (params != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            String[] accept = params.getAcceptTypes();
            ArrayList<String> clean = new ArrayList<>();
            if (accept != null) {
                for (String raw : accept) {
                    if (TextUtils.isEmpty(raw)) continue;
                    String[] parts = raw.split(",");
                    for (String part : parts) {
                        String mime = part == null ? "" : part.trim();
                        if (!TextUtils.isEmpty(mime) && mime.contains("/") && !clean.contains(mime)) {
                            clean.add(mime);
                        }
                    }
                }
            }
            if (!clean.isEmpty()) {
                pick.putExtra(Intent.EXTRA_MIME_TYPES, clean.toArray(new String[0]));
                if (clean.size() == 1) pick.setType(clean.get(0));
            }
        }

        return pick;
    }

    private Uri[] collectWebsiteFilePickerResult(int resultCode, Intent data) {
        if (resultCode != RESULT_OK || data == null) return null;

        ArrayList<Uri> selected = new ArrayList<>();

        // Read ClipData ourselves first. A few Android/OEM document providers return a
        // valid multiple selection here while WebChromeClient.parseResult() gives null.
        try {
            ClipData clip = data.getClipData();
            if (clip != null) {
                for (int i = 0; i < clip.getItemCount(); i++) {
                    Uri uri = clip.getItemAt(i).getUri();
                    addWebsiteUploadUri(selected, uri, data);
                }
            }
        } catch (Exception ignored) {}

        try {
            addWebsiteUploadUri(selected, data.getData(), data);
        } catch (Exception ignored) {}

        // Keep the platform parser as a compatibility fallback for providers that package
        // their result differently.
        if (selected.isEmpty()) {
            try {
                Uri[] parsed = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                if (parsed != null) {
                    for (Uri uri : parsed) addWebsiteUploadUri(selected, uri, data);
                }
            } catch (Exception ignored) {}
        }

        if (selected.isEmpty()) return null;
        return selected.toArray(new Uri[0]);
    }

    private void addWebsiteUploadUri(ArrayList<Uri> selected, Uri uri, Intent resultData) {
        if (uri == null || selected.contains(uri)) return;

        // Retain read access when the provider supports it. This prevents a selected
        // content:// URI from becoming unreadable before the webpage starts uploading.
        if ("content".equalsIgnoreCase(uri.getScheme()) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            int returnedFlags = resultData == null ? 0 : resultData.getFlags();
            int takeFlags = returnedFlags &
                    (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if ((returnedFlags & Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) != 0 &&
                    (takeFlags & Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0) {
                try {
                    getContentResolver().takePersistableUriPermission(uri,
                            takeFlags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}
            }
        }

        selected.add(uri);
    }

    private void finishSiteLocation(boolean allow) {
        GeolocationPermissions.Callback callback = pendingGeoCallback;
        String origin = pendingGeoOrigin;
        pendingGeoCallback = null;
        pendingGeoOrigin = null;
        pendingGeoView = null;
        AlertDialog dialog = geoConsentDialog;
        geoConsentDialog = null;
        if (dialog != null) dialog.dismiss();
        if (callback != null && origin != null) {
            try { callback.invoke(origin, allow, false); } catch (Exception ignored) {}
        }
    }

    private void requestSiteLocation(WebView owner, String origin, GeolocationPermissions.Callback callback) {
        if (isFinishing() || isDestroyed() || locationPermissionInFlight) {
            callback.invoke(origin, false, false);
            return;
        }
        finishSiteLocation(false);
        pendingGeoCallback = callback;
        pendingGeoOrigin = origin;
        pendingGeoView = owner;
        geoConsentDialog = new AlertDialog.Builder(this)
                .setTitle("Website Location Permission")
                .setMessage(origin + "\n\nइस website को आपकी location इस्तेमाल करने दें?")
                .setNegativeButton("Block", (dialog, which) -> finishSiteLocation(false))
                .setOnCancelListener(dialog -> finishSiteLocation(false))
                .setPositiveButton("Allow", (dialog, which) -> {
                    geoConsentDialog = null;
                    if (pendingGeoCallback == null) return;
                    if (hasLocationPermission()) {
                        finishSiteLocation(true);
                    } else {
                        locationPermissionInFlight = true;
                        try {
                            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
                        } catch (Exception e) {
                            locationPermissionInFlight = false;
                            finishSiteLocation(false);
                        }
                    }
                }).show();
    }

    private boolean hasLocationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_FILE_CHOOSER) {
            ValueCallback<Uri[]> callback = pendingFileChooser;
            pendingFileChooser = null;

            if (callback != null) {
                Uri[] result = collectWebsiteFilePickerResult(resultCode, data);
                try {
                    callback.onReceiveValue(result);
                } catch (Exception ignored) {
                    // The page may have navigated away while the picker was open.
                }
            }
            return;
        }

        if (requestCode == REQ_EXPORT_SETTINGS) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                writeSettingsBackup(data.getData());
            }
            return;
        }

        if (requestCode == REQ_IMPORT_SETTINGS) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                restoreSettingsBackup(data.getData());
            }
            return;
        }

        if (requestCode == REQ_PHONE_DATA_DELETE) {
            if (slot1DocumentsHome) showDocumentsHome();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQ_DOCUMENT_ACCESS) {
            documentAccessRequested = false;
            if (slot1DocumentsHome) showDocumentsHome();
            return;
        }

        if (requestCode != REQ_LOCATION) return;

        locationPermissionInFlight = false;
        boolean granted = hasLocationPermission();
        finishSiteLocation(granted);

        if (!granted) {
            showLocationPermissionHelp();
        }
    }

    private void showLocationPermissionHelp() {
        if (isFinishing()) return;
        new AlertDialog.Builder(this)
                .setTitle("Location Permission")
                .setMessage("इस website को location चाहिए। Location permission Allow करें। अगर popup दोबारा नहीं आता है, App Settings में Location permission ON करें।")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("App Settings", (d, w) -> {
                    try {
                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    } catch (Exception ignored) {}
                })
                .show();
    }

    private boolean isPhoneDataUrl(String url) {
        return url != null && "sts.documents".equals(Uri.parse(url).getHost());
    }

    @Override
    public void onBackPressed() {
        if (videoController != null && videoController.exitFullscreen()) return;
        if (slot2Button != null && slot2Button.hasFocus()) {
            finishAddressEditing();
            return;
        }
        if (activeSlot == 1 && slot1DocumentsHome) {
            handlePhoneDataBack();
            return;
        }
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else if (webView != null) {
            // D2 leaves the existing file-list view intact, including its scroll/selection.
            if (slot1DocumentsHome && webView1 != null) showWebView(1);
            else showDocumentsHome();
        } else {
            moveTaskToBack(true);
        }
    }

    private void handlePhoneDataBack() {
        if (phoneBackPending) return;
        if (webView1 == null) { moveTaskToBack(true); return; }
        phoneBackPending = true;
        final int generation = documentsLoadGeneration;
        webView1.evaluateJavascript(
                "typeof stsHandleBack==='function' ? stsHandleBack() : false", handled -> {
                    phoneBackPending = false;
                    if (isFinishing() || isDestroyed() || activeSlot != 1 || !slot1DocumentsHome
                            || generation != documentsLoadGeneration) return;
                    if (!"true".equals(handled)) moveTaskToBack(true);
                });
    }

    private void destroyWebView(WebView target) {
        if (target == null) return;
        target.stopLoading();
        target.loadUrl("about:blank");
        target.clearHistory();
        target.removeAllViews();
        target.destroy();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            synchronized (phoneDataThumbCache) {
                phoneDataThumbCache.evictAll();
            }
        }
    }

    @Override
    public void onLowMemory() {
        synchronized (phoneDataThumbCache) {
            phoneDataThumbCache.evictAll();
        }
        super.onLowMemory();
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= 33 && systemBackCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(systemBackCallback);
            systemBackCallback = null;
        }
        if (videoController != null) videoController.destroy();
        finishSiteLocation(false);
        if (pendingFileChooser != null) {
            try { pendingFileChooser.onReceiveValue(null); } catch (Exception ignored) {}
            pendingFileChooser = null;
        }
        stopLoadingLogoAnimation();
        if (loadingOverlay != null) loadingOverlay.animate().cancel();
        destroyWebView(webView1);
        destroyWebView(webView2);
        webView1 = null;
        webView2 = null;
        webView = null;
        synchronized (phoneDataThumbCache) {
            phoneDataThumbCache.evictAll();
        }
        super.onDestroy();
    }

    private static class DownloadResolvedMeta {
        String finalUrl = "";
        String contentDisposition = "";
        String contentType = "";
        String headerName = "";
    }

    private static class DownloadHint {
        final String href;
        final String name;
        final long timeMs;

        DownloadHint(String href, String name, long timeMs) {
            this.href = href == null ? "" : href;
            this.name = name == null ? "" : name;
            this.timeMs = timeMs;
        }
    }

    private static class DocumentEntry {
        final String uri;
        final String name;
        final String mime;
        final String category;
        final String filterType;
        final long size;
        final long modified;

        DocumentEntry(String uri, String name, String mime, String category, String filterType, long size, long modified) {
            this.uri = uri;
            this.name = name;
            this.mime = mime;
            this.category = category;
            this.filterType = filterType;
            this.size = size;
            this.modified = modified;
        }
    }

    private static class Site {
        String name;
        String url;
        String passwordHash;
        int order = Integer.MAX_VALUE;

        Site(String name, String url, String passwordHash) {
            this.name = name;
            this.url = url;
            this.passwordHash = passwordHash == null ? "" : passwordHash;
        }

        boolean hasPassword() {
            return passwordHash != null && !passwordHash.isEmpty();
        }
    }
}
