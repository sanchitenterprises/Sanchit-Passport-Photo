package com.sts.fastbrowser;

import android.graphics.*;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import java.util.ArrayList;

/** Page-relative marks, independent of raster resolution and zoom. */
final class PdfEditMark {
 final int page, color, background; final String kind, text, oldText; final float size;
 final ArrayList<float[]> points = new ArrayList<>();
 PdfEditMark(int page,String kind,int color,float size,String text){this(page,kind,color,size,text,"");}
 PdfEditMark(int page,String kind,int color,float size,String text,String oldText){this(page,kind,color,size,text,oldText,Color.WHITE);}
 PdfEditMark(int page,String kind,int color,float size,String text,String oldText,int background){
  this.page=page;this.kind=kind;this.color=color;this.size=size;this.text=text;this.oldText=oldText;this.background=background;
 }
 void point(float x,float y){points.add(new float[]{Math.max(0,Math.min(1,x)),Math.max(0,Math.min(1,y))});}
 private TextPaint ocrPaint(float height){
  TextPaint tp=new TextPaint(Paint.ANTI_ALIAS_FLAG|Paint.SUBPIXEL_TEXT_FLAG);
  tp.setColor(color);
  tp.setTypeface(Typeface.create("serif",Typeface.NORMAL));
  tp.setTextSize(Math.max(5f,height*0.89f));
  return tp;
 }
 boolean canFitScanText(float pageAspect){
  if(!"ScanReplace".equals(kind)||points.size()<2)return true;
  // Both text measurement and the available rectangle are proportional to
  // viewport height. Reject overlong replacements rather than distorting size.
  float[] first=points.get(0),last=points.get(1);
  TextPaint paint=ocrPaint(1000f*(last[1]-first[1]));
  float allowed=(last[0]-first[0])*1000f*pageAspect;
  return paint.measureText(text)<=allowed*1.10f;
 }
 void draw(Canvas canvas,float width,float height){
  if(points.isEmpty())return;
  Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(color);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
  float[] first=points.get(0);
  if("Replace".equals(kind)&&points.size()>1){
   // Do not falsely preview a different font with a white rectangle over live
   // searchable text. Keep the PDF visible and show the pending edit outline.
   float[] end=points.get(1);p.setColor(Color.rgb(0,121,107));p.setStyle(Paint.Style.STROKE);
   p.setStrokeWidth(Math.max(1f,width*0.001f));
   canvas.drawRect(first[0]*width,first[1]*height,end[0]*width,end[1]*height,p);
   return;
  }
  if("ScanReplace".equals(kind)&&points.size()>1){
   float[] end=points.get(1);
   float x=first[0]*width,y=first[1]*height,r=end[0]*width,b=end[1]*height;
   Paint cover=new Paint(Paint.ANTI_ALIAS_FLAG);cover.setColor(background);
   // Cover glyph anti-aliasing at all four edges without reaching nearby rules.
   float pad=Math.min(1.25f,Math.max(0.4f,(b-y)*0.025f));
   canvas.drawRect(x-pad,y-pad,r+pad,b+pad,cover);
   TextPaint tp=ocrPaint(b-y);
   float measured=tp.measureText(text);
   if(measured>r-x && measured>0)tp.setTextScaleX(Math.max(0.9f,(r-x)/measured));
   float baseline=b-Math.max(0f,(b-y-tp.getTextSize())*0.2f);
   canvas.drawText(text,x,baseline,tp);
   return;
  }
  if("Text".equals(kind)){
   TextPaint tp=new TextPaint(p);tp.setTextSize(width*size);tp.setTypeface(Typeface.DEFAULT);
   int available=Math.max(1,Math.round(width*(1-first[0])));
   StaticLayout layout=StaticLayout.Builder.obtain(text,0,text.length(),tp,available).setAlignment(Layout.Alignment.ALIGN_NORMAL).setIncludePad(false).build();
   canvas.save();canvas.translate(first[0]*width,first[1]*height);layout.draw(canvas);canvas.restore();return;
  }
  p.setStrokeWidth(width*size);p.setStyle(Paint.Style.STROKE);
  if("Highlight".equals(kind)){p.setColor(Color.YELLOW);p.setAlpha(85);}
  Path path=new Path();path.moveTo(first[0]*width,first[1]*height);
  for(int i=1;i<points.size();i++){float[] q=points.get(i);path.lineTo(q[0]*width,q[1]*height);}
  if(points.size()==1){p.setStyle(Paint.Style.FILL);canvas.drawCircle(first[0]*width,first[1]*height,width*size/2,p);}else canvas.drawPath(path,p);
 }
}
