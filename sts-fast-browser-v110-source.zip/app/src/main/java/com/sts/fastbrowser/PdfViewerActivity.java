package com.sts.fastbrowser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.text.TextUtils;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.pdmodel.PDPage;
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle;
import com.tom_roush.pdfbox.pdmodel.interactive.action.PDAction;
import com.tom_roush.pdfbox.pdmodel.interactive.action.PDActionURI;
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotation;
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationLink;
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PdfViewerActivity extends Activity {
    private static final int REQ_STORAGE = 701;

    private String sourceUrl;
    private Uri sourceUri;
    private String fileName;
    private String cookie;
    private String userAgent;
    private int browserSlot = 1;

    private File sourceFile;
    private File pdfFile;
    private ParcelFileDescriptor pdfPfd;
    private PdfRenderer pdfRenderer;
    private PDDocument textDocument;

    private LinearLayout pages;
    private ScrollView pdfScroll;
    private TextView status;
    private boolean destroyed = false;
    private int basePageRenderWidth = 900;
    private final ExecutorService pdfRenderExecutor = Executors.newSingleThreadExecutor();
    private final Runnable visiblePageUpdater = this::updateVisiblePdfPages;
    private final Map<Integer, List<PdfLink>> pageLinks = new HashMap<>();
    private final Set<Integer> pageLinksScanned = new HashSet<>();
    private int pendingImagePage = -1;
    private String pendingPageFormat = null;

    private final ArrayList<PdfEditMark> pdfMarks = new ArrayList<>();
    private final ArrayList<ArrayList<PdfEditMark>> pdfUndo = new ArrayList<>(), pdfRedo = new ArrayList<>();
    private boolean pdfEditing, pdfSaving, pdfEditable = true;
    private String pdfTool = "Move";
    private boolean textBold, textPlacementArmed;
    private PdfEditMark lastPlacedText;
    private LinearLayout styleRow, paletteRow;
    private TextView boldButton, colourButton;
    private int inkColor = Color.BLACK;
    private int highlightColor=Color.YELLOW, textColor=Color.BLACK;
    private int sizeStep = 1;
    private LinearLayout editPanel, textRow, saveRow, exitRow;
    private android.window.OnBackInvokedCallback pdfBackCallback;
    private EditText inlineText, inlineName;
    private TextView editHint, textActionButton;
    private PdfTextSelection.Selection replacementSelection;
    private PdfScanTextReplace.Found replacementScanSelection;
    // Drag-selection belongs to the existing in-viewer Replace editor; no new activity/window.
    private int textSpanPage=-1;
    private float spanStartX,spanStartY,spanEndX,spanEndY;
    private boolean spanActive,spanDragging;
    private int spanHandle=-1;
    private static final float SPAN_HANDLE_RADIUS=0.025f;
    private int replacementRequestId;
    // Native PDF replacements are never faked by text painted over the old page.
    // Preview is rendered from an actual, temporarily patched PDF content stream.
    private boolean replacementApplying;
    private int replacementPreviewVersion;
    private int replacementPreviewPage = -1;
    private Bitmap replacementPreviewBitmap;


    private void buildPdfEditor(LinearLayout root) {
        editPanel = new LinearLayout(this); editPanel.setOrientation(LinearLayout.VERTICAL);
        editPanel.setBackgroundColor(Color.parseColor("#E3EAF4")); editPanel.setVisibility(View.GONE);
        android.widget.HorizontalScrollView scroll = new android.widget.HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false); scroll.setHorizontalFadingEdgeEnabled(true); scroll.setFadingEdgeLength(dp(12));
        LinearLayout tools = new LinearLayout(this); scroll.addView(tools);
        for (String label : new String[]{"Text", "Replace", "Highlighter", "Undo", "Redo"}) {
            TextView button = editButton(label);
            button.setTag(label);button.setPadding(dp(6),0,dp(6),0);button.setOnClickListener(v -> pdfEditorAction(label)); tools.addView(button);
            int icon = "Undo".equals(label)?R.drawable.ic_undo:"Redo".equals(label)?R.drawable.ic_redo:0;
            if(icon!=0){android.graphics.drawable.Drawable glyph=getDrawable(icon);glyph.setBounds(0,0,dp(18),dp(18));button.setCompoundDrawables(glyph,null,null,null);button.setCompoundDrawablePadding(dp(5));}
        }
        editPanel.addView(scroll, new LinearLayout.LayoutParams(-1, dp(44)));
        textRow = new LinearLayout(this); textRow.setGravity(Gravity.CENTER_VERTICAL);
        inlineText = new EditText(this); inlineText.setTextSize(15); inlineText.setHint("Text लिखें, फिर PDF पर जगह छुएँ");
        inlineText.setMaxLines(2); inlineText.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(500)});
        textRow.addView(inlineText,new LinearLayout.LayoutParams(0,dp(52),1));
        textActionButton = editButton("Place");
        textActionButton.setOnClickListener(v -> {
            if (isPdfReplacementMode()) applyPdfReplacement();
            else {
                if(inlineText.getText().toString().trim().isEmpty()){
                    editHint.setText("पहले Text लिखें, फिर Place दबाएँ");return;
                }
                textPlacementArmed=true;lastPlacedText=null;
                editHint.setText("PDF पर एक बार छुएँ; Text सिर्फ एक बार Place होगा");
                hidePdfKeyboard();
            }
        });
        textRow.addView(textActionButton);
        textRow.setVisibility(View.GONE); editPanel.addView(textRow);
        styleRow = new LinearLayout(this);styleRow.setGravity(Gravity.CENTER_VERTICAL);
        boldButton=editButton("Bold: OFF");boldButton.setOnClickListener(v->{
            textBold=!textBold;boldButton.setText(textBold?"Bold: ON":"Bold: OFF");
            modifyPlacedTextStyle();
        });
        styleRow.addView(boldButton,new LinearLayout.LayoutParams(-2,dp(40)));
        colourButton=editButton("Color");colourButton.setOnClickListener(v->{
            paletteRow.setVisibility(paletteRow.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE);
        });
        styleRow.addView(colourButton,new LinearLayout.LayoutParams(-2,dp(40)));
        styleRow.setVisibility(View.GONE);editPanel.addView(styleRow);
        paletteRow=new LinearLayout(this);paletteRow.setGravity(Gravity.CENTER_VERTICAL);
        int[] colors={Color.BLACK,Color.WHITE,Color.RED,Color.BLUE,Color.GREEN,Color.YELLOW,
            Color.parseColor("#FF9800"),Color.parseColor("#9C27B0")};
        for(int color:colors){
            TextView swatch=editButton("●");swatch.setTextSize(23);swatch.setTextColor(color);
            swatch.setContentDescription(String.format(java.util.Locale.ROOT,"Text color #%06X",color&0xFFFFFF));
            swatch.setOnClickListener(v->{inkColor=color;if("Text".equals(pdfTool))textColor=color;else if("Highlight".equals(pdfTool))highlightColor=color;paletteRow.setVisibility(View.GONE);modifyPlacedTextStyle();updateEditHint();});
            paletteRow.addView(swatch,new LinearLayout.LayoutParams(0,dp(40),1));
        }
        paletteRow.setVisibility(View.GONE);editPanel.addView(paletteRow);
        saveRow = new LinearLayout(this);
        inlineName = new EditText(this);inlineName.setSingleLine(true);inlineName.setTextSize(14);inlineName.setText(fileName.replaceAll("(?i)\\.pdf$", "")+"_edited.pdf");
        saveRow.addView(inlineName,new LinearLayout.LayoutParams(0,dp(48),1));
        TextView copy = editButton("Save copy");copy.setOnClickListener(v -> savePdfEdits(false));saveRow.addView(copy);
        saveRow.setVisibility(View.GONE);editPanel.addView(saveRow);
        editHint = new TextView(this);editHint.setTextColor(Color.parseColor("#355C62"));editHint.setTextSize(12);editHint.setPadding(dp(12),dp(4),dp(12),dp(6));editPanel.addView(editHint);
        exitRow=new LinearLayout(this);exitRow.setVisibility(View.GONE);
        TextView keep=editButton("Keep editing"), discard=editButton("Discard & close");
        keep.setOnClickListener(v->exitRow.setVisibility(View.GONE));discard.setOnClickListener(v->{if(!pdfSaving)finish();});
        exitRow.addView(keep);exitRow.addView(discard);editPanel.addView(exitRow);
        root.addView(editPanel,new LinearLayout.LayoutParams(-1,-2));
    }
    private TextView editButton(String label) {
        TextView b=new TextView(this);b.setText(label);b.setTextSize(14);b.setTextColor(Color.parseColor("#162326"));
        b.setGravity(Gravity.CENTER);b.setPadding(dp(12),0,dp(12),0);b.setMinHeight(dp(44));b.setContentDescription(label);
        android.util.TypedValue attr=new android.util.TypedValue();getTheme().resolveAttribute(android.R.attr.selectableItemBackground,attr,true);b.setBackgroundResource(attr.resourceId);return b;
    }
    private void startPdfEditing() {
        if(!pdfEditable){Toast.makeText(this,"इस protected PDF में editing उपलब्ध नहीं है",Toast.LENGTH_LONG).show();return;}
        pdfEditing=true;editPanel.setVisibility(View.VISIBLE);pdfTool="Move";
        textPlacementArmed=false;styleRow.setVisibility(View.GONE);paletteRow.setVisibility(View.GONE);
        textRow.setVisibility(View.GONE);updateEditHint();
    }
    private void pdfEditorAction(String action) {
        if(pdfSaving)return;
        if("Undo".equals(action)||"Redo".equals(action)){
            ArrayList<ArrayList<PdfEditMark>> from="Undo".equals(action)?pdfUndo:pdfRedo;
            ArrayList<ArrayList<PdfEditMark>> to="Undo".equals(action)?pdfRedo:pdfUndo;
            if(!from.isEmpty()){
                to.add(new ArrayList<>(pdfMarks));pdfMarks.clear();pdfMarks.addAll(from.remove(from.size()-1));
                lastPlacedText=null;textPlacementArmed=false;
                refreshNativeReplacePreview();redrawPdfMarks();
            }
        }else if("Save".equals(action)){savePdfEdits(true);return;}
        else if("Save As".equals(action)){
            saveRow.setVisibility(saveRow.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE);return;
        }else{
            pdfTool="Highlighter".equals(action)?"Highlight":action;
            if("Highlight".equals(pdfTool))inkColor=highlightColor;
            if("Text".equals(pdfTool))inkColor=textColor;
            replacementSelection=null;replacementScanSelection=null;replacementRequestId++;
            spanActive=false;spanDragging=false;textSpanPage=-1;
            textPlacementArmed=false;lastPlacedText=null;
            boolean textMode="Text".equals(pdfTool)||isPdfReplacementMode();
            textRow.setVisibility(textMode?View.VISIBLE:View.GONE);
            styleRow.setVisibility(("Text".equals(pdfTool)||"Highlight".equals(pdfTool))?View.VISIBLE:View.GONE);
            boldButton.setVisibility("Text".equals(pdfTool)?View.VISIBLE:View.GONE);
            paletteRow.setVisibility(View.GONE);
            textActionButton.setText(isPdfReplacementMode()?"Apply":"Place");
            inlineText.setHint(isPdfReplacementMode()?"पुराना Text चुनें, नया Text लिखें":"Text लिखें और Place दबाएँ");
            if(isPdfReplacementMode())inlineText.setText("");
            hidePdfKeyboard();
        }
        updateEditHint();redrawPdfMarks();
    }
    private void modifyPlacedTextStyle(){
        if(!"Text".equals(pdfTool))return;
        PdfEditMark original=lastPlacedText;
        if(original==null||!pdfMarks.contains(original))return;
        PdfEditMark updated=original.copy();updated.color=inkColor;updated.bold=textBold;
        replacePdfMark(original,updated);lastPlacedText=updated;
    }
    /** Only swap a clone, never mutate a committed mark: Undo must restore prior size/position/style. */
    private void replacePdfMark(PdfEditMark original,PdfEditMark updated){
        int index=pdfMarks.indexOf(original);if(index<0)return;
        pdfUndo.add(new ArrayList<>(pdfMarks));if(pdfUndo.size()>30)pdfUndo.remove(0);
        pdfRedo.clear();pdfMarks.set(index,updated);updateEditHint();redrawPdfMarks();
    }
    private void updateEditHint(){
        android.widget.HorizontalScrollView strip=(android.widget.HorizontalScrollView)editPanel.getChildAt(0);
        LinearLayout buttons=(LinearLayout)strip.getChildAt(0);
        for(int i=0;i<buttons.getChildCount();i++){
            TextView button=(TextView)buttons.getChildAt(i);String label=String.valueOf(button.getTag());
            boolean selected=("Highlighter".equals(label)?"Highlight":label).equals(pdfTool);
            button.setTypeface(null,selected?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL);
            button.setTextColor(selected?Color.parseColor("#00796B"):Color.parseColor("#162326"));
            button.setEnabled(!pdfSaving&&(!"Undo".equals(label)||!pdfUndo.isEmpty())&&(!"Redo".equals(label)||!pdfRedo.isEmpty()));
            button.setAlpha(button.isEnabled()?1f:0.5f);
        }
        String prompt="Move".equals(pdfTool)?"Scroll / zoom":
            "Text".equals(pdfTool)?"लिखें → Place → Tap; Text को खींचें या दो उँगली से Resize करें":
            "Replace".equals(pdfTool)?"एक शब्द पर Tap, कई शब्दों के लिए Drag; Handles से Select बदलें":
            "Highlight".equals(pdfTool)?"Color चुनकर Highlight करें":"";
        editHint.setText(pdfSaving?"PDF Save हो रही है…":prompt+" • "+pdfMarks.size()+" edits");
    }
    private boolean isPdfReplacementMode(){return "Replace".equals(pdfTool);}
    private void clearPdfSpan(){spanActive=false;spanDragging=false;textSpanPage=-1;spanHandle=-1;redrawPdfMarks();}
    /** Selection endpoints are page-normalized to survive zoom and scrolling. */
    private void selectPdfRange(int page,float sx,float sy,float ex,float ey){
        replacementSelection=null;replacementScanSelection=null;
        final int request=++replacementRequestId;
        editHint.setText("चुने हुए PDF text की जाँच कर रहे हैं…");
        pdfRenderExecutor.execute(()->{
            PdfTextSelection.Selection nativeText=null;
            PdfScanTextReplace.Found scanText=null;
            String error=null;
            try{
                synchronized(this){if(textDocument!=null)nativeText=PdfTextSelection.pickRange(textDocument,page,sx,sy,ex,ey);}
                if(nativeText==null){
                    Bitmap bitmap=null;
                    try{bitmap=renderPageBitmap(page,Math.min(1900,Math.max(1500,basePageRenderWidth*2)));
                        scanText=PdfScanTextReplace.recognizeRange(bitmap,page,sx,sy,ex,ey);
                    }finally{if(bitmap!=null&&!bitmap.isRecycled())bitmap.recycle();}
                }
            }catch(Exception e){error=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();}
            final PdfTextSelection.Selection selected=nativeText;
            final PdfScanTextReplace.Found scanned=scanText;
            final String failure=error;
            runOnUiThread(()->{
                if(destroyed||!pdfEditing|| !isPdfReplacementMode()||replacementRequestId!=request)return;
                replacementSelection=selected;replacementScanSelection=scanned;
                if(selected!=null){
                    inlineText.setText(selected.original);
                    editHint.setText("चुना हुआ text: "+selected.original+" • अब नया text लिखें और Apply करें");
                }else if(scanned!=null){
                    inlineText.setText(scanned.text);
                    editHint.setText(scanned.complexBackground?
                        "चयन मिला, लेकिन stamp/line/background है; सुरक्षित Replace संभव नहीं":
                        "Scanned selection: "+scanned.text+" • font केवल अनुमानित होगा");
                }else{
                    inlineText.setText("");
                    editHint.setText(failure==null?"इस selection में PDF text नहीं मिला; handles बदलें":
                        "Selection नहीं मिला: "+failure);
                }
                redrawPdfMarks();
            });
        });
    }
    private void selectPdfText(int page,float x,float y){
        replacementSelection=null;
        replacementScanSelection=null;
        final int request=++replacementRequestId;
        editHint.setText("PDF का text पहचान रहे हैं…");
        pdfRenderExecutor.execute(()->{
            PdfTextSelection.Selection selected=null;
            PdfScanTextReplace.Found scanned=null;
            String error=null;
            try {
                synchronized(this){if(textDocument!=null)selected=PdfTextSelection.pick(textDocument,page,x,y);}
                if(selected==null){
                    Bitmap bitmap=null;
                    try {
                        bitmap=renderPageBitmap(page,Math.min(1900,Math.max(1500,basePageRenderWidth*2)));
                        scanned=PdfScanTextReplace.recognize(bitmap,page,x,y);
                    }finally{if(bitmap!=null&&!bitmap.isRecycled())bitmap.recycle();}
                }
            }catch(Exception e){error=e.getClass().getSimpleName();}
            final PdfTextSelection.Selection nativeText=selected;
            final PdfScanTextReplace.Found scanText=scanned;
            final String failure=error;
            runOnUiThread(()->{
                if(destroyed||!pdfEditing||!"Replace".equals(pdfTool)||replacementRequestId!=request)return;
                replacementSelection=nativeText;
                replacementScanSelection=scanText;
                if(nativeText!=null){
                    inlineText.setText(nativeText.original);
                    inlineText.setSelection(inlineText.length());
                    editHint.setText("Original PDF text: "+nativeText.original+" • बदलें और Apply दबाएँ");
                }else if(scanText!=null){
                    inlineText.setText(scanText.text);
                    inlineText.setSelection(inlineText.length());
                    editHint.setText(scanText.complexBackground
                            ?"Image text मिला, लेकिन पीछे stamp/line/background है; सुरक्षित Replace नहीं होगा"
                            :"Scanned text: "+scanText.text+" • रंग/आकार मिलाने की कोशिश होगी; exact font की गारंटी नहीं");
                }else{
                    editHint.setText(failure==null
                            ?"यहाँ text नहीं मिला; उसी शब्द पर tap करें या zoom बदलें"
                            :"Text पहचानने में समस्या ("+failure+"); यह PDF सुरक्षित है");
                }
            });
        });
    }
    private void applyPdfReplacement(){
        if(pdfSaving || replacementApplying)return;
        PdfTextSelection.Selection sel=replacementSelection;
        PdfScanTextReplace.Found scanned=replacementScanSelection;
        if(sel==null && scanned==null){editHint.setText("पहले पुराने PDF text को tap या Select करके चुनें");return;}
        String changed=inlineText.getText().toString().trim();
        if(changed.isEmpty()||changed.length()>500){editHint.setText("नया text 1 से 500 अक्षर रखें");return;}
        String original=sel!=null?sel.original:scanned.text;
        if(changed.equals(original)){editHint.setText("Text में कोई बदलाव नहीं है");return;}
        if(scanned!=null){
            if(scanned.complexBackground){editHint.setText("पीछे table line, stamp या image है; मिटाने से नुकसान होगा, इसलिए Replace रोका गया");return;}
            PdfEditMark mark=new PdfEditMark(scanned.page,"ScanReplace",scanned.foreground,
                    Math.max(0.005f,scanned.bottom-scanned.top),changed,original,scanned.background);
            mark.point(scanned.left,scanned.top);mark.point(scanned.right,scanned.bottom);
            if(!mark.canFitScanText(scanned.aspect)){
                editHint.setText("नया text पुरानी जगह में उसी size पर नहीं आएगा; छोटा text चुनें");return;
            }
            commitPdfMark(mark);
            editHint.setText("Scanned Replace ready • Save As से नई PDF बनेगी; original सुरक्षित रहेगा");
        }else{
            PdfEditMark mark=new PdfEditMark(sel.page,"Replace",Color.BLACK,
                    Math.max(0.008f,sel.height),changed,sel.original);
            mark.point(sel.left,sel.top);mark.point(sel.right,sel.bottom);
            // Validate before accepting the edit; an outline on top of the OLD
            // text is not a successful replacement. Use the same PDF mutation
            // code for this preview and Save, retaining its native font.
            replacementApplying=true;
            editHint.setText("Original font में बदलाव जाँच रहे हैं…");
            final ArrayList<PdfEditMark> nativeMarks=new ArrayList<>(pdfMarks);
            nativeMarks.add(mark);
            final int generation=++replacementPreviewVersion;
            pdfRenderExecutor.execute(() -> {
                Bitmap preview=null;String error=null;
                try{preview=renderActualNativeReplacement(nativeMarks,sel.page);}
                catch(Exception e){error=e.getMessage()==null?"Font / PDF structure unsupported":e.getMessage();}
                final Bitmap result=preview;final String failure=error;
                runOnUiThread(()->{
                    replacementApplying=false;
                    if(destroyed||generation!=replacementPreviewVersion){if(result!=null)result.recycle();return;}
                    if(result==null){editHint.setText("Replace नहीं हुआ: "+failure+" • Original सुरक्षित है");return;}
                    commitPdfMark(mark);
                    acceptNativePreview(sel.page,result);
                    editHint.setText("पुराना text हटकर नया original font में दिख रहा है • Save करें");
                    replacementSelection=null;replacementScanSelection=null;
                    clearPdfSpan();hidePdfKeyboard();
                });
            });
            return;
        }
        replacementSelection=null;replacementScanSelection=null;
        clearPdfSpan();hidePdfKeyboard();
    }
    /** Render an actual modified PDF page into memory; do not overlay old native text. */
    private Bitmap renderActualNativeReplacement(List<PdfEditMark> marks,int pageIndex) throws Exception {
        File temp=null;
        try {
            temp=File.createTempFile("sts-native-preview-", ".pdf", getCacheDir());
            try(PDDocument doc=PDDocument.load(pdfFile)){
                if(!doc.getCurrentAccessPermission().canModify())
                    throw new java.io.IOException("PDF editing is restricted");
                for(PdfEditMark m:marks)if("Replace".equals(m.kind))
                    PdfNativeTextReplace.replace(doc,m.page,m.oldText,m.text);
                doc.save(temp);
            }
            try(ParcelFileDescriptor fd=ParcelFileDescriptor.open(temp,ParcelFileDescriptor.MODE_READ_ONLY);
                PdfRenderer renderer=new PdfRenderer(fd);
                PdfRenderer.Page p=renderer.openPage(pageIndex)) {
                int w=Math.min(1900,Math.max(900,basePageRenderWidth*2));
                int h=Math.max(1,Math.round(w*p.getHeight()/(float)p.getWidth()));
                Bitmap bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
                try {
                    bmp.eraseColor(Color.WHITE);
                    p.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    return bmp;
                } catch(Exception e){bmp.recycle();throw e;}
            }
        } finally {if(temp!=null)temp.delete();}
    }
    private void acceptNativePreview(int page,Bitmap replacement){
        Bitmap old=replacementPreviewBitmap;
        replacementPreviewBitmap=replacement;
        replacementPreviewPage=page;
        if(old!=null && old!=replacement && !old.isRecycled())old.recycle();
        redrawPdfMarks();
    }
    private void refreshNativeReplacePreview(){
        int page=-1;
        for(PdfEditMark m:pdfMarks)if("Replace".equals(m.kind))page=m.page;
        final int forPage=page;
        final int gen=++replacementPreviewVersion;
        Bitmap old=replacementPreviewBitmap;
        replacementPreviewBitmap=null;replacementPreviewPage=-1;
        if(old!=null&&!old.isRecycled())old.recycle();
        if(page<0){redrawPdfMarks();return;}
        final ArrayList<PdfEditMark> snapshot=new ArrayList<>(pdfMarks);
        pdfRenderExecutor.execute(()->{
            Bitmap bmp=null;
            try{bmp=renderActualNativeReplacement(snapshot,forPage);}
            catch(Exception ignored){}
            final Bitmap ready=bmp;
            runOnUiThread(()->{
                if(destroyed || gen!=replacementPreviewVersion){if(ready!=null)ready.recycle();return;}
                if(ready!=null)acceptNativePreview(forPage,ready);
            });
        });
    }
    private void hidePdfKeyboard(){((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(inlineText.getWindowToken(),0);inlineText.clearFocus();}
    private void commitPdfMark(PdfEditMark mark){
        pdfUndo.add(new ArrayList<>(pdfMarks));if(pdfUndo.size()>30)pdfUndo.remove(0);pdfRedo.clear();pdfMarks.add(mark);updateEditHint();redrawPdfMarks();
    }
    private void redrawPdfMarks(){for(int i=0;i<pages.getChildCount();i++)pages.getChildAt(i).invalidate();}
    private void savePdfEdits(boolean original) {
        if(pdfSaving || replacementApplying || pdfFile==null)return;
        if(pdfMarks.isEmpty()){editHint.setText("पहले PDF में text / pen / highlight जोड़ें");return;}
        if(original){
            for(PdfEditMark mark:pdfMarks)if("ScanReplace".equals(mark.kind)){
                saveRow.setVisibility(View.VISIBLE);
                editHint.setText("Scanned PDF बदलाव के लिए Save As इस्तेमाल करें; original PDF सुरक्षित रहेगा");
                return;
            }
        }
        if(original && sourceUri==null){saveRow.setVisibility(View.VISIBLE);editHint.setText("Downloaded PDF के लिए Save copy करें");return;}
        if(!original && android.os.Build.VERSION.SDK_INT<29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){
            editHint.setText("Save copy के लिए storage permission दें और फिर Save copy दबाएँ");
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},705);return;
        }
        final String outputName=sanitize(inlineName.getText().toString().trim());
        if(!original && (outputName.length()<5 || !outputName.toLowerCase(Locale.ROOT).endsWith(".pdf"))){editHint.setText("नाम के अंत में .pdf रखें");return;}
        final ArrayList<PdfEditMark> marks=new ArrayList<>(pdfMarks);
        final File input=pdfFile;pdfSaving=true;hidePdfKeyboard();updateEditHint();
        pdfRenderExecutor.execute(() -> {
            File staged=null;
            try {
                staged=File.createTempFile("edited-", ".pdf",getCacheDir());
                try(PDDocument doc=PDDocument.load(input)){
                    if(!doc.getCurrentAccessPermission().canModify())throw new java.io.IOException("Editing not permitted");
                    // Modify original PDF text objects, not just paint an image over them.
                    // Unsupported/non-unique/subset-font cases fail safely, preserving edits.
                    for(PdfEditMark mark:marks)if("Replace".equals(mark.kind))
                        PdfNativeTextReplace.replace(doc,mark.page,mark.oldText,mark.text);
                    for(int pageIndex=0;pageIndex<doc.getNumberOfPages();pageIndex++){
                        boolean found=false;for(PdfEditMark mark:marks)
                            if(mark.page==pageIndex && !"Replace".equals(mark.kind)){found=true;break;}
                        if(!found)continue;
                        PDPage page=doc.getPage(pageIndex);PDRectangle box=page.getCropBox();int rotation=((page.getRotation()%360)+360)%360;
                        float w=box.getWidth(),h=box.getHeight();float displayW=rotation%180==0?w:h,displayH=rotation%180==0?h:w;
                        float factor=Math.min(3f,Math.min(2048f/Math.max(displayW,displayH),(float)Math.sqrt(4000000f/(displayW*displayH))));
                        Bitmap overlay=Bitmap.createBitmap(Math.max(1,Math.round(displayW*factor)),Math.max(1,Math.round(displayH*factor)),Bitmap.Config.ARGB_8888);
                        try {
                            android.graphics.Canvas canvas=new android.graphics.Canvas(overlay);
                            for(PdfEditMark mark:marks)if(mark.page==pageIndex && !"Replace".equals(mark.kind))
                                mark.draw(canvas,overlay.getWidth(),overlay.getHeight());
                            com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject image=com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory.createFromImage(doc,overlay);
                            try(com.tom_roush.pdfbox.pdmodel.PDPageContentStream stream=new com.tom_roush.pdfbox.pdmodel.PDPageContentStream(doc,page,com.tom_roush.pdfbox.pdmodel.PDPageContentStream.AppendMode.APPEND,true,true)){
                                float[] matrix=PdfEditGeometry.matrix(rotation,w,h,box.getLowerLeftX(),box.getLowerLeftY());
                                stream.drawImage(image,new com.tom_roush.pdfbox.util.Matrix(matrix[0],matrix[1],matrix[2],matrix[3],matrix[4],matrix[5]));
                            }
                        } finally {overlay.recycle();}
                    }
                    doc.save(staged);
                }
                if(original){try(InputStream in=new FileInputStream(staged);OutputStream out=getContentResolver().openOutputStream(sourceUri,"wt")){if(out==null)throw new java.io.IOException("Write permission unavailable");copy(in,out);}}
                else if(android.os.Build.VERSION.SDK_INT>=29){
                    ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,outputName);values.put(MediaStore.Downloads.MIME_TYPE,"application/pdf");values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/STS Fast Browser");
                    final File saved=staged;SafeMediaExport.write(this,MediaStore.Downloads.EXTERNAL_CONTENT_URI,values,out->{try(InputStream in=new FileInputStream(saved)){copy(in,out);}});
                }else{
                    File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"STS Fast Browser");dir.mkdirs();File target=new File(dir,outputName);int suffix=2;while(target.exists())target=new File(dir,outputName.substring(0,outputName.length()-4)+" ("+(suffix++)+").pdf");
                    boolean complete=false;try(InputStream in=new FileInputStream(staged);OutputStream out=new FileOutputStream(target)){copy(in,out);complete=true;}finally{if(!complete)target.delete();}
                }
                final File savedFile=staged;staged=null;
                synchronized(this){
                    if(destroyed){savedFile.delete();return;}
                    if(pdfRenderer!=null)pdfRenderer.close();if(pdfPfd!=null)pdfPfd.close();if(textDocument!=null)textDocument.close();
                    pdfFile=savedFile;textDocument=PDDocument.load(savedFile);pdfPfd=ParcelFileDescriptor.open(savedFile,ParcelFileDescriptor.MODE_READ_ONLY);pdfRenderer=new PdfRenderer(pdfPfd);pageLinks.clear();pageLinksScanned.clear();
                }
                runOnUiThread(()->{
                    if(destroyed)return;pdfSaving=false;pdfMarks.clear();pdfUndo.clear();pdfRedo.clear();
                    ++replacementPreviewVersion;
                    if(replacementPreviewBitmap!=null&&!replacementPreviewBitmap.isRecycled())replacementPreviewBitmap.recycle();
                    replacementPreviewBitmap=null;replacementPreviewPage=-1;
                    for(int i=0;i<pages.getChildCount();i++)if(pages.getChildAt(i) instanceof ZoomPageView)((ZoomPageView)pages.getChildAt(i)).releaseBitmap();
                    updateVisiblePdfPages();updateEditHint();editHint.setText(original?"PDF saved":"PDF copy Downloads में save हो गई");
                });
            }catch(Exception|OutOfMemoryError e){
                final String reason=(e.getMessage()==null?"PDF font or document unsupported":e.getMessage());
                runOnUiThread(()->{if(!destroyed){pdfSaving=false;
                    editHint.setText("Save नहीं हुआ; edits सुरक्षित हैं: "+reason);}});
            }
            finally{if(staged!=null)staged.delete();}
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PDFBoxResourceLoader.init(getApplicationContext());

        getWindow().setStatusBarColor(Color.parseColor("#355C62"));
        getWindow().setNavigationBarColor(Color.parseColor("#F2F5F4"));

        sourceUrl = getIntent().getStringExtra("pdf_url");
        sourceUri = getIntent().getData();
        fileName = getIntent().getStringExtra("pdf_name");
        cookie = getIntent().getStringExtra("pdf_cookie");
        userAgent = getIntent().getStringExtra("pdf_user_agent");
        browserSlot = getIntent().getIntExtra("pdf_slot", 1);
        if (browserSlot != 2) browserSlot = 1;

        if (sourceUri != null) {
            String externalName = resolveDisplayName(sourceUri);
            if (!TextUtils.isEmpty(externalName)) fileName = externalName;
        }
        if (TextUtils.isEmpty(fileName)) fileName = "Document.pdf";
        if (!fileName.toLowerCase(Locale.ROOT).endsWith(".pdf")) fileName += ".pdf";

        setTitle(fileName);
        setContentView(buildUi());
        if(android.os.Build.VERSION.SDK_INT>=33){pdfBackCallback=this::handlePdfBack;getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,pdfBackCallback);}
        loadPdf();
    }
    @Override public void onConfigurationChanged(android.content.res.Configuration config) {
        super.onConfigurationChanged(config);
        if(pdfRenderer==null || destroyed)return;
        for(int i=0;i<pages.getChildCount();i++)if(pages.getChildAt(i) instanceof ZoomPageView)((ZoomPageView)pages.getChildAt(i)).releaseBitmap();
        pdfRenderExecutor.execute(()->{try{if(!destroyed)renderAllPages();}catch(Exception ignored){}});
    }
    private void handlePdfBack(){
        if(pdfSaving)return;
        if(!pdfMarks.isEmpty()){startPdfEditing();exitRow.setVisibility(View.VISIBLE);editHint.setText("Unsaved edits • Save / Save As करें या Discard चुनें");return;}
        if(pdfEditing){pdfEditing=false;editPanel.setVisibility(View.GONE);return;}
        finish();
    }
    @Override public void onBackPressed(){handlePdfBack();}

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#EEF2F3"));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(6), dp(3), dp(4), dp(3));
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.parseColor("#D9F0EE"), Color.parseColor("#E3EAF4"), Color.parseColor("#EEE8F4")}
        );
        top.setBackground(bg);
        root.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        TextView title = new TextView(this);
        title.setText(fileName);
        title.setTextColor(Color.parseColor("#162326"));
        title.setTextSize(15);
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(10), 0, dp(8), 0);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        ImageButton menu = new ImageButton(this);
        menu.setImageResource(R.drawable.ic_more);
        menu.setScaleType(ImageButton.ScaleType.CENTER_INSIDE);
        menu.setPadding(dp(10), dp(10), dp(10), dp(10));
        ViewerStyle.icon(menu);
        menu.setContentDescription("Menu");
        top.addView(menu, new LinearLayout.LayoutParams(dp(42), ViewGroup.LayoutParams.MATCH_PARENT));
        menu.setOnClickListener(this::showMenu);

        buildPdfEditor(root);
        pdfScroll = new ScrollView(this);
        pdfScroll.setFillViewport(true);
        pdfScroll.setSmoothScrollingEnabled(true);
        pages = new LinearLayout(this);
        pages.setOrientation(LinearLayout.VERTICAL);
        pages.setGravity(Gravity.CENTER_HORIZONTAL);
        pages.setPadding(dp(6), dp(6), dp(6), dp(12));
        pages.setClipChildren(false);
        pdfScroll.addView(pages, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        pdfScroll.setOnScrollChangeListener((v, scrollX, scrollY, oldScrollX, oldScrollY) -> scheduleVisiblePageUpdate());
        root.addView(pdfScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        status = new TextView(this);
        status.setText("PDF loading...");
        status.setTextColor(Color.DKGRAY);
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(12), dp(32), dp(12), dp(32));
        pages.addView(status, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(110)));

        return root;
    }

    private void showMenu(View anchor) {
        CompactPopupMenu pm = new CompactPopupMenu(this, anchor, Gravity.END);
        pm.getMenu().add("Edit");
        pm.getMenu().add("Save");
        pm.getMenu().add("Save As");
        pm.getMenu().add("Share");
        pm.getMenu().add("Print");
        pm.getMenu().add("Download");
        pm.setOnMenuItemClickListener(item -> {
            if (pdfFile == null || !pdfFile.exists()) {
                Toast.makeText(this, "PDF अभी तैयार हो रहा है", Toast.LENGTH_SHORT).show();
                return true;
            }
            String t = String.valueOf(item.getTitle());
            if ("Edit".equals(t)) { startPdfEditing(); return true; }
            if ("Save".equals(t)||"Save As".equals(t)) {
                if(!pdfEditing)startPdfEditing();
                pdfEditorAction(t);return true;
            }
            if (!pdfMarks.isEmpty()) { startPdfEditing(); editHint.setText("पहले Save / Save As करें, फिर "+t); return true; }
            if ("Share".equals(t)) sharePdf();
            else if ("Print".equals(t)) printPdf();
            else if ("Download".equals(t)) saveToDownloads();
            return true;
        });
        pm.show();
    }

    private void loadPdf() {
        new Thread(() -> {
            try {
                File dir = new File(getCacheDir(), "pdf");
                if (!dir.exists()) dir.mkdirs();

                sourceFile = new File(dir, "source_" + System.currentTimeMillis() + "_" + sanitize(fileName));
                if (sourceUri != null && ("content".equalsIgnoreCase(sourceUri.getScheme()) || "file".equalsIgnoreCase(sourceUri.getScheme()))) {
                    copyUriToFile(sourceUri, sourceFile);
                } else {
                    download(sourceUrl, sourceFile);
                }

                openDocumentWithPassword(null, false);
            } catch (Exception e) {
                showOpenError();
            }
        }).start();
    }

    private void openDocumentWithPassword(String password, boolean fromPrompt) {
        new Thread(() -> {
            PDDocument doc = null;
            try {
                doc = PDDocument.load(sourceFile, password == null ? "" : password);
                if (destroyed) {
                    doc.close();
                    return;
                }

                closePdfResources();
                textDocument = doc;
                pdfEditable = !doc.isEncrypted() && doc.getCurrentAccessPermission().canModify();

                if (doc.isEncrypted()) {
                    File dir = new File(getCacheDir(), "pdf");
                    pdfFile = new File(dir, "view_" + System.currentTimeMillis() + "_" + sanitize(fileName));
                    doc.setAllSecurityToBeRemoved(true);
                    doc.save(pdfFile);
                } else {
                    pdfFile = sourceFile;
                }

                pdfPfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY);
                pdfRenderer = new PdfRenderer(pdfPfd);
                synchronized (this) {
                    pageLinks.clear();
                    pageLinksScanned.clear();
                }
                renderAllPages();
            } catch (InvalidPasswordException e) {
                if (doc != null) try { doc.close(); } catch (Exception ignored) {}
                runOnUiThread(() -> showPasswordDialog(fromPrompt));
            } catch (Exception e) {
                if (doc != null && doc != textDocument) try { doc.close(); } catch (Exception ignored) {}
                showOpenError();
            }
        }).start();
    }

    private void showPasswordDialog(boolean wasWrong) {
        if (isFinishing() || destroyed) return;

        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Password");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setPadding(dp(16), dp(4), dp(16), dp(4));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Password Protected PDF")
                .setMessage(wasWrong ? "Password गलत है। दोबारा डालें।" : "इस PDF को खोलने के लिए password डालें।")
                .setView(input)
                .setNegativeButton("Close", (d, w) -> finish())
                .setPositiveButton("Open", null)
                .create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String password = input.getText().toString();
                dialog.dismiss();
                status.setText("PDF opening...");
                openDocumentWithPassword(password, true);
            });
        });
        dialog.show();
    }

    private void ensurePdfLinks(int pageIndex) {
        synchronized (this) {
            if (textDocument == null || pageLinksScanned.contains(pageIndex)) return;
            pageLinksScanned.add(pageIndex);
            try {
                if (pageIndex < 0 || pageIndex >= textDocument.getNumberOfPages()) return;
                PDPage page = textDocument.getPage(pageIndex);
                PDRectangle box = page.getCropBox();
                if (box == null) box = page.getMediaBox();
                if (box == null) return;

                float pageW = box.getWidth();
                float pageH = box.getHeight();
                float boxLeft = box.getLowerLeftX();
                float boxBottom = box.getLowerLeftY();
                List<PdfLink> links = new ArrayList<>();

                List<PDAnnotation> annotations = page.getAnnotations();
                if (annotations == null) return;

                for (PDAnnotation annotation : annotations) {
                    if (!(annotation instanceof PDAnnotationLink)) continue;
                    PDAnnotationLink link = (PDAnnotationLink) annotation;
                    PDAction action = link.getAction();
                    if (!(action instanceof PDActionURI)) continue;

                    String uri = ((PDActionURI) action).getURI();
                    if (TextUtils.isEmpty(uri)) continue;
                    String lower = uri.toLowerCase(Locale.ROOT);
                    if (!(lower.startsWith("http://") || lower.startsWith("https://"))) continue;

                    PDRectangle rect = link.getRectangle();
                    if (rect == null) continue;

                    float left = rect.getLowerLeftX() - boxLeft;
                    float right = rect.getUpperRightX() - boxLeft;
                    float bottom = rect.getLowerLeftY() - boxBottom;
                    float top = rect.getUpperRightY() - boxBottom;

                    links.add(new PdfLink(
                            uri,
                            Math.min(left, right),
                            Math.max(left, right),
                            Math.min(bottom, top),
                            Math.max(bottom, top),
                            pageW,
                            pageH
                    ));
                }

                if (!links.isEmpty()) pageLinks.put(pageIndex, links);
            } catch (Exception ignored) {
            }
        }
    }

    private void openPdfLinkInBrowser(String url) {
        if (TextUtils.isEmpty(url)) return;
        try {
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("browser_open_url", url);
            intent.putExtra("browser_slot", browserSlot);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                    Intent.FLAG_ACTIVITY_CLEAR_TOP |
                    Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Link open नहीं हो पाया", Toast.LENGTH_SHORT).show();
        }
    }

    private static class PdfLink {
        final String url;
        final float left;
        final float right;
        final float bottom;
        final float top;
        final float pageWidth;
        final float pageHeight;

        PdfLink(String url, float left, float right, float bottom, float top,
                float pageWidth, float pageHeight) {
            this.url = url;
            this.left = left;
            this.right = right;
            this.bottom = bottom;
            this.top = top;
            this.pageWidth = pageWidth;
            this.pageHeight = pageHeight;
        }

        boolean contains(float x, float y) {
            return x >= left && x <= right && y >= bottom && y <= top;
        }
    }

    private void renderAllPages() throws Exception {
        int screen = getResources().getDisplayMetrics().widthPixels;
        basePageRenderWidth = Math.min(Math.max(640, screen - dp(12)), 1200);

        final int count;
        final float[] ratios;
        synchronized (this) {
            if (pdfRenderer == null) throw new IllegalStateException("PDF renderer unavailable");
            count = pdfRenderer.getPageCount();
            ratios = new float[count];
            for (int i = 0; i < count; i++) {
                PdfRenderer.Page page = pdfRenderer.openPage(i);
                try {
                    ratios[i] = page.getWidth() <= 0 ? 1.414f : (page.getHeight() / (float) page.getWidth());
                } finally {
                    page.close();
                }
            }
        }

        runOnUiThread(() -> {
            if (destroyed || pages == null) return;
            pages.removeCallbacks(visiblePageUpdater);
            pages.removeAllViews();

            int pageWidth = Math.max(1, getResources().getDisplayMetrics().widthPixels - dp(12));
            for (int i = 0; i < count; i++) {
                addPagePlaceholder(i, ratios[i], pageWidth);
            }

            pages.post(this::updateVisiblePdfPages);
        });
    }

    private void addPagePlaceholder(int pageIndex, float ratio, int pageWidth) {
        if (destroyed || pages == null) return;

        ZoomPageView iv = new ZoomPageView(this, pageIndex);
        iv.setBackgroundColor(Color.WHITE);
        iv.setContentDescription("PDF page " + (pageIndex + 1));

        int height = Math.max(dp(120), Math.round(pageWidth * Math.max(0.2f, ratio)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                height
        );
        lp.setMargins(0, 0, 0, dp(7));
        pages.addView(iv, lp);
    }

    private void scheduleVisiblePageUpdate() {
        if (destroyed || pages == null) return;
        pages.removeCallbacks(visiblePageUpdater);
        pages.postDelayed(visiblePageUpdater, 70);
    }

    private void updateVisiblePdfPages() {
        if (destroyed || pages == null || pdfScroll == null) return;
        int viewport = Math.max(1, pdfScroll.getHeight());
        int scrollY = pdfScroll.getScrollY();

        int loadStart = Math.max(0, scrollY - viewport);
        int loadEnd = scrollY + (viewport * 2);
        int keepStart = Math.max(0, scrollY - (viewport * 2));
        int keepEnd = scrollY + (viewport * 3);

        for (int i = 0; i < pages.getChildCount(); i++) {
            View child = pages.getChildAt(i);
            if (!(child instanceof ZoomPageView)) continue;
            ZoomPageView pageView = (ZoomPageView) child;
            int top = child.getTop();
            int bottom = child.getBottom();

            if (bottom >= loadStart && top <= loadEnd) {
                pageView.ensureBaseBitmap();
            } else if (bottom < keepStart || top > keepEnd) {
                pageView.releaseBaseBitmapOnly();
            }
        }
    }

    private synchronized Bitmap renderPageBitmap(int pageIndex, int targetW) throws Exception {
        if (pdfRenderer == null) throw new IllegalStateException("PDF renderer unavailable");
        PdfRenderer.Page page = pdfRenderer.openPage(pageIndex);
        try {
            int targetH = Math.max(1, Math.round(targetW * (page.getHeight() / (float) page.getWidth())));
            Bitmap bmp = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888);
            bmp.eraseColor(Color.WHITE);
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            return bmp;
        } finally {
            page.close();
        }
    }

    private void showPageActions(int pageIndex) {
        if(pdfSaving)return;
        if(!pdfMarks.isEmpty()){startPdfEditing();editHint.setText("पहले edits Save करें, फिर page export करें");return;}
        if (isFinishing() || destroyed) return;
        new AlertDialog.Builder(this)
                .setTitle("Page " + (pageIndex + 1))
                .setItems(new String[]{"Save Page", "Copy Text"}, (d, which) -> {
                    if (which == 0) showSavePageFormats(pageIndex);
                    else showPageText(pageIndex);
                })
                .show();
    }

    private void showSavePageFormats(int pageIndex) {
        new AlertDialog.Builder(this)
                .setTitle("Save Page " + (pageIndex + 1))
                .setItems(new String[]{"JPG", "PNG", "PDF"}, (d, which) -> {
                    if (which == 0) savePageAsImage(pageIndex, "jpg");
                    else if (which == 1) savePageAsImage(pageIndex, "png");
                    else savePageAsPdf(pageIndex);
                })
                .show();
    }

    private void showPageText(int pageIndex) {
        new Thread(() -> {
            try {
                String text;
                synchronized (this) {
                    if (textDocument == null) throw new IllegalStateException("PDF text unavailable");
                    PDFTextStripper stripper = new PDFTextStripper();
                    stripper.setStartPage(pageIndex + 1);
                    stripper.setEndPage(pageIndex + 1);
                    text = stripper.getText(textDocument);
                }
                final String finalText = text == null ? "" : text.trim();
                runOnUiThread(() -> {
                    if (destroyed || isFinishing() || isDestroyed()) return;
                    if (finalText.isEmpty()) {
                        Toast.makeText(this, "इस page में selectable text नहीं मिला", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    EditText box = new EditText(this);
                    box.setText(finalText);
                    box.setTextSize(15);
                    box.setTextColor(Color.parseColor("#172326"));
                    box.setBackgroundColor(Color.WHITE);
                    box.setPadding(dp(14), dp(10), dp(14), dp(10));
                    box.setTextIsSelectable(true);
                    box.setKeyListener(null);

                    ScrollView scroll = new ScrollView(this);
                    scroll.addView(box, new ScrollView.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                    ));

                    new AlertDialog.Builder(this)
                            .setTitle("Page " + (pageIndex + 1) + " Text")
                            .setView(scroll)
                            .setNegativeButton("Close", null)
                            .setPositiveButton("Copy All", (dialog, which) -> {
                                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                                cm.setPrimaryClip(ClipData.newPlainText("PDF Page Text", finalText));
                                Toast.makeText(this, "Text copied", Toast.LENGTH_SHORT).show();
                            })
                            .show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Text copy नहीं हो पाया", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void savePageAsImage(int pageIndex, String format) {
        if (android.os.Build.VERSION.SDK_INT < 29 &&
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingImagePage = pageIndex;
            pendingPageFormat = format;
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            return;
        }

        new Thread(() -> {
            Bitmap bmp = null;
            try {
                int width = 3000;
                bmp = renderPageBitmap(pageIndex, width);
                String base = fileName.toLowerCase(Locale.ROOT).endsWith(".pdf")
                        ? fileName.substring(0, fileName.length() - 4)
                        : fileName;

                boolean png = "png".equalsIgnoreCase(format);
                String ext = png ? ".png" : ".jpg";
                String mime = png ? "image/png" : "image/jpeg";
                String outName = sanitize(base) + "_Page_" + (pageIndex + 1) + ext;
                Bitmap.CompressFormat compressFormat = png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG;
                int quality = 100;

                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Images.Media.DISPLAY_NAME, outName);
                    v.put(MediaStore.Images.Media.MIME_TYPE, mime);
                    v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/STS Fast Browser");
                    v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) throw new Exception("Unable to create image");
                    try {
                        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                            if (out == null || !bmp.compress(compressFormat, quality, out)) {
                                throw new Exception("Unable to save image");
                            }
                        }
                        publishSavedMedia(uri);
                    } catch (Exception e) {
                        discardFailedMedia(uri);
                        throw e;
                    }
                } else {
                    File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "STS Fast Browser");
                    if (!dir.exists()) dir.mkdirs();
                    File outFile = uniqueFile(dir, outName, ext);
                    try (OutputStream out = new FileOutputStream(outFile)) {
                        if (!bmp.compress(compressFormat, quality, out)) {
                            throw new Exception("Unable to save image");
                        }
                    } catch (Exception e) {
                        outFile.delete();
                        throw e;
                    }
                }

                final String label = png ? "PNG" : "JPG";
                runOnUiThread(() -> Toast.makeText(
                        this,
                        "Page " + (pageIndex + 1) + " " + label + " में save हो गया",
                        Toast.LENGTH_LONG
                ).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Page image save नहीं हो पाया", Toast.LENGTH_SHORT).show());
            } finally {
                if (bmp != null && !bmp.isRecycled()) bmp.recycle();
            }
        }).start();
    }

    private void savePageAsPdf(int pageIndex) {
        if (android.os.Build.VERSION.SDK_INT < 29 &&
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingImagePage = pageIndex;
            pendingPageFormat = "pdf";
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            return;
        }

        new Thread(() -> {
            File tmp = null;
            try {
                String base = fileName.toLowerCase(Locale.ROOT).endsWith(".pdf")
                        ? fileName.substring(0, fileName.length() - 4)
                        : fileName;
                String outName = sanitize(base) + "_Page_" + (pageIndex + 1) + ".pdf";

                tmp = new File(getCacheDir(), "single_page_" + System.currentTimeMillis() + ".pdf");
                synchronized (this) {
                    if (textDocument == null) throw new IllegalStateException("PDF unavailable");
                    PDDocument single = new PDDocument();
                    try {
                        single.importPage(textDocument.getPage(pageIndex));
                        single.save(tmp);
                    } finally {
                        single.close();
                    }
                }

                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, outName);
                    v.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                    v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/STS Fast Browser");
                    v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) throw new Exception("Unable to create PDF");
                    try {
                        try (InputStream in = new FileInputStream(tmp);
                             OutputStream out = getContentResolver().openOutputStream(uri)) {
                            copy(in, out);
                        }
                        publishSavedMedia(uri);
                    } catch (Exception e) {
                        discardFailedMedia(uri);
                        throw e;
                    }
                } else {
                    File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "STS Fast Browser");
                    if (!dir.exists()) dir.mkdirs();
                    File outFile = uniqueFile(dir, outName, ".pdf");
                    try (InputStream in = new FileInputStream(tmp);
                         OutputStream out = new FileOutputStream(outFile)) {
                        copy(in, out);
                    } catch (Exception e) {
                        outFile.delete();
                        throw e;
                    }
                }

                runOnUiThread(() -> Toast.makeText(
                        this,
                        "Page " + (pageIndex + 1) + " PDF में save हो गया",
                        Toast.LENGTH_LONG
                ).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Page PDF save नहीं हो पाया", Toast.LENGTH_SHORT).show());
            } finally {
                if (tmp != null) tmp.delete();
            }
        }).start();
    }

    private String resolveDisplayName(Uri uri) {
        if (uri == null) return null;
        if ("content".equalsIgnoreCase(uri.getScheme())) {
            try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (i >= 0) return c.getString(i);
                }
            } catch (Exception ignored) {}
        }
        String last = uri.getLastPathSegment();
        if (last != null && !last.trim().isEmpty()) return last;
        return null;
    }

    private void copyUriToFile(Uri uri, File out) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream os = new FileOutputStream(out)) {
            if (in == null) throw new Exception("Unable to open PDF");
            copy(in, os);
        }
    }

    private void download(String urlString, File out) throws Exception {
        SafeHttpDownload.download(urlString, out, userAgent, cookie, null,
                address -> android.webkit.CookieManager.getInstance().getCookie(address));
    }

    private void sharePdf() {
        Uri uri = Uri.parse("content://" + getPackageName() + ".pdfshare/" + Uri.encode(sourceFile.getName()));
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/pdf");
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Share PDF"));
    }

    private void printPdf() {
        PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
        pm.print(fileName, new RawPdfAdapter(pdfFile, fileName), new PrintAttributes.Builder().build());
    }

    private void saveToDownloads() {
        if (android.os.Build.VERSION.SDK_INT < 29 &&
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingImagePage = -2;
            pendingPageFormat = null;
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            return;
        }

        new Thread(() -> {
            try {
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                    v.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                    v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/STS Fast Browser");
                    v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) throw new Exception("insert failed");
                    try {
                        try (InputStream in = new FileInputStream(sourceFile); OutputStream out = getContentResolver().openOutputStream(uri)) {
                            copy(in, out);
                        }
                        publishSavedMedia(uri);
                    } catch (Exception e) {
                        discardFailedMedia(uri);
                        throw e;
                    }
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists()) dir.mkdirs();
                    File out = uniqueFile(dir, fileName, ".pdf");
                    try (InputStream in = new FileInputStream(sourceFile); OutputStream os = new FileOutputStream(out)) {
                        copy(in, os);
                    } catch (Exception e) {
                        out.delete();
                        throw e;
                    }
                }
                runOnUiThread(() -> Toast.makeText(this, "PDF Downloads में save हो गया", Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Download नहीं हो पाया", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void publishSavedMedia(Uri uri) throws Exception {
        ContentValues ready = new ContentValues();
        ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
        if (getContentResolver().update(uri, ready, null, null) != 1)
            throw new Exception("Unable to finish saving");
    }

    private void discardFailedMedia(Uri uri) {
        try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
    }

    private File uniqueFile(File dir, String name, String extension) {
        File f = new File(dir, name);
        if (!f.exists()) return f;

        String base = name;
        if (name.toLowerCase(Locale.ROOT).endsWith(extension.toLowerCase(Locale.ROOT))) {
            base = name.substring(0, name.length() - extension.length());
        }
        int n = 2;
        do {
            f = new File(dir, base + " (" + n++ + ")" + extension);
        } while (f.exists());
        return f;
    }

    private static void copy(InputStream in, OutputStream out) throws Exception {
        if (out == null) throw new Exception("no output");
        byte[] buf = new byte[32768];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.flush();
    }

    private String sanitize(String s) {
        return s.replaceAll("[^a-zA-Z0-9._ -]", "_");
    }

    private void showOpenError() {
        runOnUiThread(() -> {
            if (status != null) status.setText("PDF open नहीं हो पाया");
            Toast.makeText(this, "PDF open नहीं हो पाया", Toast.LENGTH_SHORT).show();
        });
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_STORAGE && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            int pending = pendingImagePage;
            String format = pendingPageFormat;
            pendingImagePage = -1;
            pendingPageFormat = null;
            if (pending >= 0) {
                if ("pdf".equalsIgnoreCase(format)) savePageAsPdf(pending);
                else savePageAsImage(pending, "png".equalsIgnoreCase(format) ? "png" : "jpg");
            } else if (pending == -2) {
                saveToDownloads();
            }
        }
    }

    private synchronized void closePdfResources() {
        if (pdfRenderer != null) {
            try { pdfRenderer.close(); } catch (Exception ignored) {}
            pdfRenderer = null;
        }
        if (pdfPfd != null) {
            try { pdfPfd.close(); } catch (Exception ignored) {}
            pdfPfd = null;
        }
        if (textDocument != null) {
            try { textDocument.close(); } catch (Exception ignored) {}
            textDocument = null;
        }
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        ++replacementPreviewVersion;
        if(replacementPreviewBitmap!=null&&!replacementPreviewBitmap.isRecycled())replacementPreviewBitmap.recycle();
        replacementPreviewBitmap=null;replacementPreviewPage=-1;
        if(android.os.Build.VERSION.SDK_INT>=33 && pdfBackCallback!=null)getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(pdfBackCallback);
        if (pages != null) {
            pages.removeCallbacks(visiblePageUpdater);
            for (int i = 0; i < pages.getChildCount(); i++) {
                View child = pages.getChildAt(i);
                if (child instanceof ZoomPageView) ((ZoomPageView) child).releaseBitmap();
            }
        }
        pdfRenderExecutor.shutdownNow();
        synchronized (this) {
            pageLinks.clear();
            pageLinksScanned.clear();
        }
        closePdfResources();
        super.onDestroy();
    }

    private class ZoomPageView extends ImageView {
        private PdfEditMark activeMark;
        private PdfEditMark movingTextOriginal, movingTextDraft;
        private float dragOffsetX,dragOffsetY,initialPinchDistance,initialTextSize;
        private boolean pinchText;
        private final Matrix drawMatrix = new Matrix();
        private final ScaleGestureDetector scaleDetector;
        private final GestureDetector gestureDetector;
        private final int pageIndex;

        private Bitmap baseBitmap;
        private Bitmap sharpBitmap;
        private float currentScale = 1f;
        private float offsetX = 0f;
        private float offsetY = 0f;
        private float lastX;
        private float lastY;
        private int sharpGeneration = 0;
        private int baseGeneration = 0;
        private boolean baseLoading = false;

        ZoomPageView(Context context, int pageIndex) {
            super(context);
            this.pageIndex = pageIndex;
            setScaleType(ScaleType.MATRIX);
            setClickable(true);
            setLongClickable(true);

            scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScaleBegin(ScaleGestureDetector detector) {
                    sharpGeneration++;
                    getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                }

                @Override
                public boolean onScale(ScaleGestureDetector detector) {
                    float factor = detector.getScaleFactor();
                    if (Float.isNaN(factor) || Float.isInfinite(factor)) return false;

                    float next = Math.max(1f, Math.min(5f, currentScale * factor));
                    float applied = next / currentScale;
                    currentScale = next;

                    float focusX = detector.getFocusX();
                    float focusY = detector.getFocusY();
                    offsetX = focusX - ((focusX - offsetX) * applied);
                    offsetY = focusY - ((focusY - offsetY) * applied);

                    clampOffsets();
                    applyCurrentMatrix();
                    return true;
                }

                @Override
                public void onScaleEnd(ScaleGestureDetector detector) {
                    if (currentScale <= 1.02f) {
                        resetToBase();
                    } else {
                        clampOffsets();
                        applyCurrentMatrix();
                        requestSharpBitmap();
                    }
                    getParent().requestDisallowInterceptTouchEvent(currentScale > 1.02f);
                }
            });

            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onDown(MotionEvent e) { return true; }

                @Override
                public void onLongPress(MotionEvent e) {
                    performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                    showPageActions(pageIndex);
                }

                @Override
                public boolean onSingleTapConfirmed(MotionEvent e) {
                    String url = findLinkAt(e.getX(), e.getY());
                    if (url != null) {
                        openPdfLinkInBrowser(url);
                        return true;
                    }
                    return false;
                }

                @Override
                public boolean onDoubleTap(MotionEvent e) {
                    if (currentScale > 1.05f) {
                        resetToBase();
                    } else {
                        currentScale = 2f;
                        offsetX = e.getX() - ((e.getX() - offsetX) * 2f);
                        offsetY = e.getY() - ((e.getY() - offsetY) * 2f);
                        clampOffsets();
                        applyCurrentMatrix();
                        requestSharpBitmap();
                    }
                    return true;
                }
            });
        }

        void ensureBaseBitmap() {
            if (destroyed || baseLoading || (baseBitmap != null && !baseBitmap.isRecycled())) return;
            baseLoading = true;
            final int generation = ++baseGeneration;
            final int targetWidth = Math.max(480, basePageRenderWidth);

            pdfRenderExecutor.execute(() -> {
                Bitmap fresh = null;
                try {
                    if (destroyed || generation != baseGeneration) return;
                    fresh = renderPageBitmap(pageIndex, targetWidth);
                    ensurePdfLinks(pageIndex);
                    final Bitmap result = fresh;
                    runOnUiThread(() -> {
                        if (destroyed || generation != baseGeneration) {
                            if (!result.isRecycled()) result.recycle();
                            return;
                        }
                        baseLoading = false;
                        setInitialBitmap(result);
                    });
                    fresh = null;
                } catch (Exception e) {
                    final Bitmap failed = fresh;
                    runOnUiThread(() -> {
                        baseLoading = false;
                        if (failed != null && !failed.isRecycled()) failed.recycle();
                    });
                } finally {
                    if (fresh != null && !fresh.isRecycled()) fresh.recycle();
                }
            });
        }

        void releaseBaseBitmapOnly() {
            if (currentScale > 1.02f) return;
            baseGeneration++;
            baseLoading = false;
            clearSharpBitmap();

            Bitmap base = baseBitmap;
            baseBitmap = null;
            if (base != null && !base.isRecycled()) base.recycle();

            currentScale = 1f;
            offsetX = 0f;
            offsetY = 0f;
            super.setImageDrawable(null);
        }

        void setInitialBitmap(Bitmap bitmap) {
            baseLoading = false;
            Bitmap oldBase = baseBitmap;
            baseBitmap = bitmap;
            super.setImageBitmap(baseBitmap);
            currentScale = 1f;
            offsetX = 0f;
            offsetY = 0f;
            clearSharpBitmap();
            if (oldBase != null && oldBase != bitmap && !oldBase.isRecycled()) oldBase.recycle();
            post(this::applyCurrentMatrix);
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            if (w <= 0 || h <= 0) return;
            if (oldw != w || oldh != h) {
                currentScale = 1f;
                offsetX = 0f;
                offsetY = 0f;
                clearSharpBitmap();
                if (baseBitmap != null && !baseBitmap.isRecycled()) super.setImageBitmap(baseBitmap);
                applyCurrentMatrix();
            }
        }

        private void applyCurrentMatrix() {
            if (getDrawable() == null || getWidth() <= 0 || getHeight() <= 0) return;

            float dw = getDrawable().getIntrinsicWidth();
            float dh = getDrawable().getIntrinsicHeight();
            if (dw <= 0f || dh <= 0f) return;

            float fit = Math.min(getWidth() / dw, getHeight() / dh);
            float scale = fit * currentScale;

            drawMatrix.reset();
            drawMatrix.postScale(scale, scale);
            drawMatrix.postTranslate(offsetX, offsetY);
            setImageMatrix(drawMatrix);
        }

        private void clampOffsets() {
            if (getWidth() <= 0 || getHeight() <= 0) return;

            float contentW = getWidth() * currentScale;
            float contentH = getHeight() * currentScale;

            if (contentW <= getWidth()) {
                offsetX = (getWidth() - contentW) * 0.5f;
            } else {
                float minX = getWidth() - contentW;
                offsetX = Math.max(minX, Math.min(0f, offsetX));
            }

            if (contentH <= getHeight()) {
                offsetY = (getHeight() - contentH) * 0.5f;
            } else {
                float minY = getHeight() - contentH;
                offsetY = Math.max(minY, Math.min(0f, offsetY));
            }
        }

        private void requestSharpBitmap() {
            if (destroyed || currentScale <= 1.02f || getWidth() <= 0 || baseBitmap == null || baseBitmap.isRecycled()) return;

            final int generation = ++sharpGeneration;
            final float requestedScale = currentScale;
            final int targetWidth = Math.min(4096,
                    Math.max(baseBitmap.getWidth(), Math.round(getWidth() * requestedScale)));

            pdfRenderExecutor.execute(() -> {
                Bitmap fresh = null;
                try {
                    fresh = renderPageBitmap(pageIndex, targetWidth);
                    final Bitmap result = fresh;
                    runOnUiThread(() -> {
                        if (destroyed || generation != sharpGeneration || currentScale <= 1.02f) {
                            if (!result.isRecycled()) result.recycle();
                            return;
                        }

                        Bitmap oldSharp = sharpBitmap;
                        sharpBitmap = result;
                        superSetImageBitmap(result);
                        applyCurrentMatrix();
                        if (oldSharp != null && oldSharp != result && !oldSharp.isRecycled()) {
                            oldSharp.recycle();
                        }
                    });
                } catch (Exception e) {
                    if (fresh != null && !fresh.isRecycled()) fresh.recycle();
                }
            });
        }

        private void superSetImageBitmap(Bitmap bitmap) {
            super.setImageBitmap(bitmap);
        }

        private void clearSharpBitmap() {
            sharpGeneration++;
            Bitmap oldSharp = sharpBitmap;
            sharpBitmap = null;
            if (oldSharp != null && !oldSharp.isRecycled()) oldSharp.recycle();
        }

        private void resetToBase() {
            currentScale = 1f;
            offsetX = 0f;
            offsetY = 0f;
            clearSharpBitmap();
            if (baseBitmap != null && !baseBitmap.isRecycled()) {
                super.setImageBitmap(baseBitmap);
            }
            applyCurrentMatrix();
            getParent().requestDisallowInterceptTouchEvent(false);
        }

        private String findLinkAt(float viewX, float viewY) {
            List<PdfLink> links = pageLinks.get(pageIndex);
            if (links == null || links.isEmpty() || getWidth() <= 0 || getHeight() <= 0) return null;

            float contentX = (viewX - offsetX) / currentScale;
            float contentY = (viewY - offsetY) / currentScale;
            if (contentX < 0f || contentY < 0f || contentX > getWidth() || contentY > getHeight()) return null;

            for (PdfLink link : links) {
                float pdfX = (contentX / getWidth()) * link.pageWidth;
                float pdfY = link.pageHeight - ((contentY / getHeight()) * link.pageHeight);
                if (link.contains(pdfX, pdfY)) return link.url;
            }
            return null;
        }

        void releaseBitmap() {
            baseGeneration++;
            baseLoading = false;
            sharpGeneration++;
            Bitmap sharp = sharpBitmap;
            sharpBitmap = null;
            if (sharp != null && !sharp.isRecycled()) sharp.recycle();

            Bitmap base = baseBitmap;
            baseBitmap = null;
            if (base != null && !base.isRecycled()) base.recycle();

            super.setImageDrawable(null);
        }

        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            canvas.save();canvas.translate(offsetX,offsetY);canvas.scale(currentScale,currentScale);
            if(replacementPreviewPage==pageIndex && replacementPreviewBitmap!=null
                    && !replacementPreviewBitmap.isRecycled()){
                android.graphics.Paint previewPaint=new android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG);
                canvas.drawBitmap(replacementPreviewBitmap,null,
                    new android.graphics.RectF(0f,0f,getWidth(),getHeight()),previewPaint);
            }
            for(PdfEditMark mark:pdfMarks)if(mark.page==pageIndex && !"Replace".equals(mark.kind) && mark!=movingTextOriginal)mark.draw(canvas,getWidth(),getHeight());
            if(activeMark!=null)activeMark.draw(canvas,getWidth(),getHeight());
            if(movingTextDraft!=null)movingTextDraft.draw(canvas,getWidth(),getHeight());
            if("Replace".equals(pdfTool) && textSpanPage==pageIndex && spanActive){
                android.graphics.Paint p=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
                p.setColor(0x52008080);
                float sx=spanStartX*getWidth(),sy=spanStartY*getHeight();
                float ex=spanEndX*getWidth(),ey=spanEndY*getHeight();
                canvas.drawRect(Math.min(sx,ex),Math.min(sy,ey),Math.max(sx,ex),Math.max(sy,ey),p);
                p.setColor(0xFF00796B);p.setStyle(android.graphics.Paint.Style.STROKE);
                p.setStrokeWidth(dp(2));
                canvas.drawRect(Math.min(sx,ex),Math.min(sy,ey),Math.max(sx,ex),Math.max(sy,ey),p);
                p.setStyle(android.graphics.Paint.Style.FILL);
                canvas.drawCircle(sx,sy,dp(6)/Math.max(1,currentScale),p);
                canvas.drawCircle(ex,ey,dp(6)/Math.max(1,currentScale),p);
            }
            canvas.restore();
        }
        private PdfEditMark findTextAt(float x,float y){
            // Hit testing uses the same TextPaint size as drawing, with a small finger tolerance.
            for(int i=pdfMarks.size()-1;i>=0;i--){
                PdfEditMark mark=pdfMarks.get(i);
                if(mark.page!=pageIndex || !"Text".equals(mark.kind)||mark.points.isEmpty())continue;
                float[] pos=mark.points.get(0);
                android.graphics.Paint paint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
                paint.setTextSize(getWidth()*mark.size);
                paint.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT,
                    mark.bold?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL));
                float length=paint.measureText(mark.text)/Math.max(1,getWidth());
                float yheight=(paint.getTextSize()*1.5f)/Math.max(1,getHeight());
                float pad=0.012f;
                if(x>=pos[0]-pad&&x<=Math.min(1,pos[0]+length+pad)&&
                   y>=pos[1]-pad&&y<=Math.min(1,pos[1]+yheight+pad))return mark;
            }
            return null;
        }
        private boolean editTouch(MotionEvent event){
            if(pdfSaving)return true;
            if(!pdfEditing || "Move".equals(pdfTool))return false;
            getParent().requestDisallowInterceptTouchEvent(true);
            int action=event.getActionMasked();
            float[] xy=PdfEditGeometry.point(event.getX(),event.getY(),offsetX,offsetY,currentScale,getWidth(),getHeight());
            if("Text".equals(pdfTool)&&movingTextDraft!=null){
                if(action==MotionEvent.ACTION_POINTER_DOWN && event.getPointerCount()==2){
                    pinchText=true;
                    initialPinchDistance=(float)Math.hypot(event.getX(0)-event.getX(1),event.getY(0)-event.getY(1));
                    initialTextSize=movingTextDraft.size;
                    return true;
                }
                if(action==MotionEvent.ACTION_MOVE){
                    if(pinchText&&event.getPointerCount()>=2){
                        float now=(float)Math.hypot(event.getX(0)-event.getX(1),event.getY(0)-event.getY(1));
                        if(initialPinchDistance>1f)movingTextDraft.size=Math.max(0.009f,Math.min(0.15f,initialTextSize*now/initialPinchDistance));
                    }else if(!pinchText){
                        movingTextDraft.points.get(0)[0]=Math.max(0,Math.min(1,xy[0]-dragOffsetX));
                        movingTextDraft.points.get(0)[1]=Math.max(0,Math.min(1,xy[1]-dragOffsetY));
                    }
                    invalidate();return true;
                }
                if(action==MotionEvent.ACTION_POINTER_UP){return true;}
                if(action==MotionEvent.ACTION_UP){
                    replacePdfMark(movingTextOriginal,movingTextDraft);lastPlacedText=movingTextDraft;
                    movingTextOriginal=null;movingTextDraft=null;pinchText=false;
                    getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;
                }
                if(action==MotionEvent.ACTION_CANCEL){
                    movingTextOriginal=null;movingTextDraft=null;pinchText=false;
                    getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;
                }
                return true;
            }
            if(action==MotionEvent.ACTION_DOWN){
                if(xy[0]<0||xy[1]<0||xy[0]>1||xy[1]>1)return true;
                if("Replace".equals(pdfTool)){
                    boolean start=spanActive&&textSpanPage==pageIndex&&
                        Math.hypot(spanStartX-xy[0],spanStartY-xy[1])<SPAN_HANDLE_RADIUS;
                    boolean end=spanActive&&textSpanPage==pageIndex&&
                        Math.hypot(spanEndX-xy[0],spanEndY-xy[1])<SPAN_HANDLE_RADIUS;
                    if(!start&&!end){spanStartX=xy[0];spanStartY=xy[1];spanEndX=xy[0];spanEndY=xy[1];spanHandle=1;}
                    else spanHandle=start?0:1;
                    textSpanPage=pageIndex;spanActive=true;spanDragging=true;invalidate();return true;
                }
                if("Text".equals(pdfTool)){
                    PdfEditMark touched=findTextAt(xy[0],xy[1]);
                    if(touched!=null&&!textPlacementArmed){
                        lastPlacedText=touched;textBold=touched.bold;inkColor=touched.color;
                        boldButton.setText(textBold?"Bold: ON":"Bold: OFF");
                        movingTextOriginal=touched;movingTextDraft=touched.copy();
                        float[] p=touched.points.get(0);
                        dragOffsetX=xy[0]-p[0];dragOffsetY=xy[1]-p[1];pinchText=false;
                        invalidate();return true;
                    }
                    if(!textPlacementArmed){
                        editHint.setText("नया Text रखने के लिए पहले Place दबाएँ; पुराने Text को छूकर Move/Resize करें");return true;
                    }
                    String text=inlineText.getText().toString().trim();
                    if(text.isEmpty()){editHint.setText("पहले नया Text लिखें");return true;}
                    activeMark=new PdfEditMark(pageIndex,"Text",inkColor,0.026f,text);
                    activeMark.bold=textBold;
                    activeMark.point(xy[0],xy[1]);invalidate();return true;
                }
                if(pdfMarks.size()>=200){editHint.setText("200 edits पूरे; आगे बढ़ने से पहले Save करें");return true;}
                activeMark=new PdfEditMark(pageIndex,pdfTool,inkColor,0.021f,"");
                activeMark.point(xy[0],xy[1]);invalidate();return true;
            }
            if(action==MotionEvent.ACTION_MOVE && "Replace".equals(pdfTool)&&spanDragging){
                if(spanHandle==0){spanStartX=Math.max(0,Math.min(1,xy[0]));spanStartY=Math.max(0,Math.min(1,xy[1]));}
                else{spanEndX=Math.max(0,Math.min(1,xy[0]));spanEndY=Math.max(0,Math.min(1,xy[1]));}
                invalidate();return true;
            }
            if(action==MotionEvent.ACTION_UP && "Replace".equals(pdfTool)){
                if(spanDragging){
                    spanDragging=false;spanHandle=-1;
                    float distance=(float)Math.hypot(spanEndX-spanStartX,spanEndY-spanStartY);
                    if(distance<0.008f)selectPdfText(pageIndex,spanStartX,spanStartY);
                    else selectPdfRange(pageIndex,spanStartX,spanStartY,spanEndX,spanEndY);
                }
                getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;
            }
            if(action==MotionEvent.ACTION_MOVE && activeMark!=null&&"Text".equals(activeMark.kind)){
                // Placement follows finger until released, but commits exactly once.
                activeMark.points.get(0)[0]=Math.max(0,Math.min(1,xy[0]));
                activeMark.points.get(0)[1]=Math.max(0,Math.min(1,xy[1]));invalidate();return true;
            }
            if(action==MotionEvent.ACTION_MOVE&&activeMark!=null){
                if(activeMark.points.size()<6000)activeMark.point(xy[0],xy[1]);invalidate();return true;
            }
            if(action==MotionEvent.ACTION_UP){
                if(activeMark!=null){
                    commitPdfMark(activeMark);
                    if("Text".equals(activeMark.kind)){
                        lastPlacedText=activeMark;textPlacementArmed=false;
                        editHint.setText("Text रखा गया; Move/Resize के लिए इसे छुएँ, नया Text रखने के लिए Place दबाएँ");
                    }
                    activeMark=null;
                }
                getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;
            }
            if(action==MotionEvent.ACTION_CANCEL){activeMark=null;spanDragging=false;spanHandle=-1;
                getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;}
            return true;
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (editTouch(event)) return true;
            if (baseBitmap == null || baseBitmap.isRecycled()) {
                ensureBaseBitmap();
                return true;
            }
            scaleDetector.onTouchEvent(event);
            gestureDetector.onTouchEvent(event);

            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = event.getX();
                    lastY = event.getY();
                    if (currentScale > 1.02f) {
                        sharpGeneration++;
                        getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    break;

                case MotionEvent.ACTION_MOVE:
                    if (!scaleDetector.isInProgress() && currentScale > 1.02f) {
                        float dx = event.getX() - lastX;
                        float dy = event.getY() - lastY;
                        offsetX += dx;
                        offsetY += dy;
                        clampOffsets();
                        applyCurrentMatrix();
                        getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    lastX = event.getX();
                    lastY = event.getY();
                    break;

                case MotionEvent.ACTION_POINTER_UP:
                    clampOffsets();
                    applyCurrentMatrix();
                    break;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (currentScale <= 1.02f) {
                        resetToBase();
                    } else {
                        clampOffsets();
                        applyCurrentMatrix();
                        requestSharpBitmap();
                    }
                    break;
            }
            return true;
        }
    }

    private static class RawPdfAdapter extends PrintDocumentAdapter {
        private final File file;
        private final String name;

        RawPdfAdapter(File file, String name) {
            this.file = file;
            this.name = name;
        }

        @Override
        public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                             android.os.CancellationSignal cancellationSignal,
                             LayoutResultCallback callback, Bundle extras) {
            if (cancellationSignal.isCanceled()) {
                callback.onLayoutCancelled();
                return;
            }
            PrintDocumentInfo info = new PrintDocumentInfo.Builder(name)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                    .build();
            callback.onLayoutFinished(info, true);
        }

        @Override
        public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                            android.os.CancellationSignal cancellationSignal,
                            WriteResultCallback callback) {
            new Thread(() -> {
                try (InputStream in = new FileInputStream(file);
                     OutputStream out = new FileOutputStream(destination.getFileDescriptor())) {
                    byte[] buf = new byte[32768];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        if (cancellationSignal.isCanceled()) {
                            callback.onWriteCancelled();
                            return;
                        }
                        out.write(buf, 0, n);
                    }
                    callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                } catch (Exception e) {
                    callback.onWriteFailed(e.getMessage());
                }
            }).start();
        }
    }
}
