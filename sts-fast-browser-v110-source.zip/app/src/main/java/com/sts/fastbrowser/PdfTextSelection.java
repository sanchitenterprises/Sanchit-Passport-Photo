package com.sts.fastbrowser;

import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.pdmodel.PDPage;
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.text.TextPosition;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Detect tap targets on selectable PDF text, in top-left normalized page coordinates. */
final class PdfTextSelection extends PDFTextStripper {
    static final class Selection {
        final int page;
        final String original;
        final float left, top, right, bottom, height;
        Selection(int page,String original,float left,float top,float right,float bottom,float height){
            this.page=page;this.original=original;this.left=left;this.top=top;
            this.right=right;this.bottom=bottom;this.height=height;
        }
    }
    private final int pageIndex;
    private final float pageWidth,pageHeight;
    private final List<Selection> words=new ArrayList<>();
    private PdfTextSelection(int index,float w,float h) throws IOException {
        pageIndex=index;pageWidth=w;pageHeight=h;
        setStartPage(index+1);setEndPage(index+1);setSortByPosition(true);
    }
    @Override protected void writeString(String str,List<TextPosition> glyphs) throws IOException {
        if(glyphs==null||glyphs.isEmpty())return;
        // PDFTextStripper often groups a whole line in one writeString callback.
        // Select individual words instead so one tap doesn't try to replace an
        // entire line spanning several independent Tj/TJ string segments.
        StringBuilder word=new StringBuilder();
        float left=Float.MAX_VALUE,top=Float.MAX_VALUE,right=0,bottom=0,maxH=0;
        for(TextPosition glyph:glyphs){
            String unicode=glyph.getUnicode();
            if(unicode==null||unicode.isEmpty())continue;
            boolean gap=true;
            for(int at=0;at<unicode.length();){
                int c=unicode.codePointAt(at);
                if(!Character.isWhitespace(c)&&!Character.isSpaceChar(c)){gap=false;break;}
                at+=Character.charCount(c);
            }
            if(gap){
                if(word.length()>0)addWord(word.toString(),left,top,right,bottom,maxH);
                word.setLength(0);left=Float.MAX_VALUE;top=Float.MAX_VALUE;
                right=0;bottom=0;maxH=0;
                continue;
            }
            word.append(unicode);
            float x=glyph.getXDirAdj();float y=glyph.getYDirAdj();
            float width=glyph.getWidthDirAdj(),height=glyph.getHeightDir();
            left=Math.min(left,x);top=Math.min(top,y-height);
            right=Math.max(right,x+width);bottom=Math.max(bottom,y+height*0.15f);
            maxH=Math.max(maxH,height);
        }
        if(word.length()>0)addWord(word.toString(),left,top,right,bottom,maxH);
    }
    private void addWord(String raw,float left,float top,float right,float bottom,float maxH){
        raw=raw.trim();
        if(raw.isEmpty()||left>=right||top>=bottom||pageWidth<=0||pageHeight<=0)return;
        words.add(new Selection(pageIndex,raw,clamp(left/pageWidth),clamp(top/pageHeight),
                clamp(right/pageWidth),clamp(bottom/pageHeight),maxH/pageHeight));
    }
    static Selection pick(PDDocument doc,int page,float x,float y) throws IOException {
        PDPage target=doc.getPage(page);
        PDRectangle rect=target.getCropBox();
        if(rect==null)rect=target.getMediaBox();
        int angle=((target.getRotation()%360)+360)%360;
        float width=angle%180==0?rect.getWidth():rect.getHeight();
        float height=angle%180==0?rect.getHeight():rect.getWidth();
        PdfTextSelection stripper=new PdfTextSelection(page,width,height);
        stripper.getText(doc);
        Selection closest=null;
        float best=Float.MAX_VALUE;
        for(Selection word:stripper.words){
            float dx=Math.max(word.left-x,Math.max(0,x-word.right));
            float dy=Math.max(word.top-y,Math.max(0,y-word.bottom));
            float distance=dx*dx+dy*dy;
            if(distance<best){best=distance;closest=word;}
        }
        return best<=0.00045f?closest:null; // ~2.1% page tolerance
    }
    /** Two drag endpoints select a continuous word interval in reading order.
     * No guessed text is inserted: native replacement still validates the exact
     * PDF font/bytes and fails safely for unsupported fragmented content. */
    static Selection pickRange(PDDocument doc,int page,float sx,float sy,float ex,float ey) throws IOException {
        PDPage target=doc.getPage(page);
        PDRectangle rect=target.getCropBox();if(rect==null)rect=target.getMediaBox();
        int angle=((target.getRotation()%360)+360)%360;
        float w=angle%180==0?rect.getWidth():rect.getHeight();
        float h=angle%180==0?rect.getHeight():rect.getWidth();
        PdfTextSelection stripper=new PdfTextSelection(page,w,h);
        stripper.getText(doc);
        if(stripper.words.isEmpty())return null;
        int from=stripper.nearestIndex(sx,sy),to=stripper.nearestIndex(ex,ey);
        if(from<0||to<0)return null;
        if(from>to){int tmp=from;from=to;to=tmp;}
        if(to-from>=80)return null; // guard against accidental whole-page edits
        StringBuilder joined=new StringBuilder();
        float left=1,top=1,right=0,bottom=0,maxH=0;
        for(int i=from;i<=to;i++){
            Selection word=stripper.words.get(i);
            if(joined.length()>0){
                Selection previous=stripper.words.get(i-1);
                boolean sameLine=Math.abs(word.top-previous.top)<Math.max(word.height,previous.height)*0.9f;
                joined.append(sameLine?' ':'\n');
            }
            joined.append(word.original);
            left=Math.min(left,word.left);top=Math.min(top,word.top);
            right=Math.max(right,word.right);bottom=Math.max(bottom,word.bottom);
            maxH=Math.max(maxH,word.height);
        }
        String text=joined.toString();
        if(text.length()>500)return null;
        return new Selection(page,text,left,top,right,bottom,maxH);
    }
    private int nearestIndex(float x,float y){
        int best=-1;float distance=Float.MAX_VALUE;
        for(int i=0;i<words.size();i++){
            Selection word=words.get(i);
            float dx=Math.max(word.left-x,Math.max(0,x-word.right));
            float dy=Math.max(word.top-y,Math.max(0,y-word.bottom));
            float d=dx*dx+dy*dy;
            if(d<distance){best=i;distance=d;}
        }
        return distance<=0.0025f?best:-1;
    }
    private static float clamp(float value){return Math.max(0f,Math.min(1f,value));}
}
