from pathlib import Path
root=Path(__file__).resolve().parents[1]
v=(root/'app/src/main/java/com/sts/fastbrowser/PdfViewerActivity.java').read_text()
n=(root/'app/src/main/java/com/sts/fastbrowser/PdfTextSelection.java').read_text()
o=(root/'app/src/main/java/com/sts/fastbrowser/PdfScanTextReplace.java').read_text()
g=(root/'app/build.gradle').read_text()
assert 'new String[]{"Text", "Replace", "Highlighter", "Undo", "Redo"}' in v
assert 'private boolean isPdfReplacementMode(){return "Replace".equals(pdfTool);}' in v
assert 'spanStartX' in v and 'spanEndX' in v and 'SPAN_HANDLE_RADIUS' in v
assert 'PdfTextSelection.pickRange' in v and 'PdfScanTextReplace.recognizeRange' in v
assert 'selectPdfRange(pageIndex,spanStartX,spanStartY,spanEndX,spanEndY)' in v
assert 'replacementSelection=selected;replacementScanSelection=scanned;' in v
assert 'getParent().requestDisallowInterceptTouchEvent(false)' in v
assert 'isPdfReplacementMode()' in v
assert 'static Selection pickRange' in n and 'to-from>=80' in n
assert 'static Found recognizeRange' in o and 'complex' in o
assert 'versionCode 111' in g and "versionName '1.0.110'" in g
print('PASS integrated Replace range, handles, safe PDF selection and version checks')
