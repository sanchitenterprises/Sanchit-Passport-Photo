from pathlib import Path
r=Path(__file__).resolve().parents[1]
v=(r/'app/src/main/java/com/sts/fastbrowser/PdfViewerActivity.java').read_text()
n=(r/'app/src/main/java/com/sts/fastbrowser/PdfTextSelection.java').read_text()
o=(r/'app/src/main/java/com/sts/fastbrowser/PdfScanTextReplace.java').read_text()
start=v.index('private void selectPdfRange(')
end=v.index('private void applyPdfReplacement()',start)
select=v[start:end]
assert 'inlineText.setText(' not in select, 'Selecting PDF words must never overwrite user replacement text'
assert 'inlineText.setSelection(' not in select
assert 'new String[]{"Text", "Replace", "Highlighter", "Undo", "Redo"}' in v
assert 'getText().toString().trim()' in v
assert 'words= replacementSelection' not in v  # current exact variable branch check below
assert 'words=replacementSelection.wordBounds;' in v
assert 'words=replacementScanSelection.wordBounds;' in v
assert 'canvas.drawRect(Math.min(sx,ex)' not in v
assert 'canvas.drawRect(word[0]*getWidth()' in v
assert 'snapSpanToWordEdges' in v
assert 'wordBounds' in n and 'bounds.add(new float[]{word.left,word.top,word.right,word.bottom})' in n
assert 'selectedWordRects.add(new Rect(current.rect))' in o
assert 'replacementRequestId++;replacementSelection=null;replacementScanSelection=null;' in v
print('PASS: Replace selects individual word highlights + handles; no box; user input never auto-filled')
