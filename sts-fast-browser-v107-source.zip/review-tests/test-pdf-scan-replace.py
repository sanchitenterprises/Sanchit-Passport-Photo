from pathlib import Path
src=Path(__file__).resolve().parents[1]/'app/src/main/java/com/sts/fastbrowser'
a=(src/'PdfViewerActivity.java').read_text()
b=(src/'PdfScanTextReplace.java').read_text()
c=(src/'PdfEditMark.java').read_text()
assert 'PdfTextSelection.pick(' in a
assert 'PdfScanTextReplace.recognize(' in a
assert '"ScanReplace".equals(mark.kind)' in a and 'saveRow.setVisibility(View.VISIBLE)' in a
assert 'replacementRequestId!=request' in a
assert 'mark.canFitScanText(scanned.aspect)' in a
assert 'Tasks.await(latin.process(' in b and 'Tasks.await(devanagari.process(' in b
assert 'nonmatching>3?-1:avg' in b
assert 'canvas.drawRect(x,y,r,b,cover)' in c
assert 'Paint.Style.STROKE' in c and '"Replace".equals(kind)' in c
print('OCR/native route, request guards, conservative scan safety, original-protection and rendering checks PASSED')
