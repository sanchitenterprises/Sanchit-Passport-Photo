package com.sts.fastbrowser;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions;

import java.util.ArrayList;
import java.util.List;

/**
 * Offline on-device OCR fallback for an image-only PDF page. Nothing is uploaded.
 * Rejects complex backgrounds instead of erasing lines, stamps or watermarks.
 * OCR cannot recover the actual font embedded in a bitmap: its size/colour and a
 * closest system font are only an approximation, never a guaranteed exact match.
 */
final class PdfScanTextReplace {
    static final class Found {
        final int page;
        final String text;
        final float left, top, right, bottom, aspect;
        final int background, foreground;
        final boolean complexBackground;
        Found(int page, String text, Rect box, Bitmap bmp, int background, int foreground,
              boolean complex) {
            this.page=page;this.text=text;aspect=bmp.getWidth()/(float)bmp.getHeight();
            left=clip(box.left/(float)bmp.getWidth());
            top=clip(box.top/(float)bmp.getHeight());
            right=clip(box.right/(float)bmp.getWidth());
            bottom=clip(box.bottom/(float)bmp.getHeight());
            this.background=background;this.foreground=foreground;
            complexBackground=complex;
        }
    }
    private static float clip(float v){return Math.max(0f,Math.min(1f,v));}
    private static final class Candidate {
        final Text.Element text;
        final Rect rect;
        Candidate(Text.Element text){this.text=text;this.rect=text.getBoundingBox();}
    }
    static Found recognize(Bitmap image,int page,float nx,float ny) throws Exception {
        TextRecognizer latin=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        TextRecognizer devanagari=TextRecognition.getClient(new DevanagariTextRecognizerOptions.Builder().build());
        ArrayList<Candidate> candidates=new ArrayList<>();
        try {
            // Bundled on-device models; no network/OCR server or PDF upload.
            append(Tasks.await(latin.process(InputImage.fromBitmap(image,0))),candidates);
            append(Tasks.await(devanagari.process(InputImage.fromBitmap(image,0))),candidates);
        } finally {latin.close();devanagari.close();}
        if(candidates.isEmpty())return null;
        float tapX=nx*image.getWidth(),tapY=ny*image.getHeight();
        Candidate best=null;float distance=Float.MAX_VALUE;
        for(Candidate c:candidates){
            Rect r=c.rect;
            if(r==null || r.width()<3 || r.height()<3 || c.text.getText()==null || c.text.getText().trim().isEmpty())continue;
            float dx=Math.max(r.left-tapX,Math.max(0,tapX-r.right));
            float dy=Math.max(r.top-tapY,Math.max(0,tapY-r.bottom));
            float d=(dx*dx+dy*dy)/(image.getWidth()*(float)image.getWidth());
            if(d<distance){distance=d;best=c;}
        }
        if(best==null||distance>0.0005f)return null;
        Rect box=best.rect;
        int background=background(image,box);
        boolean unsafe=background<0;
        if(unsafe)background=Color.WHITE;
        int foreground=foreground(image,box,background);
        return new Found(page,best.text.getText(),box,image,background,foreground,unsafe);
    }
    private static void append(Text result,List<Candidate> out){
        for(Text.TextBlock block:result.getTextBlocks())
            for(Text.Line line:block.getLines())
                for(Text.Element element:line.getElements())out.add(new Candidate(element));
    }
    private static int dist(int a,int b){
        return Math.max(Math.abs(Color.red(a)-Color.red(b)),Math.max(
                Math.abs(Color.green(a)-Color.green(b)),Math.abs(Color.blue(a)-Color.blue(b)));
    }
    // Character boxes may touch a stamp, underline, cell border or photograph.
    // Only permit automatic deletion on a nearly flat document background.
    private static int background(Bitmap bmp,Rect r){
        int w=bmp.getWidth(),h=bmp.getHeight();
        int pad=Math.max(3,Math.round(r.height()*0.19f));
        int[] pixels=new int[32];int count=0;
        for(int i=0;i<8;i++){
            int x=Math.max(0,Math.min(w-1,r.left+(r.width()*(i+1))/9));
            for(int dy:new int[]{-pad,r.height()+pad}){
                int y=Math.max(0,Math.min(h-1,r.top+dy));
                pixels[count++]=bmp.getPixel(x,y);
            }
        }
        for(int i=0;i<8;i++){
            int y=Math.max(0,Math.min(h-1,r.top+(r.height()*(i+1))/9));
            for(int dx:new int[]{-pad,r.width()+pad}){
                int x=Math.max(0,Math.min(w-1,r.left+dx));
                pixels[count++]=bmp.getPixel(x,y);
            }
        }
        int red=0,green=0,blue=0;
        for(int p:pixels){red+=Color.red(p);green+=Color.green(p);blue+=Color.blue(p);}
        int avg=Color.rgb(red/count,green/count,blue/count);
        int nonmatching=0;
        for(int p:pixels)if(dist(p,avg)>31)nonmatching++;
        return nonmatching>3?-1:avg;
    }
    private static int foreground(Bitmap bmp,Rect r,int bg){
        int[] channels=new int[3];int count=0;
        int stride=Math.max(1,Math.min(r.width(),r.height())/22);
        for(int y=Math.max(0,r.top);y<Math.min(bmp.getHeight(),r.bottom);y+=stride)
            for(int x=Math.max(0,r.left);x<Math.min(bmp.getWidth(),r.right);x+=stride){
                int c=bmp.getPixel(x,y);
                if(dist(c,bg)<57)continue;
                // Exclude coloured stamps and photographs; choose dominant dark ink.
                if(Color.red(c)+Color.green(c)+Color.blue(c)>540)continue;
                channels[0]+=Color.red(c);channels[1]+=Color.green(c);channels[2]+=Color.blue(c);count++;
            }
        if(count==0)return Color.BLACK;
        return Color.rgb(channels[0]/count,channels[1]/count,channels[2]/count);
    }
}
