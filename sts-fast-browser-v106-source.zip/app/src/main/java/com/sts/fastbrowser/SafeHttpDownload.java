package com.sts.fastbrowser;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

/** Bounded redirects, origin-scoped credentials and failed-transfer cleanup. */
final class SafeHttpDownload {
    interface Cookies { String forUrl(String url); }
    static final class Result {
        String url, contentDisposition, contentType;
    }

    static boolean sameOrigin(URL a, URL b) {
        return a.getProtocol().equalsIgnoreCase(b.getProtocol())
                && a.getHost().equalsIgnoreCase(b.getHost())
                && port(a) == port(b);
    }
    private static int port(URL url) {
        return url.getPort() < 0 ? url.getDefaultPort() : url.getPort();
    }
    private static boolean present(String value) { return value != null && !value.isEmpty(); }

    static Result download(String address, File destination, String userAgent,
                           String initialCookie, String referer, Cookies cookies) throws IOException {
        boolean complete = false;
        try {
            URL original = new URL(address);
            URL current = original;
            for (int hop = 0; hop < 10; hop++) {
                String protocol = current.getProtocol();
                if (!"http".equalsIgnoreCase(protocol) && !"https".equalsIgnoreCase(protocol))
                    throw new IOException("Unsupported download protocol");
                HttpURLConnection connection = (HttpURLConnection) current.openConnection();
                try {
                    connection.setInstanceFollowRedirects(false);
                    connection.setConnectTimeout(20000);
                    connection.setReadTimeout(45000);
                    connection.setRequestProperty("Accept-Encoding", "identity");
                    if (present(userAgent)) connection.setRequestProperty("User-Agent", userAgent);
                    String scopedCookie = cookies == null ? null : cookies.forUrl(current.toString());
                    if (!present(scopedCookie) && sameOrigin(original, current)) scopedCookie = initialCookie;
                    if (present(scopedCookie)) connection.setRequestProperty("Cookie", scopedCookie);
                    if (present(referer) && sameOrigin(new URL(referer), current))
                        connection.setRequestProperty("Referer", referer);
                    int status = connection.getResponseCode();
                    if (status == 301 || status == 302 || status == 303 || status == 307 || status == 308) {
                        String location = connection.getHeaderField("Location");
                        if (!present(location)) throw new IOException("Redirect without Location");
                        URL next = new URL(current, location);
                        if ("https".equalsIgnoreCase(current.getProtocol()) && !"https".equalsIgnoreCase(next.getProtocol()))
                            throw new IOException("Insecure download redirect");
                        referer = current.toString();
                        current = next;
                        continue;
                    }
                    if (status != 200) throw new IOException("HTTP " + status);
                    long expected = connection.getContentLengthLong();
                    long copied = 0;
                    try (InputStream in = new BufferedInputStream(connection.getInputStream());
                         OutputStream out = new BufferedOutputStream(new FileOutputStream(destination))) {
                        byte[] buffer = new byte[65536];
                        int count;
                        while ((count = in.read(buffer)) != -1) {
                            if (Thread.currentThread().isInterrupted()) throw new InterruptedIOException();
                            out.write(buffer, 0, count);
                            copied += count;
                        }
                    }
                    if (expected >= 0 && copied != expected) throw new IOException("Incomplete download");
                    Result result = new Result();
                    result.url = current.toString();
                    result.contentDisposition = connection.getHeaderField("Content-Disposition");
                    result.contentType = connection.getContentType();
                    complete = true;
                    return result;
                } finally { connection.disconnect(); }
            }
            throw new IOException("Too many redirects");
        } finally {
            if (!complete && destination.exists()) destination.delete();
        }
    }
}
