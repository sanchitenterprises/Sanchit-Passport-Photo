package com.sts.fastbrowser;

import android.app.Application;
import android.os.Build;
import android.webkit.WebView;
import java.io.File;

/** Configure private WebView storage before any WebView/CookieManager is created. */
public class BrowserApplication extends Application {
    private static final String PREFIX = "app_webview_sts_private_";

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 35) registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override public void onActivityCreated(android.app.Activity activity, android.os.Bundle state) {
                android.view.View content = activity.findViewById(android.R.id.content);
                if (content == null) return;
                content.setOnApplyWindowInsetsListener((view, insets) -> {
                    android.graphics.Insets safe = insets.getInsets(
                            android.view.WindowInsets.Type.systemBars()
                            | android.view.WindowInsets.Type.displayCutout()
                            | android.view.WindowInsets.Type.ime());
                    view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
                    return android.view.WindowInsets.CONSUMED;
                });
                content.requestApplyInsets();
            }
            @Override public void onActivityStarted(android.app.Activity a) { }
            @Override public void onActivityResumed(android.app.Activity a) { }
            @Override public void onActivityPaused(android.app.Activity a) { }
            @Override public void onActivityStopped(android.app.Activity a) { }
            @Override public void onActivitySaveInstanceState(android.app.Activity a, android.os.Bundle b) { }
            @Override public void onActivityDestroyed(android.app.Activity a) { }
        });
        if (Build.VERSION.SDK_INT >= 28 && Application.getProcessName().endsWith(":private")) {
            clearOldPrivateProfiles();
            WebView.setDataDirectorySuffix("sts_private_" + java.util.UUID.randomUUID().toString());
        }
    }

    void clearOldPrivateProfiles() {
        File[] temporary = getCacheDir().listFiles();
        if (temporary != null) for (File entry : temporary)
            if (entry.getName().startsWith("private-download-")) entry.delete();
        File root = new File(getApplicationInfo().dataDir);
        File[] entries = root.listFiles();
        if (entries == null) return;
        for (File entry : entries) {
            if (entry.getName().startsWith(PREFIX)) deleteTree(entry);
        }
    }

    private void deleteTree(File file) {
        try {
            if (java.nio.file.Files.isSymbolicLink(file.toPath())) { file.delete(); return; }
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteTree(child);
            file.delete();
        } catch (Exception ignored) { }
    }
}
