package com.sts.fastbrowser;
/** Maps a displayed page overlay back into the PDF crop box, including rotation. */
final class PdfEditGeometry {
 static float[] matrix(int rotation,float w,float h,float x,float y){
  switch(((rotation%360)+360)%360){
   case 90:return new float[]{0,h,-w,0,x+w,y};
   case 180:return new float[]{-w,0,0,-h,x+w,y+h};
   case 270:return new float[]{0,-h,w,0,x,y+h};
   default:return new float[]{w,0,0,h,x,y};
  }
 }
 static float[] point(float x,float y,float offsetX,float offsetY,float scale,float width,float height){return new float[]{(x-offsetX)/scale/width,(y-offsetY)/scale/height};}
}
