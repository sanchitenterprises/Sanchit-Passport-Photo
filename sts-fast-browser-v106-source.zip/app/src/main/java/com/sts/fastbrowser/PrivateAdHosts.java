package com.sts.fastbrowser;
final class PrivateAdHosts {
    private static final String[] HOSTS = new String[] {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.", "adsystem.com", "adnxs.com", "adsrvr.org",
            "taboola.com", "outbrain.com", "criteo.com", "criteo.net",
            "scorecardresearch.com", "zedo.com", "pubmatic.com", "rubiconproject.com",
            "openx.net", "moatads.com", "amazon-adsystem.com", "serving-sys.com",
            "smartadserver.com", "adform.net", "quantserve.com", "yieldmo.com",
            "casalemedia.com", "lijit.com", "smaato.net", "advertising.com",
            "media.net", "revcontent.com", "mgid.com", "exoclick.com",
            "propellerads.com", "popads.net", "popcash.net", "onclickads.net",
            "hilltopads.net", "juicyads.com", "trafficjunky.net", "adsafeprotected.com"
    };
    static boolean blocked(String host) {
        host = host.toLowerCase(java.util.Locale.ROOT);
        for (String entry : HOSTS) {
            if (entry.endsWith(".") ? host.startsWith(entry) : host.equals(entry) || host.endsWith("." + entry)) return true;
        }
        return false;
    }
}
