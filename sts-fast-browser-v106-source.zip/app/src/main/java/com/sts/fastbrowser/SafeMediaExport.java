package com.sts.fastbrowser;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.provider.MediaStore;
import java.io.IOException;
import java.io.OutputStream;

/** Publish a new MediaStore file only after the writer and stream both finish. */
@android.annotation.TargetApi(29)
final class SafeMediaExport {
    interface Writer { void write(OutputStream out) throws Exception; }
    static void write(Context context, Uri collection, ContentValues values, Writer writer) throws Exception {
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri target = context.getContentResolver().insert(collection, values);
        if (target == null) throw new IOException("Unable to create output");
        boolean published = false;
        try {
            try (OutputStream out = context.getContentResolver().openOutputStream(target, "w")) {
                if (out == null) throw new IOException("Unable to open output");
                writer.write(out);
                out.flush();
            }
            ContentValues ready = new ContentValues();
            ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
            if (context.getContentResolver().update(target, ready, null, null) == 0)
                throw new IOException("Unable to publish output");
            published = true;
        } finally {
            if (!published) {
                try { context.getContentResolver().delete(target, null, null); }
                catch (Exception ignored) { }
            }
        }
    }
    private SafeMediaExport() { }
}
