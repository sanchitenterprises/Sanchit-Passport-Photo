package com.sts.fastbrowser;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import org.json.JSONObject;
import java.util.*;
import java.util.function.Supplier;

/** Fullscreen WebChromeClient host and video-only system PiP for both browser modes. */
public final class BrowserVideoController {
    private final Activity activity;
    private final Supplier<WebView> current;
    private final View toolbar;
    private final String script;
    private View customView, hiddenContent;
    private FrameLayout fullscreen;
    private WebChromeClient.CustomViewCallback customCallback;
    private WebView fittedView;
    private boolean pipAllowed=true;
    public void setPipAllowed(boolean allowed){pipAllowed=allowed;}
    private boolean fallbackFull, ready, playing, entering, destroyed;
    private int videoWidth=16, videoHeight=9, previousUi, previousFlags, previousOrientation;
    private final String action;
    private final BroadcastReceiver receiver;

    public BrowserVideoController(Activity activity, Supplier<WebView> current, View toolbar) {
        this.activity=activity;this.current=current;this.toolbar=toolbar;
        String source="";
        try(java.io.InputStream in=activity.getAssets().open("browser-video.js")) {
            java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] bytes=new byte[8192];int n;
            while((n=in.read(bytes))!=-1)out.write(bytes,0,n);source=out.toString("UTF-8");
        } catch(Exception ignored) {}
        script=source;
        action=activity.getPackageName()+".VIDEO_"+UUID.randomUUID();
        receiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){
            if(action.equals(i.getAction()))perform(i.getStringExtra("command"));
        }};
        if(Build.VERSION.SDK_INT>=33)activity.registerReceiver(receiver,new IntentFilter(action),Context.RECEIVER_NOT_EXPORTED);
        else activity.registerReceiver(receiver,new IntentFilter(action));
    }
    public void attach(WebView view) {view.addJavascriptInterface(new Bridge(view),"STSVideo");}
    public void install(WebView view) {if(!destroyed)view.evaluateJavascript("window.__stsPipAllowed="+pipAllowed+";"+script,null);}
    public void reset(WebView view) {
        if(view==current.get()){ready=false;playing=false;updatePip();}
    }
    private final class Bridge {
        private final WebView owner;Bridge(WebView v){owner=v;}
        @JavascriptInterface public void status(String raw){
            if(raw==null || raw.length()>1024)return;
            activity.runOnUiThread(()->{
                if(destroyed || owner!=current.get())return;
                try {JSONObject s=new JSONObject(raw);ready=s.optBoolean("ready");playing=s.optBoolean("playing");
                    videoWidth=Math.max(1,Math.min(16384,s.optInt("width",16)));videoHeight=Math.max(1,Math.min(16384,s.optInt("height",9)));updatePip();
                }catch(Exception ignored){}
            });
        }
        @JavascriptInterface public void command(String command){activity.runOnUiThread(()->{
            if(destroyed || owner!=current.get())return;
            if("full".equals(command))requestFullscreen();else if("pip".equals(command))enterPip(false);
        });}
    }
    public void showCustomView(View view, WebChromeClient.CustomViewCallback callback) {
        if(destroyed || customView!=null){callback.onCustomViewHidden();return;}
        if(fallbackFull)exitFullscreen();
        customView=view;customCallback=callback;
        saveWindow();
        FrameLayout content=activity.findViewById(android.R.id.content);
        hiddenContent=content.getChildAt(0);
        if(hiddenContent!=null)hiddenContent.setVisibility(View.GONE);
        fullscreen=new FrameLayout(activity);fullscreen.setBackgroundColor(Color.BLACK);
        fullscreen.addView(view,new FrameLayout.LayoutParams(-1,-1));
        content.addView(fullscreen,new FrameLayout.LayoutParams(-1,-1));
        immersive();
        playing=true;updatePip();
    }
    private void saveWindow(){previousUi=activity.getWindow().getDecorView().getSystemUiVisibility();previousFlags=activity.getWindow().getAttributes().flags;previousOrientation=activity.getRequestedOrientation();}
    private void immersive(){
        activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        activity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR);
    }
    public boolean exitFullscreen() {
        if(customView==null&&!fallbackFull)return false;
        if(fullscreen!=null){fullscreen.removeAllViews();((ViewGroup)fullscreen.getParent()).removeView(fullscreen);fullscreen=null;}
        customView=null;
        if(hiddenContent!=null){hiddenContent.setVisibility(View.VISIBLE);hiddenContent=null;}
        boolean restoreFit=fallbackFull;fallbackFull=false;
        if(restoreFit && !inPip())restorePage();
        activity.getWindow().setFlags(previousFlags,WindowManager.LayoutParams.FLAG_FULLSCREEN|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        activity.getWindow().getDecorView().setSystemUiVisibility(previousUi);
        activity.setRequestedOrientation(previousOrientation);
        if(toolbar!=null)toolbar.setVisibility(inPip()?View.GONE:View.VISIBLE);
        WebChromeClient.CustomViewCallback callback=customCallback;customCallback=null;
        if(callback!=null)callback.onCustomViewHidden();
        return true;
    }
    public boolean isFullscreen(){return customView!=null||fallbackFull;}
    private boolean inPip(){return Build.VERSION.SDK_INT>=26&&activity.isInPictureInPictureMode();}
    public void requestFullscreen(){
        WebView view=current.get();if(view==null)return;
        if(isFullscreen()){exitFullscreen();return;}
        install(view);
        view.evaluateJavascript("window.__stsVideo && window.__stsVideo.fit('full')",result->{
            if(destroyed||view!=current.get())return;
            if(!"true".equals(result)){toast("Video तैयार होने पर उसका Full Screen बटन दबाएँ");return;}
            fittedView=view;saveWindow();fallbackFull=true;if(toolbar!=null)toolbar.setVisibility(View.GONE);immersive();
        });
    }
    public void perform(String command){
        if(!Arrays.asList("toggle","back","forward","pause").contains(command))return;
        WebView view=current.get();if(view!=null)view.evaluateJavascript("window.__stsVideo && window.__stsVideo.action("+JSONObject.quote(command)+")",null);
    }
    private RemoteAction remote(String label,int icon,String command,int code){
        Intent intent=new Intent(action).setPackage(activity.getPackageName()).putExtra("command",command);
        PendingIntent pending=PendingIntent.getBroadcast(activity,code,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        return new RemoteAction(Icon.createWithResource(activity,icon),label,label,pending);
    }
    private PictureInPictureParams params(){
        float ratio=Math.max(1f/2.39f,Math.min(2.39f,videoWidth/(float)videoHeight));
        PictureInPictureParams.Builder builder=new PictureInPictureParams.Builder()
            .setAspectRatio(new android.util.Rational(Math.round(ratio*10000),10000))
            .setActions(ready ? Arrays.asList(remote("Back 20 seconds",android.R.drawable.ic_media_rew,"back",1),
                remote(playing?"Pause":"Play",playing?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play,"toggle",2),
                remote("Forward 20 seconds",android.R.drawable.ic_media_ff,"forward",3)) : java.util.Collections.emptyList());
        View source=customView!=null?customView:current.get();Rect rect=new Rect();
        if(source!=null&&source.getGlobalVisibleRect(rect))builder.setSourceRectHint(rect);
        if(Build.VERSION.SDK_INT>=31){builder.setAutoEnterEnabled(pipAllowed && playing);builder.setSeamlessResizeEnabled(false);}
        return builder.build();
    }
    public void updatePip(){if(pipAllowed&&Build.VERSION.SDK_INT>=26&&!destroyed)try{activity.setPictureInPictureParams(params());}catch(Exception ignored){}}
    public void enterPip(boolean automatic){
        if(!pipAllowed||destroyed||entering||inPip()||Build.VERSION.SDK_INT<26)return;
        if(automatic && !playing)return;
        // Home/gesture must not await JS after the activity starts leaving the foreground.
        if(automatic) {
            if(Build.VERSION.SDK_INT>=31)return; // System auto-enter was armed at playback start.
            try { activity.enterPictureInPictureMode(params()); } catch(Exception ignored) {}
            return;
        }
        if(customView!=null){try{activity.enterPictureInPictureMode(params());}catch(Exception e){if(!automatic)toast("इस फोन पर छोटी window उपलब्ध नहीं है");}return;}
        WebView view=current.get();if(view==null)return;
        entering=true;install(view);
        view.evaluateJavascript("window.__stsVideo && window.__stsVideo.fit()",result->{
            entering=false;if(destroyed)return;
            if(view!=current.get()||!"true".equals(result)){if(!automatic)toast("चलता हुआ video मिलने पर छोटी window खुलेगी");return;}
            fittedView=view;if(toolbar!=null)toolbar.setVisibility(View.GONE);
            view.post(()->{if(destroyed)return;try{if(!activity.enterPictureInPictureMode(params()))restorePage();}catch(Exception e){restorePage();if(!automatic)toast("Picture-in-picture permission जाँचें");}});
        });
    }
    public void preparePipContent(){
        if(!pipAllowed || destroyed || customView!=null)return;
        WebView view=current.get();if(view==null)return;
        fittedView=view;
        view.evaluateJavascript("window.__stsVideo && window.__stsVideo.fit()",null);
        if(toolbar!=null)toolbar.setVisibility(View.GONE);
    }
    public void pipChanged(boolean pip){
        if(pip)preparePipContent();
        if(toolbar!=null)toolbar.setVisibility(pip||isFullscreen()?View.GONE:View.VISIBLE);
        if(!pip&&!fallbackFull)restorePage();
        else if(!pip&&fallbackFull&&fittedView!=null)fittedView.evaluateJavascript("window.__stsVideo && window.__stsVideo.fit('full')",null);
    }
    private void restorePage(){
        if(fittedView!=null){fittedView.evaluateJavascript("window.__stsVideo && window.__stsVideo.restore()",null);fittedView=null;}
        if(toolbar!=null&&!isFullscreen())toolbar.setVisibility(View.VISIBLE);
    }
    private void toast(String text){Toast.makeText(activity,text,Toast.LENGTH_SHORT).show();}
    public void destroy(){exitFullscreen();restorePage();destroyed=true;try{activity.unregisterReceiver(receiver);}catch(Exception ignored){}}
}
