package com.sts.fastbrowser;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.*;
import android.widget.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.content.res.ColorStateList;
import android.text.InputType;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.view.ViewGroup;
import android.view.MotionEvent;
import org.json.JSONObject;
import org.json.JSONArray;

/** A separate process with a disposable WebView profile; normal cookies stay untouched. */
public class PrivateBrowserActivity extends Activity {
    private LinearLayout root, bar;
    private FrameLayout shield;
    private boolean locked=true, resumed, credentialFlow, pendingUnlock, suppressPrompt;
    private Bundle lockedHistory;
    private String lockedUrl;
    private static final int UNLOCK_REQUEST=991;
    private final ArrayList<Site> privateSites=new ArrayList<>();
    private final ArrayList<android.app.Dialog> privateDialogs=new ArrayList<>();
    private CompactPopupMenu activeMenu;
    private PopupWindow chromePopup;
    private AlertDialog manageSitesDialog;
    private static final String GOOGLE_NAME="Google",GOOGLE_URL="https://www.google.com";
    private String slot2Name="Incognito",slot2Url="";
    private boolean browserLoading;
    private volatile boolean adBlockEnabled=true,hardAdBlockEnabled=true;
    private android.content.SharedPreferences privatePrefs;
    private FrameLayout webStage,loadingOverlay;
    private ImageView loadingLogo;
    private android.animation.AnimatorSet loadingLogoAnimator;
    private Intent pendingPickerData;
    private int pendingPickerResult;
    private boolean pickerDeferred;
    private WebView browser;
    private BrowserVideoController videoController;
    private android.window.OnBackInvokedCallback backCallback;
    private ImageView addressAction;
    private TextView sitesButton;
    private boolean addressEdited, selectedSite;

    private EditText address;
    private ValueCallback<Uri[]> picker;
    private boolean closing;
    private String downloadUrl, downloadAgent;
    private volatile boolean downloadRunning;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (android.os.Build.VERSION.SDK_INT < 28) { finish(); return; }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setStatusBarColor(Color.rgb(79, 143, 139));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(205, 222, 219));
        root.setFitsSystemWindows(true);
        privatePrefs=getSharedPreferences("sts_incognito_sites",MODE_PRIVATE);
        adBlockEnabled=privatePrefs.getBoolean("adblock",true);hardAdBlockEnabled=privatePrefs.getBoolean("hard_adblock",true);
        bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(4),dp(3),dp(4),dp(3));
        bar.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.parseColor("#D9F0EE"),Color.parseColor("#E3EAF4"),Color.parseColor("#EEE8F4")}));
        ImageView home=makeIconButton(R.drawable.ic_home);home.setContentDescription("Private home");home.setOnClickListener(v->showPrivateHome());bar.addView(home,new LinearLayout.LayoutParams(dp(40),-1));
        LinearLayout siteContainer=makeSlotContainer(Color.TRANSPARENT),addressContainer=makeSlotContainer(Color.TRANSPARENT);
        sitesButton=makeSlotLabel("Incognito");android.graphics.drawable.Drawable arrow=getDrawable(R.drawable.ic_dropdown);arrow.setBounds(0,0,dp(12),dp(12));sitesButton.setCompoundDrawables(null,null,arrow,null);sitesButton.setCompoundDrawablePadding(dp(3));sitesButton.setEllipsize(TextUtils.TruncateAt.END);sitesButton.setContentDescription("Incognito websites");
        sitesButton.setOnClickListener(v->showSites(siteContainer));siteContainer.addView(sitesButton,new LinearLayout.LayoutParams(-1,-1));
        LinearLayout.LayoutParams siteLp=new LinearLayout.LayoutParams(0,-1,.85f);siteLp.setMargins(0,0,dp(3),0);bar.addView(siteContainer,siteLp);
        address=makeD2AddressBar();address.setImeOptions(EditorInfo.IME_ACTION_GO|EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
        address.setOnEditorActionListener((v, action, event) -> {
            if (action == EditorInfo.IME_ACTION_GO) { navigate(address.getText().toString()); return true; }
            return false;
        });
        addressContainer.addView(address,new LinearLayout.LayoutParams(-1,-1));LinearLayout.LayoutParams addressLp=new LinearLayout.LayoutParams(0,-1,1.15f);addressLp.setMargins(0,0,dp(3),0);bar.addView(addressContainer,addressLp);
        addressAction=makeIconButton(R.drawable.ic_refresh);addressAction.setContentDescription("Refresh current page");bar.addView(addressAction,new LinearLayout.LayoutParams(dp(40),-1));addressAction.setOnClickListener(v->{
            if(address.hasFocus()&&addressEdited&&!address.getText().toString().trim().isEmpty())navigate(address.getText().toString());
            else {finishEditing();browser.reload();}
        });
        address.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){if(address.hasFocus())addressEdited=true;updateAction();}
            public void afterTextChanged(android.text.Editable e){}
        });
        address.setOnFocusChangeListener((v,focus)->{if(focus)address.post(()->{if(address.hasFocus())address.selectAll();});else{addressEdited=false;syncAddress();}updateAction();});
        ImageView more=makeIconButton(R.drawable.ic_more);more.setContentDescription("Menu");bar.addView(more,new LinearLayout.LayoutParams(dp(40),-1));
        more.setOnClickListener(this::showOptions);
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(54)));
        for(View control:new View[]{home,sitesButton,addressAction,more})applyPressAnimation(control);
        webStage=new FrameLayout(this);root.addView(webStage,new LinearLayout.LayoutParams(-1,0,1));
        loadingOverlay=new FrameLayout(this);loadingOverlay.setBackgroundColor(Color.argb(235,255,255,255));loadingOverlay.setClickable(true);loadingOverlay.setVisibility(View.GONE);
        loadingLogo=new ImageView(this);loadingLogo.setImageResource(R.drawable.sfb_app_icon_v2);loadingLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);loadingLogo.setContentDescription("Loading");
        FrameLayout.LayoutParams logoLp=new FrameLayout.LayoutParams(dp(92),dp(92));logoLp.gravity=Gravity.CENTER;loadingOverlay.addView(loadingLogo,logoLp);webStage.addView(loadingOverlay,new FrameLayout.LayoutParams(-1,-1));
        createBrowser();
        FrameLayout screen=new FrameLayout(this);screen.addView(root,new FrameLayout.LayoutParams(-1,-1));
        shield=new FrameLayout(this);shield.setBackgroundColor(Color.rgb(205,222,219));
        LinearLayout gate=new LinearLayout(this);gate.setOrientation(LinearLayout.VERTICAL);gate.setGravity(Gravity.CENTER);gate.setPadding(dp(24),dp(24),dp(24),dp(24));
        TextView title=new TextView(this);title.setText("Incognito locked");title.setTextSize(22);title.setGravity(Gravity.CENTER);gate.addView(title);
        Button unlock=new Button(this);unlock.setText("Unlock with phone lock");unlock.setOnClickListener(v->requestUnlock());gate.addView(unlock);
        Button close=new Button(this);close.setText("Close private session");close.setOnClickListener(v->closeSession());gate.addView(close);
        shield.addView(gate,new FrameLayout.LayoutParams(-1,-1));screen.addView(shield,new FrameLayout.LayoutParams(-1,-1));
        root.setVisibility(View.INVISIBLE);setContentView(screen);loadPrivateSites();
        if(android.os.Build.VERSION.SDK_INT>=33){backCallback=this::onBackPressed;getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,backCallback);}
        showPrivateHome();
    }

    private void createBrowser(){
        browser = new WebView(this);
        videoController = new BrowserVideoController(this, () -> browser, bar);
        videoController.setPipAllowed(false);
        videoController.attach(browser);
        WebSettings settings = browser.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setDomStorageEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSaveFormData(false);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(browser, false);
        browser.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                if(view!=browser)return;setLoading(true);if(videoController!=null)videoController.reset(view);
                if(!address.hasFocus())address.setText(selectedSite || url.startsWith("https://private.sts.invalid/") ? "" : url);
            }
            @Override public void onPageFinished(WebView view,String url){if(view!=browser)return;setLoading(false);if(adBlockEnabled)injectNormalAdCleanup(view);if(hardAdBlockEnabled)injectHardAdCleanup(view);if(videoController!=null&&!locked)videoController.install(view);}
            @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error){if(view==browser&&request.isForMainFrame())setLoading(false);}
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                if (!request.isForMainFrame() && ((adBlockEnabled && host != null && PrivateAdHosts.blocked(host)) || (hardAdBlockEnabled && isHardAdRequest(request.getUrl()))))
                    return new WebResourceResponse("text/plain", "UTF-8", new java.io.ByteArrayInputStream(new byte[0]));
                return null;
            }
            @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                closeSession();
                return true;
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view,CustomViewCallback callback){if(videoController!=null&&!locked)videoController.showCustomView(view,callback);else callback.onCustomViewHidden();}
            @Override public void onHideCustomView(){if(videoController!=null)videoController.exitFullscreen();}
            @Override public void onProgressChanged(WebView view, int value) {
                if(view==browser)setLoading(value<100);
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (picker != null) picker.onReceiveValue(null);
                picker = callback;
                try { startActivityForResult(params.createIntent(), 2); }
                catch (Exception e) { picker = null; callback.onReceiveValue(null); }
                return true;
            }
        });
        browser.setDownloadListener((url, agent, disposition, type, length) -> {
            if (downloadRunning || downloadUrl != null) {
                Toast.makeText(this, "पहला download पूरा होने दें", Toast.LENGTH_SHORT).show(); return;
            }
            new AlertDialog.Builder(this).setTitle("Save private download?")
                    .setMessage("Save की गई file Incognito बंद करने के बाद भी आपके चुने folder में रहेगी।")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Save", (dialog, which) -> {
                        downloadUrl = url; downloadAgent = agent;
                        Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        save.addCategory(Intent.CATEGORY_OPENABLE);
                        save.setType(type == null || type.isEmpty() ? "application/octet-stream" : type);
                        save.putExtra(Intent.EXTRA_TITLE, URLUtil.guessFileName(url, disposition, type));
                        try { startActivityForResult(save, 3); }
                        catch (Exception e) { downloadUrl = null; Toast.makeText(this, "Save dialog नहीं खुला", Toast.LENGTH_SHORT).show(); }
                    }).show();
        });
        webStage.addView(browser,0,new FrameLayout.LayoutParams(-1,-1));
    }

    private void showPrivateHome(){
        if(browser==null)return;
        finishEditing(); selectedSite=true;slot2Name="Incognito";slot2Url="";sitesButton.setText("Incognito");
        browser.loadDataWithBaseURL("https://private.sts.invalid/",
            "<html><meta name='viewport' content='width=device-width,initial-scale=1'><body style='background:#d5e2df;color:#172623;font-family:sans-serif;padding:24px'>"
            +"<h2>Incognito</h2><p>ऊपर website या search लिखें। Dropdown से saved website खोलें।</p>"
            +"<p>यह session सामान्य browser से अलग है। Menu में Close private session से cookies और local browsing data साफ होंगे।</p>"
            +"<p>डाउनलोड की हुई files रहेंगी। यह mode websites या internet provider से पहचान नहीं छिपाता।</p></body></html>","text/html","UTF-8",null);
        address.setText("");
    }
    private void syncAddress(){String url=browser==null?"":browser.getUrl();address.setText(selectedSite||url==null||url.startsWith("https://private.sts.invalid/")?"":url);}
    private void updateAction(){if(addressAction==null)return;boolean search=address.hasFocus()&&addressEdited&&!address.getText().toString().trim().isEmpty();addressAction.setImageResource(search?R.drawable.ic_search:R.drawable.ic_refresh);addressAction.setContentDescription(search?"Search":"Refresh");}
    private void finishEditing(){addressEdited=false;address.clearFocus();if(browser!=null)browser.requestFocus();((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);updateAction();}






    private void navigate(String value) {
        String text = value.trim();
        if (text.isEmpty()) return;
        String url = text;
        if (!url.startsWith("https://") && !url.startsWith("http://"))
            url = (!url.contains(" ") && url.contains(".")) ? "https://" + url
                    : "https://www.google.com/search?q=" + Uri.encode(url);
        selectedSite=false;sitesButton.setText("Incognito");
        browser.loadUrl(url);
        browser.requestFocus();
        ((android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(address.getWindowToken(), 0);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if(request==UNLOCK_REQUEST){credentialFlow=false;suppressPrompt=true;
            if(result==RESULT_OK){if(resumed)unlockPrivate();else pendingUnlock=true;}return;}
        if(request==2&&locked){pendingPickerData=data;pendingPickerResult=result;pickerDeferred=true;return;}
        if (request == 3) {
            final String url = downloadUrl;
            final String agent = downloadAgent;
            downloadUrl = null; downloadAgent = null;
            if (result == RESULT_OK && data != null && data.getData() != null && url != null)
                savePrivateDownload(url, agent, data.getData());
        }
        if (request == 2 && picker != null) {
            ValueCallback<Uri[]> callback = picker; picker = null;
            ArrayList<Uri> files = new ArrayList<>();
            if (result == RESULT_OK && data != null) {
                if (data.getClipData() != null) for (int i = 0; i < data.getClipData().getItemCount(); i++)
                    files.add(data.getClipData().getItemAt(i).getUri());
                if (data.getData() != null && !files.contains(data.getData())) files.add(data.getData());
            }
            callback.onReceiveValue(files.isEmpty() ? null : files.toArray(new Uri[0]));
        }
    }

    private void savePrivateDownload(String url, String agent, Uri target) {
        downloadRunning = true;
        Toast.makeText(this, "Download शुरू हुआ", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            java.io.File temp = null;
            boolean success = false;
            try {
                temp = java.io.File.createTempFile("private-download-", ".tmp", getCacheDir());
                SafeHttpDownload.download(url, temp, agent, null, null,
                        link -> CookieManager.getInstance().getCookie(link));
                try (java.io.InputStream in = new java.io.FileInputStream(temp);
                     java.io.OutputStream out = getContentResolver().openOutputStream(target, "wt")) {
                    if (out == null) throw new java.io.IOException("No output");
                    byte[] buffer = new byte[65536]; int count;
                    while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                }
                success = true;
            } catch (Exception e) {
                try { android.provider.DocumentsContract.deleteDocument(getContentResolver(), target); }
                catch (Exception ignored) { }
            } finally {
                if (temp != null) temp.delete();
                downloadRunning = false;
                final boolean saved = success;
                runOnUiThread(() -> {
                    if (!isFinishing() && !isDestroyed()) Toast.makeText(this,
                            saved ? "File save हो गई" : "Download पूरा नहीं हुआ", Toast.LENGTH_LONG).show();
                });
            }
        }, "STS-Private-Download").start();
    }

    @Override public void onBackPressed() {
        if(locked){moveTaskToBack(true);return;}
        if(videoController!=null&&videoController.exitFullscreen())return;
        if(address.hasFocus()){finishEditing();return;}
        if (browser != null && browser.canGoBack()) browser.goBack(); else closeSession();
    }

    private void closeSession() {
        if (closing) return;
        if (downloadRunning) {
            Toast.makeText(this, "File save हो रही है। पूरा होने के बाद session बंद करें।", Toast.LENGTH_LONG).show();
            return;
        }
        closing = true;
        if (picker != null) { picker.onReceiveValue(null); picker = null; }
        if (browser != null) { browser.stopLoading(); browser.loadUrl("about:blank"); browser.clearHistory(); browser.clearCache(true); }
        WebStorage.getInstance().deleteAllData();
        GeolocationPermissions.getInstance().clearAll();
        CookieManager.getInstance().removeAllCookies(done -> {
            CookieManager.getInstance().flush();
            finishAndRemoveTask();
        });
        new android.os.Handler(getMainLooper()).postDelayed(this::finishAndRemoveTask, 1500);
    }

    @Override protected void onResume(){
        super.onResume();resumed=true;
        if(pendingUnlock)unlockPrivate();else if(locked&&!credentialFlow&&!suppressPrompt)requestUnlock();
    }
    @Override protected void onPause(){
        resumed=false;
        if(!credentialFlow)suppressPrompt=false;
        lockPrivate();super.onPause();
    }
    @Override protected void onUserLeaveHint(){lockPrivate();super.onUserLeaveHint();}
    @Override protected void onStop(){super.onStop();}
    private void requestUnlock(){
        if(!locked||!resumed||credentialFlow||closing)return;
        android.app.KeyguardManager key=(android.app.KeyguardManager)getSystemService(KEYGUARD_SERVICE);
        if(key==null||!key.isDeviceSecure()){
            suppressPrompt=true;
            new AlertDialog.Builder(this).setTitle("Phone lock required")
                .setMessage("Incognito खोलने के लिए पहले फोन में PIN, pattern या password लगाएँ।")
                .setNegativeButton("Cancel",null).setPositiveButton("Phone settings",(d,w)->startActivity(new Intent(android.provider.Settings.ACTION_SECURITY_SETTINGS))).show();return;
        }
        Intent intent=key.createConfirmDeviceCredentialIntent("Unlock Incognito","फोन के screen lock से पहचान की पुष्टि करें");
        if(intent==null)return;
        try{credentialFlow=true;startActivityForResult(intent,UNLOCK_REQUEST);}
        catch(Exception e){credentialFlow=false;suppressPrompt=true;Toast.makeText(this,"फोन का unlock dialog नहीं खुला। दोबारा कोशिश करें।",Toast.LENGTH_LONG).show();}
    }
    private void lockPrivate(){
        if(locked||closing||root==null)return;
        locked=true;pendingUnlock=false;
        if(videoController!=null)videoController.exitFullscreen();
        root.setVisibility(View.INVISIBLE);shield.setVisibility(View.VISIBLE);
        if(activeMenu!=null){activeMenu.dismiss();activeMenu=null;}
        if(chromePopup!=null){chromePopup.dismiss();chromePopup=null;}
        stopLoadingLogoAnimation();loadingOverlay.setVisibility(View.GONE);
        for(android.app.Dialog dialog:new ArrayList<>(privateDialogs))dialog.dismiss();
        if(browser==null)return;
        if(picker!=null){
            // Keep the upload callback alive during the Android file chooser.
            browser.evaluateJavascript("(function stop(w){try{w.document.querySelectorAll('video,audio').forEach(function(v){v.pause();v.autoplay=false;});for(var i=0;i<w.frames.length;i++)stop(w.frames[i]);}catch(e){}})(window)",null);
            browser.onPause();browser.pauseTimers();return;
        }
        lockedUrl=browser.getUrl();lockedHistory=new Bundle();browser.saveState(lockedHistory);
        videoController.destroy();videoController=null;
        browser.stopLoading();webStage.removeView(browser);browser.destroy();browser=null;
    }
    private void unlockPrivate(){
        if(!locked||closing)return;
        if(browser==null){createBrowser();
            if(lockedHistory==null||browser.restoreState(lockedHistory)==null){
                if(lockedUrl!=null&&(lockedUrl.startsWith("https://")||lockedUrl.startsWith("http://"))&&!lockedUrl.startsWith("https://private.sts.invalid/"))browser.loadUrl(lockedUrl);else showPrivateHome();
            }
        }
        lockedHistory=null;lockedUrl=null;browser.resumeTimers();browser.onResume();
        locked=false;pendingUnlock=false;suppressPrompt=false;videoController.install(browser);setLoading(browserLoading);root.setVisibility(View.VISIBLE);shield.setVisibility(View.GONE);
        if(pickerDeferred){pickerDeferred=false;Intent data=pendingPickerData;pendingPickerData=null;onActivityResult(2,pendingPickerResult,data);}
    }
    private void trackDialog(android.app.Dialog dialog){privateDialogs.add(dialog);dialog.setOnDismissListener(d->privateDialogs.remove(dialog));}





    @Override protected void onDestroy() {
        stopLoadingLogoAnimation();
        if(android.os.Build.VERSION.SDK_INT>=33 && backCallback!=null)getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);
        if(videoController!=null)videoController.destroy();
        if (browser != null) {
            ((android.view.ViewGroup) browser.getParent()).removeView(browser);
            browser.destroy(); browser = null;
        }
        super.onDestroy();
        if (isFinishing()) {
            ((BrowserApplication) getApplication()).clearOldPrivateProfiles();
            android.os.Process.killProcess(android.os.Process.myPid());
        }
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private LinearLayout makeSlotContainer(int baseColor) {
        LinearLayout slot = new LinearLayout(this);
        slot.setOrientation(LinearLayout.HORIZONTAL);
        slot.setGravity(Gravity.CENTER_VERTICAL);
        slot.setPadding(dp(1), 0, dp(1), 0);
        slot.setBackground(makeRipple(Color.TRANSPARENT));
        return slot;
    }

    private TextView makeSlotLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#162326"));
        tv.setTextSize(13);
        tv.setGravity(Gravity.CENTER);
        tv.setSingleLine(true);
        tv.setPadding(dp(2), 0, dp(2), 0);
        tv.setClickable(true);
        tv.setFocusable(true);
        return tv;
    }

    private EditText makeD2AddressBar() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(Color.parseColor("#162326"));
        input.setHintTextColor(Color.parseColor("#68777A"));
        input.setHint("Search or type website");
        input.setTextSize(12);
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.setPadding(dp(7), 0, dp(3), 0);
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_GO);
        input.setSelectAllOnFocus(false);
        input.setLongClickable(true);
        input.setTextIsSelectable(true);

        input.setCompoundDrawablePadding(dp(2));
        return input;
    }

    private ImageView makeIconButton(int drawableRes) {
        ImageView iv = new ImageView(this);
        iv.setImageResource(drawableRes);
        iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        iv.setPadding(dp(8), dp(8), dp(8), dp(8));
        iv.setClickable(true);
        iv.setFocusable(true);
        iv.setBackground(makeRipple(Color.TRANSPARENT));
        return iv;
    }

    private RippleDrawable makeRipple(int baseColor) {
        GradientDrawable base = new GradientDrawable();
        base.setColor(baseColor);
        base.setCornerRadius(dp(10));
        if (Color.alpha(baseColor) != 0) base.setStroke(dp(1), darken(baseColor, 0.12f));
        ColorStateList ripple = ColorStateList.valueOf(withAlpha(Color.parseColor("#203B40"), 48));
        return new RippleDrawable(ripple, base, null);
    }

    private int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }

    private int darken(int color, float amount) {
        int r = Math.max(0, (int)(Color.red(color) * (1f - amount)));
        int g = Math.max(0, (int)(Color.green(color) * (1f - amount)));
        int b = Math.max(0, (int)(Color.blue(color) * (1f - amount)));
        return Color.rgb(r, g, b);
    }

    private void applyPressAnimation(View v) {
        v.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(70).start();
            } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(110).start();
            }
            return false;
        });
    }

    private int measureMainMenuWidth(String... labels) {
        TextView probe = new TextView(this);
        probe.setTextSize(15);
        probe.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));

        float widest = 0f;
        if (labels != null) {
            for (String label : labels) {
                if (label == null) continue;
                widest = Math.max(widest, probe.getPaint().measureText(label));
            }
        }

        // 10dp left text inset + 2dp outer padding on each side + tiny rounding safety.
        // The longest label therefore finishes almost at the popup's right edge.
        return Math.max(dp(96), (int) Math.ceil(widest) + dp(16));
    }

    private ImageButton makeHistoryButton(int iconRes, String description) {
        ImageButton button = new ImageButton(this);
        button.setImageResource(iconRes);
        button.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        button.setPadding(dp(10), dp(2), dp(10), dp(2));
        button.setScaleType(ImageView.ScaleType.FIT_CENTER);
        button.setColorFilter(Color.parseColor("#263C40"));
        button.setContentDescription(description);
        button.setBackground(new RippleDrawable(
                ColorStateList.valueOf(Color.parseColor("#18000000")),
                new ColorDrawable(Color.TRANSPARENT),
                null));
        applyPressAnimation(button);
        return button;
    }

    private void setHistoryButtonEnabled(ImageButton button, boolean enabled) {
        button.setEnabled(enabled);
        button.setAlpha(enabled ? 1f : 0.55f);
    }

    private void addMainMenuAction(LinearLayout box, String label, Runnable action) {
        TextView item = new TextView(this);
        item.setText(label);
        item.setTextColor(Color.parseColor("#172326"));
        item.setTextSize(15);
        item.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        item.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_START);
        item.setSingleLine(true);
        item.setMaxLines(1);
        item.setHorizontallyScrolling(true);
        item.setEllipsize(null);
        item.setPadding(dp(10), 0, 0, 0);
        item.setBackground(new RippleDrawable(
                ColorStateList.valueOf(Color.parseColor("#224F8F8B")),
                new ColorDrawable(Color.TRANSPARENT),
                null));
        item.setClickable(true);
        item.setFocusable(true);
        item.setOnClickListener(v -> {
            if (action != null) action.run();
        });
        applyPressAnimation(item);
        box.addView(item, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
    }

    private void fitPopupHeight(PopupWindow popup, View content, View anchor, int width) {
        android.graphics.Rect frame = new android.graphics.Rect();
        anchor.getWindowVisibleDisplayFrame(frame);
        int[] location = new int[2];
        anchor.getLocationOnScreen(location);
        int available = Math.max(dp(48), frame.bottom - location[1] - anchor.getHeight() - dp(8));
        content.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        popup.setHeight(Math.min(available, content.getMeasuredHeight()));
        popup.setClippingEnabled(true);
    }

    private TextView makePopupItem(String text) {
        TextView item = new TextView(this);
        item.setText(text);
        item.setTextSize(14);
        item.setSingleLine(true);
        item.setEllipsize(TextUtils.TruncateAt.END);
        item.setContentDescription(text);
        item.setTextColor(Color.parseColor("#172326"));
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(12), 0, dp(8), 0);
        GradientDrawable base = new GradientDrawable();
        base.setColor(Color.WHITE);
        base.setCornerRadius(dp(10));
        item.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.parseColor("#334F8F8B")), base, null));
        applyPressAnimation(item);
        return item;
    }

    private TextView makePasswordAction(String text, boolean primary) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setTextColor(primary ? Color.WHITE : Color.parseColor("#355C62"));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(primary ? Color.parseColor("#4F8F8B") : Color.parseColor("#E7EFEE"));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), primary ? Color.parseColor("#3D7774") : Color.parseColor("#AEC7C4"));
        button.setBackground(new RippleDrawable(
                ColorStateList.valueOf(primary ? 0x33FFFFFF : 0x22355C62), bg, null));
        button.setClickable(true);
        button.setFocusable(true);
        return button;
    }

    private boolean containsUrl(List<Site> list, String url) {
        for (Site s : list) {
            if (s.url.equalsIgnoreCase(url)) return true;
        }
        return false;
    }

    private String hashPassword(String raw) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] out = digest.digest((raw == null ? "" : raw).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : out) sb.append(String.format(Locale.ROOT, "%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return raw == null ? "" : raw;
        }
    }

    private String normalizeUrl(String raw) {
        if (raw == null) return null;
        raw = raw.trim();
        if (raw.isEmpty()) return null;
        if (!raw.matches("(?i)^[a-z][a-z0-9+.-]*://.*$")) raw = "https://" + raw;
        try {
            Uri u = Uri.parse(raw);
            String scheme = u.getScheme();
            String host = u.getHost();
            if (scheme == null || host == null) return null;
            if (!(scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https"))) return null;
            return u.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private String currentAppVersion() {
        try {
            android.content.pm.PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            return info.versionName == null ? "" : info.versionName;
        } catch (Exception e) {
            return "";
        }
    }

    private void injectNormalAdCleanup(WebView view) {
        if (view == null) return;
        String js =
                "(function(){" +
                "if(window.__stsNormalAdBlockInstalled){try{window.__stsNormalAdClean&&window.__stsNormalAdClean();}catch(e){}return;}" +
                "window.__stsNormalAdBlockInstalled=true;" +
                "var sel=[" +
                "'ins.adsbygoogle','.adsbygoogle','[id^=\"google_ads_\"]','[id^=\"div-gpt-ad\"]'," +
                "'iframe[src*=\"doubleclick.net\"]','iframe[src*=\"googlesyndication.com\"]'," +
                "'iframe[src*=\"googleadservices.com\"]','[data-ad-client]','[data-ad-slot]'," +
                "'amp-ad','.advertisement','.ad-container','.ad-banner','.ad-wrapper'" +
                "];" +
                "window.__stsNormalAdClean=function(){for(var i=0;i<sel.length;i++){var n=[];try{n=document.querySelectorAll(sel[i]);}catch(e){}" +
                "for(var j=0;j<n.length;j++){try{n[j].style.setProperty('display','none','important');" +
                "n[j].style.setProperty('visibility','hidden','important');}catch(e){}}}};" +
                "window.__stsNormalAdClean();" +
                "try{var __stsNormalPending=false;new MutationObserver(function(){if(__stsNormalPending)return;__stsNormalPending=true;" +
                "setTimeout(function(){__stsNormalPending=false;window.__stsNormalAdClean();},180);}).observe(document.documentElement||document," +
                "{childList:true,subtree:true});}catch(e){}" +
                "})();";
        try { view.evaluateJavascript(js, null); } catch (Exception ignored) {}
    }

    private void injectHardAdCleanup(WebView view) {
        if (view == null) return;
        String js =
                "(function(){" +
                "if(window.__stsHardAdBlockInstalled){try{window.__stsHardAdClean&&window.__stsHardAdClean();}catch(e){}return;}" +
                "window.__stsHardAdBlockInstalled=true;" +
                "var sel=[" +
                "'amp-embed[type=\"taboola\"]','.sponsored','.promoted','.promoted-content'," +
                "'#player-ads','ytd-ad-slot-renderer','ytd-display-ad-renderer','ytd-promoted-sparkles-web-renderer'," +
                "'ytd-in-feed-ad-layout-renderer','ytd-promoted-video-renderer','ytm-promoted-video-renderer'," +
                "'ytm-companion-ad-renderer','ytm-display-ad-renderer','ytm-ad-slot-renderer','tp-yt-paper-dialog ytd-mealbar-promo-renderer'" +
                "];" +
                "function hideAds(){for(var i=0;i<sel.length;i++){var n=[];try{n=document.querySelectorAll(sel[i]);}catch(e){}" +
                "for(var j=0;j<n.length;j++){try{n[j].style.setProperty('display','none','important');" +
                "n[j].style.setProperty('visibility','hidden','important');n[j].setAttribute('aria-hidden','true');}catch(e){}}}}" +
                "function clickSkip(){var q=['.ytp-ad-skip-button-modern','.ytp-ad-skip-button','.ytp-skip-ad-button'," +
                "'button.ytp-ad-skip-button','button[id*=skip]'];for(var i=0;i<q.length;i++){var b=null;try{b=document.querySelector(q[i]);}catch(e){}" +
                "if(b&&b.offsetParent!==null){try{b.click();return true;}catch(e){}}}return false;}" +
                "function youtube(){try{" +
                "var p=document.querySelector('.html5-video-player');if(!p)return;" +
                "var ad=p.classList.contains('ad-showing')||p.classList.contains('ad-interrupting');" +
                "var v=p.querySelector('video');" +
                "if(ad&&v){" +
                "if(!window.__stsYtAdActive){window.__stsYtAdActive=true;window.__stsYtPrevMuted=!!v.muted;" +
                "window.__stsYtPrevRate=(v.playbackRate&&isFinite(v.playbackRate))?v.playbackRate:1;}" +
                "clickSkip();" +
                "try{v.muted=true;}catch(e){}" +
                "try{if(v.playbackRate<8)v.playbackRate=8;}catch(e){}" +
                "}else if(window.__stsYtAdActive&&v){" +
                "window.__stsYtAdActive=false;" +
                "try{v.playbackRate=window.__stsYtPrevRate||1;}catch(e){}" +
                "try{v.muted=!!window.__stsYtPrevMuted;}catch(e){}" +
                "}" +
                "}catch(e){}}" +
                "window.__stsHardAdClean=function(){hideAds();youtube();};" +
                "window.__stsHardAdClean();" +
                "try{var __stsAdPending=false,__stsSchedule=function(){if(__stsAdPending||document.hidden)return;__stsAdPending=true;" +
                "setTimeout(function(){__stsAdPending=false;if(!document.hidden)window.__stsHardAdClean();},180);};" +
                "new MutationObserver(__stsSchedule).observe(document.documentElement||document,{childList:true,subtree:true,attributes:true,attributeFilter:['class']});" +
                "document.addEventListener('play',__stsSchedule,true);document.addEventListener('loadedmetadata',__stsSchedule,true);" +
                "document.addEventListener('ended',__stsSchedule,true);document.addEventListener('visibilitychange',__stsSchedule,true);}catch(e){}" +
                
                "})();";
        try { view.evaluateJavascript(js, null); } catch (Exception ignored) {}
    }

    private boolean isHardAdRequest(Uri uri) {
        if (uri == null) return false;

        String host = uri.getHost();
        String path = uri.getEncodedPath();
        String query = uri.getEncodedQuery();
        host = host == null ? "" : host.toLowerCase(Locale.ROOT);
        path = path == null ? "" : path.toLowerCase(Locale.ROOT);
        query = query == null ? "" : query.toLowerCase(Locale.ROOT);

        // YouTube can keep the player waiting on a black frame when its own
        // ad endpoints are cancelled. Let YouTube requests complete and handle
        // its web ads in-page by auto-skip + safe fast playback instead.
        if (host.endsWith("googlevideo.com") ||
                host.equals("youtube.com") || host.endsWith(".youtube.com") ||
                host.equals("youtu.be") || host.endsWith(".youtu.be")) {
            return false;
        }

        // Aggressive same-host filtering remains enabled for other websites.
        return path.contains("/gampad/") ||
                path.contains("/pagead/") ||
                path.contains("/adserver/") ||
                path.contains("/adservice/") ||
                path.contains("/prebid/") ||
                path.contains("/vast/") ||
                path.contains("/vmap/") ||
                query.contains("google_ad_client=") ||
                query.contains("ad_slot=") ||
                query.contains("adunit=");
    }

    private void startLoadingLogoAnimation() {
        if (loadingLogo == null) return;
        if (loadingLogoAnimator != null && loadingLogoAnimator.isRunning()) return;

        loadingLogo.setScaleX(0.86f);
        loadingLogo.setScaleY(0.86f);
        loadingLogo.setAlpha(0.62f);

        android.animation.ObjectAnimator sx = android.animation.ObjectAnimator.ofFloat(loadingLogo, View.SCALE_X, 0.86f, 1.08f);
        android.animation.ObjectAnimator sy = android.animation.ObjectAnimator.ofFloat(loadingLogo, View.SCALE_Y, 0.86f, 1.08f);
        android.animation.ObjectAnimator alpha = android.animation.ObjectAnimator.ofFloat(loadingLogo, View.ALPHA, 0.62f, 1f);
        sx.setDuration(620);
        sy.setDuration(620);
        alpha.setDuration(620);
        sx.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        sy.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        alpha.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        sx.setRepeatMode(android.animation.ValueAnimator.REVERSE);
        sy.setRepeatMode(android.animation.ValueAnimator.REVERSE);
        alpha.setRepeatMode(android.animation.ValueAnimator.REVERSE);

        loadingLogoAnimator = new android.animation.AnimatorSet();
        loadingLogoAnimator.playTogether(sx, sy, alpha);
        loadingLogoAnimator.start();
    }

    private void stopLoadingLogoAnimation() {
        if (loadingLogoAnimator != null) {
            loadingLogoAnimator.cancel();
            loadingLogoAnimator = null;
        }
        if (loadingLogo != null) {
            loadingLogo.setScaleX(1f);
            loadingLogo.setScaleY(1f);
            loadingLogo.setAlpha(1f);
        }
    }

    private void showAddWebsiteDialog(int slot) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20), dp(8), dp(20), 0);

        EditText name = new EditText(this);
        name.setHint("Website name");
        name.setSingleLine(true);
        EditText url = new EditText(this);
        url.setHint("URL (example.com)");
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        body.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        body.addView(url, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Add Website")
                .setView(body)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            String u = normalizeUrl(url.getText().toString().trim());
            if (n.isEmpty() || u == null) {
                Toast.makeText(this, "Name और सही URL डालें", Toast.LENGTH_SHORT).show();
                return;
            }
            Site s = new Site(n, u, "");
            List<Site> target = getSites(slot);
            if (GOOGLE_URL.equalsIgnoreCase(u) || containsUrl(privateSites, u)) {
                Toast.makeText(this, "यह website इस dropdown में पहले से है", Toast.LENGTH_SHORT).show();
                return;
            }
            target.add(s);
            saveSites(slot);
            dialog.dismiss();
            selectSite(slot, s);
        }));
        trackDialog(dialog);dialog.show();
    }

    private void showAdBlockerDialog() {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20), dp(8), dp(20), dp(8));
        android.widget.Switch normal = new android.widget.Switch(this);
        normal.setText("Normal"); normal.setChecked(adBlockEnabled);
        android.widget.Switch hard = new android.widget.Switch(this);
        hard.setText("Hard"); hard.setChecked(hardAdBlockEnabled);
        body.addView(normal, new LinearLayout.LayoutParams(-1, dp(52)));
        body.addView(hard, new LinearLayout.LayoutParams(-1, dp(52)));
        normal.setOnCheckedChangeListener((button, enabled) -> setAdBlockEnabled(enabled, true));
        hard.setOnCheckedChangeListener((button, enabled) -> setHardAdBlockEnabled(enabled, true));
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Ad Blocker")
                .setView(body).setPositiveButton("Close", null).create();
        trackDialog(dialog);
        dialog.show();
    }

    private void showManageSitesDialog() {
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(10), dp(8), dp(10), dp(8));

        addManageSection(list);

        ScrollView sc = new ScrollView(this);
        sc.addView(list);
        if (manageSitesDialog != null && manageSitesDialog.isShowing()) {
            manageSitesDialog.dismiss();
        }
        manageSitesDialog = new AlertDialog.Builder(this)
                .setTitle("Manage Websites")
                .setNeutralButton("Add Website", (d, which) -> showAddWebsiteDialog(2))
                .setView(sc)
                .setPositiveButton("Close", null)
                .create();
        privateDialogs.add(manageSitesDialog);
        manageSitesDialog.setOnDismissListener(d -> { privateDialogs.remove(d);if (manageSitesDialog == d) manageSitesDialog = null; });
        manageSitesDialog.show();
    }

    private void addManageSection(LinearLayout list) {
        List<Site> source = orderedCustomSites();
        if (source.isEmpty()) {
            TextView none = new TextView(this);
            none.setText("Custom website अभी add नहीं है");
            none.setTextColor(Color.DKGRAY);
            none.setTextSize(13);
            none.setPadding(dp(12), dp(6), dp(8), dp(10));
            list.addView(none, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
            return;
        }

        for (int i = 0; i < source.size(); i++) {
            Site s = source.get(i);
            final int slot = siteOwner(s);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(2), dp(2), dp(2), dp(2));

            TextView title = new TextView(this);
            title.setText(s.name + (s.hasPassword() ? "  🔒" : ""));
            title.setTextColor(Color.parseColor("#172326"));
            title.setTextSize(13);
            title.setPadding(dp(8), dp(4), dp(6), dp(4));

            ImageButton more = new ImageButton(this);
            more.setImageResource(R.drawable.ic_more);
            more.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            more.setPadding(dp(10), dp(10), dp(10), dp(10));
            more.setBackgroundColor(Color.TRANSPARENT);
            more.setContentDescription("Website options");

            row.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1f));
            row.addView(more, new LinearLayout.LayoutParams(dp(48), dp(48)));
            more.setOnClickListener(v -> showManagedSiteMenu(v, s, slot, title));

            list.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        }
    }

    private void showManagedSiteMenu(View anchor, Site site, int slot, TextView titleView) {
        CompactPopupMenu pm = new CompactPopupMenu(this, anchor, Gravity.END);
        pm.getMenu().add("Open Website");
        pm.getMenu().add("Edit");
        pm.getMenu().add(site.hasPassword() ? "Change Password" : "Set Password");

        List<Site> currentSites = orderedCustomSites();
        int currentIndex = currentSites.indexOf(site);
        android.view.MenuItem moveUp = pm.getMenu().add("Move Up");
        android.view.MenuItem moveDown = pm.getMenu().add("Move Down");
        moveUp.setEnabled(currentIndex > 0);
        moveDown.setEnabled(currentIndex >= 0 && currentIndex < currentSites.size() - 1);

        pm.getMenu().add("Remove Website");
        pm.setOnMenuItemClickListener(item -> {
            String t = String.valueOf(item.getTitle());
            if (t.equals("Open Website")) {
                if (manageSitesDialog != null) manageSitesDialog.dismiss();
                selectSite(slot, site);
                return true;
            }
            if (t.equals("Edit")) {
                Runnable openEditor = () -> showEditWebsiteDialog(site, slot, titleView);
                if (site.hasPassword()) {
                    showSitePasswordDialog(site, openEditor);
                } else {
                    openEditor.run();
                }
                return true;
            }
            if (t.equals("Set Password") || t.equals("Change Password")) {
                Runnable change = () -> showSetSitePasswordDialog(site, slot);
                if (site.hasPassword()) showSitePasswordDialog(site, change); else change.run();
                return true;
            }
            if (t.equals("Move Up")) {
                reorderSite(site, slot, -1);
                return true;
            }
            if (t.equals("Move Down")) {
                reorderSite(site, slot, 1);
                return true;
            }
            if (t.equals("Remove Website")) {
                confirmDeleteSite(site, slot);
                return true;
            }
            return false;
        });
        activeMenu=pm;pm.show();
    }

    private void showEditWebsiteDialog(Site site, int slot, TextView titleView) {
        if (site == null) return;

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20), dp(8), dp(20), 0);

        EditText name = new EditText(this);
        name.setHint("Website name");
        name.setSingleLine(true);
        name.setText(site.name);

        EditText url = new EditText(this);
        url.setHint("URL (example.com)");
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setText(site.url);

        body.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        body.addView(url, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit Website")
                .setView(body)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String newName = name.getText().toString().trim();
            String newUrl = normalizeUrl(url.getText().toString().trim());
            if (newName.isEmpty() || newUrl == null) {
                Toast.makeText(this, "Name और सही URL डालें", Toast.LENGTH_SHORT).show();
                return;
            }

            List<Site> allSites = new ArrayList<>(privateSites);
            for (Site other : allSites) {
                if (!newUrl.equalsIgnoreCase(site.url) && other != site && newUrl.equalsIgnoreCase(other.url)) {
                    Toast.makeText(this, "यह website इस dropdown में पहले से है", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            String oldUrl = site.url;
            site.name = newName;
            site.url = newUrl;
            saveSites(slot);

            if (oldUrl.equals(slot2Url)) {
                slot2Name = newName;
                slot2Url = newUrl;
            }
            updateSlotLabels();

            if (titleView != null) {
                titleView.setText(site.name + (site.hasPassword() ? "  🔒" : ""));
            }

            dialog.dismiss();
            Toast.makeText(this, "Website updated", Toast.LENGTH_SHORT).show();
        }));
        trackDialog(dialog);dialog.show();
    }

    private void showSetSitePasswordDialog(Site site, int slot) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(4), dp(18), 0);

        EditText pass1 = new EditText(this);
        pass1.setHint("New password");
        pass1.setSingleLine(true);
        pass1.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText pass2 = new EditText(this);
        pass2.setHint("Confirm password");
        pass2.setSingleLine(true);
        pass2.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        body.addView(pass1, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        body.addView(pass2, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(site.hasPassword() ? "Change Password" : "Set Password")
                .setView(body)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String p1 = pass1.getText().toString();
            String p2 = pass2.getText().toString();
            if (p1.length() < 4) {
                pass1.setError("कम से कम 4 अक्षर");
                return;
            }
            if (!p1.equals(p2)) {
                pass2.setError("Password match नहीं है");
                return;
            }
            site.passwordHash = hashPassword(p1);
            saveSites(slot);
            dialog.dismiss();
            if (manageSitesDialog != null) showManageSitesDialog();
            Toast.makeText(this, "Password saved", Toast.LENGTH_SHORT).show();
        }));
        trackDialog(dialog);dialog.show();
    }

    private void reorderSite(Site site, int slot, int direction) {
        List<Site> sites = orderedCustomSites();
        int from = sites.indexOf(site), to = from + direction;
        if (from < 0 || to < 0 || to >= sites.size()) return;
        java.util.Collections.swap(sites, from, to);
        for (int i = 0; i < sites.size(); i++) sites.get(i).order = i;
        privateSites.clear();privateSites.addAll(sites);
        saveSites(2);
        showManageSitesDialog();
    }

    private void confirmDeleteSite(Site site, int slot) {
        AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle("Remove " + site.name + "?")
                .setMessage("इस website को list से हटाना है?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Remove", (d, w) -> {
                    getSites(slot).remove(site);
                    if (slot == 2 && slot2Url.equals(site.url)) {
                        slot2Name = GOOGLE_NAME;
                        slot2Url = GOOGLE_URL;
                    }
                    saveSites(slot);
                            updateSlotLabels();
                    if (manageSitesDialog != null) showManageSitesDialog();
                    Toast.makeText(this, "Website removed", Toast.LENGTH_SHORT).show();
                }).create();
        trackDialog(dialog);dialog.show();
    }

    private void showSitePasswordDialog(Site site, Runnable onSuccess) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(22), dp(18), dp(22), dp(12));

        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(Color.parseColor("#F7FAF9"));
        panelBg.setCornerRadius(dp(18));
        panelBg.setStroke(dp(1), Color.parseColor("#B7CBC8"));
        body.setBackground(panelBg);

        TextView lockBadge = new TextView(this);
        lockBadge.setText("SECURE WEBSITE");
        lockBadge.setTextColor(Color.parseColor("#355C62"));
        lockBadge.setTextSize(11);
        lockBadge.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        lockBadge.setGravity(Gravity.CENTER);
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setColor(Color.parseColor("#D9F0EE"));
        badgeBg.setCornerRadius(dp(12));
        lockBadge.setBackground(badgeBg);
        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(dp(142), dp(28));
        badgeLp.gravity = Gravity.CENTER_HORIZONTAL;
        body.addView(lockBadge, badgeLp);

        TextView title = new TextView(this);
        title.setText(site.name);
        title.setTextColor(Color.parseColor("#172326"));
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(12), 0, dp(4));
        body.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView subtitle = new TextView(this);
        subtitle.setText("Website खोलने के लिए password डालें");
        subtitle.setTextColor(Color.parseColor("#5B676A"));
        subtitle.setTextSize(13);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, dp(14));
        body.addView(subtitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout passRow = new LinearLayout(this);
        passRow.setOrientation(LinearLayout.HORIZONTAL);
        passRow.setGravity(Gravity.CENTER_VERTICAL);
        passRow.setPadding(dp(4), 0, dp(4), 0);
        GradientDrawable passBg = new GradientDrawable();
        passBg.setColor(Color.WHITE);
        passBg.setCornerRadius(dp(12));
        passBg.setStroke(dp(1), Color.parseColor("#8FB5B1"));
        passRow.setBackground(passBg);

        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Password");
        input.setTextColor(Color.parseColor("#172326"));
        input.setHintTextColor(Color.parseColor("#7A8587"));
        input.setTextSize(16);
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setPadding(dp(14), 0, dp(8), 0);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setTransformationMethod(PasswordTransformationMethod.getInstance());

        TextView show = new TextView(this);
        show.setText("SHOW");
        show.setTextColor(Color.parseColor("#4F8F8B"));
        show.setTextSize(12);
        show.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        show.setGravity(Gravity.CENTER);
        show.setPadding(dp(10), 0, dp(10), 0);
        show.setClickable(true);
        show.setFocusable(true);

        final boolean[] visible = {false};
        show.setOnClickListener(v -> {
            int pos = input.getSelectionStart();
            visible[0] = !visible[0];
            if (visible[0]) {
                input.setTransformationMethod(null);
                show.setText("HIDE");
            } else {
                input.setTransformationMethod(PasswordTransformationMethod.getInstance());
                show.setText("SHOW");
            }
            if (pos >= 0) input.setSelection(Math.min(pos, input.length()));
        });

        passRow.addView(input, new LinearLayout.LayoutParams(0, dp(56), 1f));
        passRow.addView(show, new LinearLayout.LayoutParams(dp(66), dp(56)));
        body.addView(passRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

        TextView error = new TextView(this);
        error.setTextColor(Color.parseColor("#8B3D3D"));
        error.setTextSize(12);
        error.setPadding(dp(4), dp(5), dp(4), 0);
        error.setVisibility(View.GONE);
        body.addView(error, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        actions.setPadding(0, dp(6), 0, 0);

        TextView cancel = makePasswordAction("CANCEL", false);
        TextView open = makePasswordAction("OPEN", true);
        LinearLayout.LayoutParams actionLp1 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        actionLp1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams actionLp2 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        actionLp2.setMargins(dp(6), 0, 0, 0);
        actions.addView(cancel, actionLp1);
        actions.addView(open, actionLp2);
        body.addView(actions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(body)
                .create();

        cancel.setOnClickListener(v -> dialog.dismiss());
        open.setOnClickListener(v -> {
            String entered = input.getText().toString();
            if (site.passwordHash.equals(hashPassword(entered))) {
                dialog.dismiss();
                if (onSuccess != null) onSuccess.run();
            } else {
                error.setText("Password गलत है");
                error.setVisibility(View.VISIBLE);
                input.requestFocus();
            }
        });
        input.setOnEditorActionListener((v, actionId, event) -> {
            open.performClick();
            return true;
        });

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
            input.requestFocus();
        });
        trackDialog(dialog);dialog.show();
    }

    private void showSites(View anchor) {

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(4), dp(5), dp(4), dp(5));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(14));
        box.setBackground(bg);

        int popupWidth = Math.max(anchor.getWidth(), dp(180));
        android.widget.ScrollView popupScroll = new android.widget.ScrollView(this);
        popupScroll.setFillViewport(false);
        popupScroll.setVerticalScrollBarEnabled(false);
        popupScroll.addView(box);
        PopupWindow popup = new PopupWindow(popupScroll, popupWidth, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(true);
        popup.setElevation(dp(12));
        popup.setAnimationStyle(android.R.style.Animation_Dialog);

        {
            TextView phoneData = makePopupItem("Incognito");
            phoneData.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            phoneData.setOnClickListener(v -> {
                popup.dismiss();
                finishEditing();
                showPrivateHome();
            });
            box.addView(phoneData, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
        }

        List<Site> entries = new ArrayList<>();
        entries.add(new Site(GOOGLE_NAME,GOOGLE_URL,""));
        entries.addAll(orderedCustomSites());
        for (Site site : entries) {
            final int owner = siteOwner(site);
                TextView item = makePopupItem(site.name + (site.hasPassword() ? "  🔒" : ""));
                boolean selected=selectedSite&&site.url.equals(slot2Url);
                if (selected) {
                    item.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                    item.setBackground(makeRipple(Color.parseColor("#D9E9E3")));
                }
                item.setOnClickListener(v -> {
                    popup.dismiss();
                    finishEditing();
                    selectSite(owner, site);
                });
                box.addView(item, new LinearLayout.LayoutParams(-1, dp(48)));
        }

        fitPopupHeight(popup, box, anchor, popupWidth);
        android.graphics.Rect visibleFrame = new android.graphics.Rect();
        anchor.getWindowVisibleDisplayFrame(visibleFrame);
        int[] anchorPosition = new int[2];
        anchor.getLocationOnScreen(anchorPosition);
        chromePopup=popup;popup.showAsDropDown(anchor, visibleFrame.left - anchorPosition[0], dp(2), Gravity.LEFT);
    }

    private void showOptions(View anchor) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(2), dp(4), dp(2), dp(4));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), Color.parseColor("#D5DDDC"));
        box.setBackground(bg);

        int popupWidth = measureMainMenuWidth("Ad Blocker", "Download", "Manage Websites", "Close Incognito", "Clear Data", "About");
        android.widget.ScrollView popupScroll = new android.widget.ScrollView(this);
        popupScroll.setFillViewport(false);
        popupScroll.setVerticalScrollBarEnabled(false);
        popupScroll.addView(box);
        PopupWindow popup = new PopupWindow(popupScroll, popupWidth, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(true);
        popup.setElevation(dp(14));
        popup.setAnimationStyle(android.R.style.Animation_Dialog);

        LinearLayout navRow = new LinearLayout(this);
        navRow.setOrientation(LinearLayout.HORIZONTAL);
        navRow.setGravity(Gravity.CENTER_VERTICAL);
        navRow.setPadding(0, dp(1), 0, dp(2));

        ImageButton back = makeHistoryButton(R.drawable.ic_back, "Back");
        ImageButton forward = makeHistoryButton(R.drawable.ic_forward, "Forward");

        WebView active = browser;
        boolean d1Home = false;
        boolean canBack = !d1Home && active != null && active.canGoBack();
        boolean canForward = !d1Home && active != null && active.canGoForward();
        setHistoryButtonEnabled(back, canBack);
        setHistoryButtonEnabled(forward, canForward);

        back.setOnClickListener(v -> {
            popup.dismiss();
            WebView current = browser;
            if (current != null && current.canGoBack()) {
                current.goBack();
            }
        });
        forward.setOnClickListener(v -> {
            popup.dismiss();
            WebView current = browser;
            if (current != null && current.canGoForward()) {
                current.goForward();
            }
        });

        LinearLayout.LayoutParams navLp1 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        LinearLayout.LayoutParams navLp2 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        navRow.addView(back, navLp1);
        navRow.addView(forward, navLp2);
        box.addView(navRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));

        addMainMenuAction(box, browserLoading ? "Stop loading" : "Refresh", () -> {
            popup.dismiss();
            if (browser != null && browserLoading) {
                browser.stopLoading();
                setLoading(false);
            } else browser.reload();
        });
        addMainMenuAction(box, "Ad Blocker", () -> { popup.dismiss(); showAdBlockerDialog(); });
        addMainMenuAction(box, "Download", () -> {
            popup.dismiss();
            openDownloadsFolder();
        });
        addMainMenuAction(box, "Manage Websites", () -> {
            popup.dismiss();
            showManageSitesDialog();
        });
        addMainMenuAction(box, "Close Incognito", () -> {popup.dismiss();closeSession();});
        addMainMenuAction(box, "Clear Data", () -> {
            popup.dismiss();
            showClearDataDialog();
        });
        addMainMenuAction(box, "About", () -> {
            popup.dismiss();
            showAboutDialog();
        });

        int xOff = anchor.getWidth() - popupWidth;
        fitPopupHeight(popup, box, anchor, popupWidth);
        chromePopup=popup;popup.showAsDropDown(anchor, xOff, dp(2));
    }

    private void showAboutDialog() {
        android.content.pm.PackageInfo webInfo=WebView.getCurrentWebViewPackage();String health=webInfo==null?"WebView health: available":"WebView: "+webInfo.versionName;
        AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle("STS Fast Browser")
                .setMessage("Version " + currentAppVersion() +
                        "\n\nSimple • Fast • Two Quick Slots" +
                        "\nLong-Life protection: ON" +
                        "\n" + health +
                        "\n\nAd Blocker opens Normal and Hard ON/OFF controls." +
                        "\n\nCreated by Sanchit Kumar" +
                        "\n© 2026 STS Fast Browser. All Rights Reserved.")
                .setPositiveButton("OK", null)
                .create();
        trackDialog(dialog);dialog.show();
    }

    private void openDownloadsFolder() {
        try {
            Intent intent = new Intent(this, DownloadsActivity.class);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Downloads नहीं खुल पाया", Toast.LENGTH_SHORT).show();
        }
    }

    private List<Site> orderedCustomSites(){return new ArrayList<>(privateSites);}
    private int siteOwner(Site site){return 2;}
    private List<Site> getSites(int slot){return privateSites;}
    private void saveSites(int slot){JSONArray list=new JSONArray();for(int i=0;i<privateSites.size();i++){Site site=privateSites.get(i);site.order=i;try{list.put(new JSONObject().put("name",site.name).put("url",site.url).put("passwordHash",site.passwordHash).put("order",i));}catch(Exception ignored){}}privatePrefs.edit().putString("websites",list.toString()).apply();}
    private void loadPrivateSites(){try{JSONArray list=new JSONArray(privatePrefs.getString("websites","[]"));for(int i=0;i<list.length();i++){JSONObject o=list.optJSONObject(i);if(o!=null){Site site=new Site(o.optString("name"),o.optString("url"),o.optString("passwordHash"));site.order=i;privateSites.add(site);}}}catch(Exception ignored){}}
    private void selectSite(int slot,Site site){Runnable open=()->{finishEditing();selectedSite=true;slot2Name=site.name;slot2Url=site.url;updateSlotLabels();address.setText("");browser.loadUrl(site.url);};if(site.hasPassword())showSitePasswordDialog(site,open);else open.run();}
    private void updateSlotLabels(){sitesButton.setText(selectedSite?slot2Name:"Incognito");}
    private void setAdBlockEnabled(boolean enabled,boolean notify){adBlockEnabled=enabled;privatePrefs.edit().putBoolean("adblock",enabled).apply();if(browser!=null)browser.reload();if(notify)Toast.makeText(this,enabled?"Ad Blocker ON":"Ad Blocker OFF",Toast.LENGTH_SHORT).show();}
    private void setHardAdBlockEnabled(boolean enabled,boolean notify){hardAdBlockEnabled=enabled;privatePrefs.edit().putBoolean("hard_adblock",enabled).apply();if(browser!=null)browser.reload();if(notify)Toast.makeText(this,enabled?"Hard Ad Blocker ON":"Hard Ad Blocker OFF",Toast.LENGTH_SHORT).show();}
    private void setLoading(boolean value){browserLoading=value;if(loadingOverlay==null)return;loadingOverlay.animate().cancel();if(value&&!locked&&resumed){loadingOverlay.setVisibility(View.VISIBLE);loadingOverlay.setAlpha(1);startLoadingLogoAnimation();}else{stopLoadingLogoAnimation();loadingOverlay.setVisibility(View.GONE);}}
    private void showClearDataDialog(){AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Clear Data").setItems(new String[]{"Clear Cache / Temporary Data","Clear All Browser Data"},(d,which)->{if(which==0){if(browser!=null)browser.clearCache(true);CookieManager.getInstance().flush();Toast.makeText(this,"Cache cleared • Login saved",Toast.LENGTH_SHORT).show();}else{AlertDialog confirm=new AlertDialog.Builder(this).setTitle("Clear All Browser Data?").setMessage("इससे cache के साथ cookies, login/session और website storage भी हट जाएगा। Websites से logout हो सकते हैं।").setNegativeButton("Cancel",null).setPositiveButton("Clear All",(x,w)->clearPrivateBrowserData()).create();trackDialog(confirm);confirm.show();}}).setNegativeButton("Cancel",null).create();trackDialog(dialog);dialog.show();}
    private void clearPrivateBrowserData(){if(browser!=null){browser.stopLoading();browser.clearCache(true);browser.clearHistory();browser.clearFormData();browser.clearSslPreferences();}WebStorage.getInstance().deleteAllData();WebViewDatabase db=WebViewDatabase.getInstance(this);db.clearFormData();db.clearHttpAuthUsernamePassword();db.clearUsernamePassword();CookieManager.getInstance().removeAllCookies(done->{CookieManager.getInstance().flush();lockedHistory=null;lockedUrl=null;if(!locked&&!closing&&browser!=null)showPrivateHome();});}


private static class Site {
        String name;
        String url;
        String passwordHash;
        int order = Integer.MAX_VALUE;

        Site(String name, String url, String passwordHash) {
            this.name = name;
            this.url = url;
            this.passwordHash = passwordHash == null ? "" : passwordHash;
        }

        boolean hasPassword() {
            return passwordHash != null && !passwordHash.isEmpty();
        }
    }
}
