package com.sts.fastbrowser;

import android.graphics.*;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import java.util.ArrayList;

/** Page-relative marks, independent of raster resolution and zoom. */
final class PdfEditMark {
 final int page, color; final String kind, text, oldText; final float size;
 final ArrayList<float[]> points = new ArrayList<>();
 PdfEditMark(int page,String kind,int color,float size,String text){this(page,kind,color,size,text,"");}
 PdfEditMark(int page,String kind,int color,float size,String text,String oldText){this.page=page;this.kind=kind;this.color=color;this.size=size;this.text=text;this.oldText=oldText;}
 void point(float x,float y){points.add(new float[]{Math.max(0,Math.min(1,x)),Math.max(0,Math.min(1,y))});}
 void draw(Canvas canvas,float width,float height){
  if(points.isEmpty())return;
  Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(color);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
  float[] first=points.get(0);
  if("Replace".equals(kind)&&points.size()>1){
   float[] end=points.get(1);
   Paint cover=new Paint(Paint.ANTI_ALIAS_FLAG);cover.setColor(Color.WHITE);
   canvas.drawRect(first[0]*width,first[1]*height,end[0]*width,end[1]*height,cover);
   TextPaint tp=new TextPaint(Paint.ANTI_ALIAS_FLAG);tp.setColor(color);
   tp.setTypeface(Typeface.DEFAULT);tp.setTextSize(Math.max(8,width*size));
   canvas.drawText(text,first[0]*width,(first[1]*height)+tp.getTextSize(),tp);
   return;
  }
  if("Text".equals(kind)){
   TextPaint tp=new TextPaint(p);tp.setTextSize(width*size);tp.setTypeface(Typeface.DEFAULT);
   int available=Math.max(1,Math.round(width*(1-first[0])));
   StaticLayout layout=StaticLayout.Builder.obtain(text,0,text.length(),tp,available).setAlignment(Layout.Alignment.ALIGN_NORMAL).setIncludePad(false).build();
   canvas.save();canvas.translate(first[0]*width,first[1]*height);layout.draw(canvas);canvas.restore();return;
  }
  p.setStrokeWidth(width*size);p.setStyle(Paint.Style.STROKE);
  if("Highlight".equals(kind)){p.setColor(Color.YELLOW);p.setAlpha(85);}
  Path path=new Path();path.moveTo(first[0]*width,first[1]*height);
  for(int i=1;i<points.size();i++){float[] q=points.get(i);path.lineTo(q[0]*width,q[1]*height);}
  if(points.size()==1){p.setStyle(Paint.Style.FILL);canvas.drawCircle(first[0]*width,first[1]*height,width*size/2,p);}else canvas.drawPath(path,p);
 }
}
