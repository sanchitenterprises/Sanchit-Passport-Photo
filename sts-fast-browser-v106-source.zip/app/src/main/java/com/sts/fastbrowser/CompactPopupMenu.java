package com.sts.fastbrowser;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;

/** Content-sized accessible menu; no device theme minimum width. */
public final class CompactPopupMenu extends PopupMenu {
    private final Context context;
    private final View anchor;
    private OnMenuItemClickListener listener;
    private boolean leftEdge;
    private PopupWindow activeWindow;
    @Override public void dismiss(){if(activeWindow!=null){activeWindow.dismiss();activeWindow=null;}}
    public void setAlignLeftEdge(boolean left) { leftEdge=left; }
    public CompactPopupMenu(Context context, View anchor) { this(context, anchor, Gravity.END); }
    public CompactPopupMenu(Context context, View anchor, int gravity) {
        super(context, anchor, gravity);
        this.context = context;
        this.anchor = anchor;
    }
    @Override public void setOnMenuItemClickListener(OnMenuItemClickListener listener) { this.listener = listener; }
    private int dp(int n) { return Math.round(n * context.getResources().getDisplayMetrics().density); }
    @Override public void show() { showItems(getMenu()); }
    private void showItems(android.view.Menu menu) {
        Rect frame = new Rect();
        anchor.getWindowVisibleDisplayFrame(frame);
        int availableWidth = Math.max(dp(48), frame.width() - dp(8));
        LinearLayout rows = new LinearLayout(context);
        rows.setOrientation(LinearLayout.VERTICAL);
        rows.setPadding(0, dp(4), 0, dp(4));
        android.graphics.drawable.GradientDrawable surface = new android.graphics.drawable.GradientDrawable();
        surface.setColor(Color.rgb(245, 248, 247)); surface.setCornerRadius(dp(12));
        rows.setBackground(surface);
        ScrollView scroll = new ScrollView(context);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.addView(rows);
        dismiss();
        PopupWindow window = new PopupWindow(scroll, 1, 1, true);
        activeWindow=window;
        int width = dp(48);
        for (int i = 0; i < menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            if (!item.isVisible()) continue;
            TextView row = new TextView(context);
            row.setText(item.getTitle() + (item.hasSubMenu() ? "  ›" : ""));
            row.setTextSize(16);
            row.setTextColor(item.isEnabled() ? Color.rgb(23, 35, 38) : Color.GRAY);
            row.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            row.setPadding(dp(16), dp(8), dp(16), dp(8));
            row.setMinHeight(dp(48));
            row.setEnabled(item.isEnabled());
            android.util.TypedValue background = new android.util.TypedValue();
            if (context.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, background, true)) row.setBackgroundResource(background.resourceId);
            row.measure(View.MeasureSpec.makeMeasureSpec(availableWidth, View.MeasureSpec.AT_MOST), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
            width = Math.max(width, row.getMeasuredWidth());
            row.setOnClickListener(v -> { window.dismiss(); if (item.hasSubMenu()) showItems(item.getSubMenu()); else if (listener != null) listener.onMenuItemClick(item); });
            rows.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        rows.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int[] position = new int[2];
        anchor.getLocationOnScreen(position);
        int below = frame.bottom - position[1] - anchor.getHeight();
        int above = position[1] - frame.top;
        window.setWidth(width);
        window.setHeight(Math.min(rows.getMeasuredHeight(), Math.max(dp(48), Math.max(below, above) - dp(8))));
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setOutsideTouchable(true);
        window.setElevation(dp(8));
        if(leftEdge)window.showAsDropDown(anchor, frame.left-position[0], 0, Gravity.LEFT);
        else window.showAsDropDown(anchor, 0, 0, Gravity.END);
    }
}
