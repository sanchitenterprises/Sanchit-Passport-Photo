package com.sts.fastbrowser;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** ZIP preview and safe on-demand entry opening. No extraction outside app cache. */
public final class ZipViewerActivity extends Activity {
    private static final int MAX_ENTRIES = 1500;
    private static final long MAX_SCAN_BYTES = 512L * 1024 * 1024;
    private static final long MAX_SINGLE_FILE = 64L * 1024 * 1024;
    private static final long MAX_ARCHIVE_FILE = 512L * 1024 * 1024;
    private Uri archiveUri;
    private LinearLayout list;
    private TextView status;
    private volatile boolean closed;
    private final List<EntryInfo> entries = new ArrayList<>();

    private static final class EntryInfo {
        final String name;
        final boolean directory;
        final long bytes;
        EntryInfo(String name, boolean directory, long bytes) {
            this.name = name; this.directory = directory; this.bytes = bytes;
        }
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        archiveUri = getIntent().getData();
        String title = getIntent().getStringExtra("archive_name");
        if (TextUtils.isEmpty(title)) title = "ZIP Archive";
        setTitle(title);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(240,245,246));
        LinearLayout header = new LinearLayout(this);
        header.setPadding(dp(12),dp(6),dp(12),dp(6));
        header.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.rgb(217,240,238),Color.rgb(227,234,244)});
        header.setBackground(bg);
        TextView name = text(title, 16, true);
        name.setSingleLine(true);name.setEllipsize(TextUtils.TruncateAt.END);
        header.addView(name,new LinearLayout.LayoutParams(0,dp(36),1));
        root.addView(header);
        status = text("ZIP पढ़ा जा रहा है…",13,false);
        status.setPadding(dp(16),dp(10),dp(16),dp(8));
        root.addView(status);
        ScrollView scroll = new ScrollView(this);scroll.setFillViewport(true);
        list = new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(8),0,dp(8),dp(12));
        scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        if (archiveUri == null) {status.setText("ZIP file उपलब्ध नहीं है");return;}
        new Thread(this::readDirectory,"sts-zip-index").start();
    }

    private void readDirectory() {
        ArrayList<EntryInfo> found = new ArrayList<>();
        String error = null;
        try (InputStream source = getContentResolver().openInputStream(archiveUri)) {
            if (source == null) throw new IOException("Cannot open archive");
            try (ZipInputStream zip = new ZipInputStream(source)) {
                ZipEntry item;
                int count = 0;
                long decodedBytes = 0;
                byte[] buffer = new byte[16 * 1024];
                while ((item = zip.getNextEntry()) != null) {
                    if (++count > MAX_ENTRIES) throw new IOException("बहुत अधिक entries हैं (limit 1500)");
                    if (!safeName(item.getName())) throw new IOException("ZIP में unsafe path मिला");
                    found.add(new EntryInfo(item.getName(),item.isDirectory(),item.getSize()));
                    // Bounded decompression prevents ZIP bombs while building a directory.
                    int read;
                    while ((read=zip.read(buffer)) != -1) {
                        decodedBytes += read;
                        if (decodedBytes > MAX_SCAN_BYTES) throw new IOException("ZIP uncompressed size बहुत बड़ा है");
                    }
                    zip.closeEntry();
                }
            }
        } catch (Exception e) {error=e.getMessage()==null?"ZIP नहीं खुल पाई":e.getMessage();}
        final String failure = error;
        runOnUiThread(() -> {
            if (closed) return;
            if (failure != null) { status.setText("ZIP नहीं खुली: "+failure);return; }
            entries.clear(); entries.addAll(found);
            status.setText(found.size()+" items  •  किसी file को खोलने के लिए tap करें");
            if(found.isEmpty()){list.addView(text("ZIP खाली है",14,false));return;}
            for (EntryInfo entry:found) {
                TextView row=text((entry.directory?"📁  ":"📄  ")+entry.name,14,false);
                row.setMaxLines(2);row.setEllipsize(TextUtils.TruncateAt.END);
                row.setPadding(dp(12),dp(10),dp(8),dp(10));
                if (!entry.directory) {
                    row.setOnClickListener(v->openEntry(entry));
                    android.util.TypedValue selectable = new android.util.TypedValue();
                    getTheme().resolveAttribute(android.R.attr.selectableItemBackground,selectable,true);
                    row.setBackgroundResource(selectable.resourceId);
                } else row.setAlpha(0.7f);
                list.addView(row,new LinearLayout.LayoutParams(-1,-2));
                View separator = new View(this);separator.setBackgroundColor(Color.rgb(221,230,230));
                list.addView(separator,new LinearLayout.LayoutParams(-1,dp(1)));
            }
        });
    }

    private void openEntry(EntryInfo entry) {
        if (entry.bytes > MAX_SINGLE_FILE) {
            status.setText("यह file 64 MB से बड़ी है; सुरक्षित सीमा में नहीं खुलेगी");return;
        }
        status.setText("File खोली जा रही है: "+entry.name);
        new Thread(() -> {
            File extracted = null;
            try {
                File dir = new File(getCacheDir(),"zipview");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cache not available");
                String name = entry.name.substring(entry.name.lastIndexOf('/')+1)
                        .replaceAll("[^A-Za-z0-9._-]","_");
                if (name.isEmpty() || name.equals(".") || name.equals("..")) name="entry.bin";
                extracted = new File(dir,"entry-"+Long.toHexString(System.nanoTime())+"-"+name);
                long total = 0;
                boolean found = false;
                try (InputStream raw=getContentResolver().openInputStream(archiveUri)) {
                    if(raw==null)throw new IOException("Archive unavailable");
                    try(ZipInputStream zip=new ZipInputStream(raw)){
                        ZipEntry ze;
                        int scanned=0;
                        while((ze=zip.getNextEntry())!=null){
                            if(++scanned>MAX_ENTRIES)throw new IOException("Archive entry limit exceeded");
                            if(!safeName(ze.getName()))throw new IOException("Unsafe ZIP path");
                            if(entry.name.equals(ze.getName())&&!ze.isDirectory()){
                                found=true;
                                try(FileOutputStream out=new FileOutputStream(extracted)) {
                                    byte[] buf=new byte[16384];int n;
                                    while((n=zip.read(buf))!=-1){
                                        total+=n;
                                        if(total>MAX_SINGLE_FILE)throw new IOException("File 64 MB limit से बड़ी है");
                                        out.write(buf,0,n);
                                    }
                                    out.getFD().sync();
                                }
                                break;
                            }
                            zip.closeEntry();
                        }
                    }
                }
                if (!found)throw new IOException("Entry नहीं मिली");
                final File ready = extracted;
                runOnUiThread(() -> {
                    if(closed)return;
                    status.setText("ZIP: "+entry.name);
                    Uri fileUri = new Uri.Builder().scheme("content")
                            .authority(getPackageName()+".pdfshare")
                            .appendPath("zipview").appendPath(ready.getName()).build();
                    Intent view = new Intent(this,IntentRouterActivity.class);
                    view.setAction(Intent.ACTION_VIEW);
                    view.setDataAndType(fileUri,getContentResolver().getType(fileUri));
                    view.setClipData(ClipData.newRawUri("ZIP file",fileUri));
                    view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {startActivity(view);}catch(Exception e){
                        Toast.makeText(this,"यह file नहीं खुली",Toast.LENGTH_LONG).show();
                    }
                });
            } catch(Exception e) {
                if(extracted!=null)extracted.delete();
                final String detail=e.getMessage()==null?"Unknown error":e.getMessage();
                runOnUiThread(()->{if(!closed)status.setText("खोलना संभव नहीं: "+detail);});
            }
        },"sts-zip-entry").start();
    }

    private static boolean safeName(String name) {
        if (name==null||name.isEmpty()||name.startsWith("/")||name.startsWith("\\")
                ||name.indexOf('\0')>=0||name.indexOf('\\')>=0) return false;
        for (String part:name.split("/")) if (part.equals("..")||part.equals(".")) return false;
        return true;
    }
    private TextView text(String s,int size,boolean bold) {
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);
        t.setTextColor(Color.rgb(22,35,38));t.setGravity(Gravity.CENTER_VERTICAL);
        if(bold)t.setTypeface(null,android.graphics.Typeface.BOLD);
        return t;
    }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    @Override protected void onDestroy(){closed=true;super.onDestroy();}
}
