package com.sts.fastbrowser;
import android.graphics.Color;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.RippleDrawable;
import android.widget.ImageButton;
final class ViewerStyle {
 static void icon(ImageButton button) {
  button.setColorFilter(Color.parseColor("#263C40"));
  button.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22355C62),new ColorDrawable(Color.TRANSPARENT),null));
 }
}
