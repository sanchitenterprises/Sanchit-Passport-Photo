(function () {
  if (window.__stsVideo) { window.__stsVideo.scan(); return; }
  var lastStatus = "", selected = null, saved = [], fitted = false, fitMode = "pip", timer = null, ui = null;
  function videos() { return Array.prototype.slice.call(document.querySelectorAll('video')); }
  function choose() {
    var list = videos().filter(function (v) { return v.videoWidth > 0; });
    list.sort(function(a,b) { return (b.paused ? 0 : 1) - (a.paused ? 0 : 1) || b.clientWidth*b.clientHeight-a.clientWidth*a.clientHeight; });
    return fitted && selected && selected.isConnected ? selected : list[0] || null;
  }
  var revealUntil=0, hideTimer=null;
  var icons={"play": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAADbklEQVR4nO3cz04TURgF8PO1dKeiYuIr+BomIBtx7VIXPock6sqtT4IGEZ7Dhe8giS51Wo6LuR+9rf030/nbe34JgWppy5z7zZySGQARERERERERERERERERqRFJIzls+3UkieRe9PWozdeSFJIWPj8ieUbyONweaBoaEAVwh7kbkm9945Mc+X2kBlEA+ySvOXVJ8jC6n6ahDlEA90j+DhPwJ4QwDtNw4PfVNFRsQQC+GxpH0/CT5En0PZqGqqwIwD//jYI4m5sGBbGtNQEwuu3/Nj8Nqqzb2DAAF++WLkgehe9VZS2rYADz05CRPKUqa3klAoinYRK+VmUta4sAnB+kVVnLqCAA3/iut5V10PYL2MIQAAFkAA4AnDFUVjObsCeVtc8BAIABGCEPggBOAPwgeWJmDEF0urL2PQBn4WOC6TRckDwys4yqrLMqOgYso8q6Ts0BOFXWZRoKwKmyzms4AN/4rlOVdVcOwut0trKmEgDQ0cqaUgCuU5U1xQCc75YI4BjAOclTAObT0MRBOuUAgNlpGAB4C+AryUMzy8yMdU9D6gG4IfJtkQE4AnDBUFmjg3Qt06AAZo2QT8MQwClmD9K1TIMC+N/Kylr1kymAxRZV1u8kX5J8EJpSJbskBbCaAbhBPg2PAbwB8ATTg/fW9tbfJVkEMEY+CUDekD74QdnMWMWTKIDF/EA8AnAF4KOZXYU2NDCzm6qeSAHM8lU9BHAN4BOAd/7GzMyy6D6VUABTvuoB4DOA12Z2DeS/MQ0bv3IKYPou2Ff9KzP7AtyeAjmuo3661APIMD3I3q56r5h1rfpYqjV0grxejgBcAjg2sxdh4w/9nW8TLyS1CYir5QT5rxvee7UEgDp3N4ukFMCyajkIq77RDe9SCGCTatmaXQ+glWpZxK4G0Gq1LGIXA2i9WhaxSzW0M9Wy81jtiVnxVZV+9pufC5ru2W+rVBhAfMbbJXUB32YqCGD+EtaZM6Db/el6YMsA4lV/exF3eDyt+k2UDGA8t+qfR4+n8/6LKBHAqj9doA1fVIEA4ossvpF8Fj2GdjdlbRCAqmWd1gSgalm3JQFMqGrZjAUBqFo2KQrgLslf0apXtWxCFMA+82t5z0k+9P/Thm8Iyfskn0a3tbtpi1Z9C9iTv2giIiIiIiIiIiIiIiIiPfYPegqJFZSp4IcAAAAASUVORK5CYII=", "pause": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAABeUlEQVR4nO3cTUrDYBRG4feKQZQ6EFfrCnRZ7sKtWGr7OWiKFYT+pH4nynkmpZBwm5ykw5tIkiRJkiRJkiTpV1Xvga21s2ZWVZvjHP1xXd+A8alcnDi3jccvq2o5pzmXcN1jSGutxld7keQtyX2+LviQj2x/53OSl9baUFUrcs4ldQmwp5I8JLk74ZzdDbyd4ZzJegdIklW2F3vsk7lKMiTZzHTOJESAytcNOebG7B8/xzmTXPUeqO8MADMAzAAwA8AMADMAzAAwA8AMADMAzAAwA8AMADMAzAAwA8AMADMAzAAwA8AMADMAzAAwA8AMADMAzAAwA8AMADMAzAAwA8AMADMAzAAwA8AMADMAzAAwA8AMADMAzAAwA8AMADMAzAAwA8AMAKN2xu32uR27yy05b2dcjzmTEFsTH088Zxg/FzOcM1mXAHvrgN+TPCW5OeH0TbZ/la/j9zU9R/8Isbx7OHzUj9ZVdfT/c685kiRJkiRJkiRJmrlPNkFXXO1gM0QAAAAASUVORK5CYII=", "full": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAEN0lEQVR4nO2dS3LbRhCGv6ZeliI5D13I6xwlO2fl5AJJnKocx2vrFF5kl3irqiilcqzQ5J8FZkwYgkTOYOgBkP6qUAAootWDHxgAbHQPOI7jOI7jOI7jOM7/CRtqQNJRCUd6WJnZupSxqfjpfGYGnQGSToDnwEkZdwBYAwvgtZldSVoMPcKm4udOSDJJizD/Svvjl/D/srsOSRbmX+7Rz5dq9sVx/H8pHKZuYGYCFBr2L3ANPA2fDb6mAEvgCLgtYCsi9ufnjZlJ0jLsmySSBAgKn9OcegIugOPgSKmGEewtCtlq29yHn19IegocSvoA3JnZ3a4Gdmpk69Q6B94Af4TpTfgMyjVqKsSu8XvgT+D3MH8Ou3edqV2QAV8DZ4nbzZmTMMUz6zRl4+RrAE3fF68Dxv0jf5lhs2/70ncUSza+DzlbD7jfc4jNNSHJ7xwB2ju9ryFDH3ji9uePfisNAy4L2uuz33cwbiVHgD7iUXUH/BbmFj5P5eP9dVhf5TrVuit5D/zAsOeAg+DLszCtwmeDKCVA5L2Z/VjSYImHm3BX8nMBd5D0jkaANSMUwCRdAn+TfwZExvZb0BFNP1+yaywuAMDSzJaSLOfBZF+Y2aCbA0mEdhW9OSj9sOMk4gJUxgWojAtQGRegMi5AZVyAyrgAlXEBKuMCVMYFqIwLUJnciFg3shSXh0bDpsCazT5okxXJy4kJPxZZumT+wflzNm9YtMmK5O0kQEJk6S58hzH9FF2IGJl7BbxjE7mLFIvkOZ+R5O5iW2RpaOBj7Eha8Hgo0t+WdhzHcRzHcRzHcRzHcRzHuUdW9OqxjPAZBmI+YVs2/NzbPztyAjLdvNiPfwrrSZniU6JVKeCh/Sbgdi9nQYyESXoh6UbSdZjfdNZftL8/B1pFPy4kvQ3t/KvV9rj8VtJFe5tt5LyWckp/0YusTPGJsa1SwCGJvUrOi1lrNpnhak1xfe7x0HY71VlOjofnZkn2ZYZnZYpPkIcqBWS1319NrIwLUBkXoDIuQGVcgMq4AJVxASrjAlTGBaiMC1AZF6AyLkBl9lGybBFiAUfSoLjEmGrGmZrGFI9x7EOA25CmNKpUpUKpU9caeFR1KSlA7M6+lXTGps5mKmMcPyBWgDwBngzxpUtJAWLi2rMwDeUlcBXsZgnQqtz4BPipgE9tisQ+cgToZop3+8U1w3Jkxz5+QF97P5BZKSBHgIcyxSMLht9dTWX8AGj8PA7LyZUCUgRoZ4r/E9ZPaern972mMndi7ejXYTqgyaBPqhSwswDxQmhmVzR9MwCSvqPs4DhTIdaOfmVmv+YaSe6CQqb4IZshTFaUqcsfGfv4AW17AGfxuYdQtjnFSM4gPus4YI2kFfBNqo0tTGX8gOjnWagpnfWskXUbWrguf5exjh/QxaujzAEfS3I4Xh3FcRzHcRzHcRxnSvwHnvGBIDJe1csAAAAASUVORK5CYII=", "pip": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAACpElEQVR4nO3dQXLTMBTG8b9IPQUmLBhOwS04FlwAeixuwSkYFmSAjGkfC9vY3SSRqudXOd9vpossJDv+rFiWLRVERERERERERERkFSm3gJlll7kmKSWL3gfJkHU2j2f/PrfclTCG43JMKR0vLXRzUc1maWxae+Ab8GaxQRn8ZTieX4A7M+tSSv25QhcFsJCAt8Dr/P3bvOmEfJVTKDcAgH7cmFrAYz3QAQ85hUoCSMwHXgHMlsflYi8cdkQylLSAc7beD67a6j0C0M9ShtoBGHBgm60gMXyv2/GviloBTD2iA/Ae+Mm8w1txw9DX/wh8Yu71PLnSmgz4kVL6VbnecNPNqJn9rlmvxzWgG4csttYCOjPrqdxzdOkFjWfKpkYGbWgCZlb3K+k+IJgCCKYAgimAYAogmAIIpgCCKYBgCiCYAgimAIIpgGAKIJgCCKYAgimAYAogmMcTsVV4z1NY62leswFs5XFnkwE4z1Moes+/VFMBrDRPoeg9/1JNBbDgOU+h6D3/Uq0GAH7zFIre8y/VcgBe8xSK3vMvpfuAYAogmAIIpgCCKYBgCiCYAgimAIIpgGAKIJgCCKYAgrU8GNczj4jWHg0FjYaelIB3TnVPk6/3TvU/0lQAi+fAfxhmq1dbMmDhgeGn+ev4+d5hG/81FcBkfFZ7t9K2XH+KmgwAwMyevE7DGffeBx8aDsDzQfmavNaK6ID68/pjdePXedZrRVhK6XvlOp+LHsDMDjUrrR3ASzP7DBzZ3mopO4Ye0Yfxc5WWUCuA6UbolqF7eA12NSrxuAZs4uJ4wo6K1wGXi7BDnZulwbhgCiBY6drRHqOQrSsaRS1ZPd1rFLJ1RaOoFwWw0ihk61YdRZVKSv6Jj7qZp60yiioiIiIiIiIiIiKZ/gGEv6Ixt8SU5gAAAABJRU5ErkJggg=="};
  function visible(e) {
    if(!e || e.hidden)return false;
    var r=e.getBoundingClientRect();if(!r.width||!r.height)return false;
    for(var n=e;n&&n.nodeType===1;n=n.parentElement){var c=getComputedStyle(n);if(c.display==='none'||c.visibility==='hidden'||Number(c.opacity)===0)return false;}
    return true;
  }
  function nativeControls(v){
    if(v.controls)return true;
    var player=v.closest('.html5-video-player,#player,ytm-player,[data-player]')||v.parentElement;
    return player && Array.prototype.some.call(player.querySelectorAll('.ytp-chrome-bottom,.ytp-chrome-top,.player-controls-content,.player-controls,.ytm-player-controls,ytm-player-controls,button[aria-label*="Pause"],button[aria-label*="Play"]'),function(e){return !ui.contains(e)&&visible(e);});
  }
  function report() {
    var v=choose();
    var status=JSON.stringify(v?{ready:true,playing:!v.paused&&!v.ended,width:v.videoWidth,height:v.videoHeight}:{ready:false});
    if(status!==lastStatus)try{STSVideo.status(status);lastStatus=status;}catch(e){}
    if(!ui)return;
    var show=v&&!document.hidden&&!document.fullscreenElement&&(!fitted||fitMode==='full')&&(v.paused||Date.now()<revealUntil)&&!nativeControls(v);
    if(v){var r=v.getBoundingClientRect();ui.style.left=r.left+'px';ui.style.top=r.top+'px';ui.style.width=r.width+'px';ui.style.height=r.height+'px';
      ui.children[0].querySelector('img').src=icons[v.paused?'play':'pause'];
      if(r.width<120||r.height<90||r.bottom<=0||r.top>=innerHeight)show=false;
    }
    ui.style.display=show?'block':'none';
  }
  function reveal(){revealUntil=Date.now()+2200;clearTimeout(hideTimer);report();hideTimer=setTimeout(function(){revealUntil=0;report();},2200);}
  function restore() {
    for (var i=saved.length-1;i>=0;i--) {
      var e=saved[i][0], style=saved[i][1];
      if(style===null)e.removeAttribute('style');else e.setAttribute('style',style);
    }
    saved=[];fitted=false;selected=null;report();
  }
  function remember(e) { if(!saved.some(function(x){return x[0]===e;}))saved.push([e,e.getAttribute('style')]); }
  function fit(mode) {
    fitMode=mode || "pip";
    var v=choose();if(!v)return false;
    if(fitted){report();return true;}
    selected=v;fitted=true;
    remember(document.documentElement);
    document.documentElement.style.setProperty("zoom","1","important");
    document.documentElement.style.setProperty("overflow","hidden","important");
    // Keep the original video in its player: moving/replacing it can restart playback.
    var e=v;
    while(e && e!==document.documentElement) {
      remember(e);
      var parent=e.parentElement;
      if(parent)Array.prototype.forEach.call(parent.children,function(s){
        if(s!==e && s!==ui){remember(s);s.style.setProperty('display','none','important');}
      });
      e.style.setProperty('position','fixed','important');
      e.style.setProperty('inset','0','important');
      e.style.setProperty('width','100%','important');
      e.style.setProperty('height','100%','important');
      e.style.setProperty('margin','0','important');
      e.style.setProperty('padding','0','important');
      e.style.setProperty('min-width','0','important');
      e.style.setProperty('min-height','0','important');
      e.style.setProperty('max-width','none','important');
      e.style.setProperty('max-height','none','important');
      e.style.setProperty('transform','none','important');
      e.style.setProperty('visibility','visible','important');
      e.style.setProperty('display','block','important');
      e.style.setProperty('background','#000','important');
      e=e.parentElement;
    }
    v.style.setProperty('object-fit','contain','important');
    report();return true;
  }
  function action(command) {
    var v=choose();if(!v)return false;
    if(command==='pause')v.pause();
    else if(command==='toggle'){if(v.paused){var p=v.play();if(p&&p.catch)p.catch(function(){});}else v.pause();}
    else if(command==='back') {if(isFinite(v.duration))v.currentTime=Math.max(0,v.currentTime-20);}
    else if(command==='forward') {if(isFinite(v.duration))v.currentTime=Math.min(v.duration,v.currentTime+20);}
    report();return true;
  }
  function scan() {
    if(!ui && document.body) {
      ui=document.createElement('div');
      ui.setAttribute('aria-label','STS video controls');
      ui.style.cssText='position:fixed;z-index:2147483647;display:none;pointer-events:none;overflow:hidden;background:transparent';
      [['play','Play / Pause','toggle'],['full','Full screen','full'],['pip','Picture in picture','pip']].forEach(function(spec){
        if(spec[2]==='pip'&&window.__stsPipAllowed===false)return;
        var b=document.createElement('button');b.setAttribute('aria-label',spec[1]);b.title=spec[1];
        b.style.cssText='position:absolute;width:44px;height:44px;background:rgba(15,31,30,.65);border:0;border-radius:50%;padding:8px;pointer-events:auto;'+(spec[2]==='toggle'?'left:50%;top:50%;transform:translate(-50%,-50%)':'bottom:8px;right:'+(spec[2]==='full'?8:60)+'px');
        var img=document.createElement('img');img.src=icons[spec[0]];img.alt='';img.style.cssText='width:100%;height:100%;pointer-events:none';b.appendChild(img);
        b.onclick=function(e){e.preventDefault();e.stopPropagation();if(spec[2]==='toggle')action('toggle');else try{STSVideo.command(spec[2]);}catch(ignore){}};
        ui.appendChild(b);
      });document.body.appendChild(ui);
    }
    videos().forEach(function(v){if(v.__stsBound)return;v.__stsBound=true;
      ['play','pause','loadedmetadata','ended','emptied'].forEach(function(name){v.addEventListener(name,function(){if(name==='play'){revealUntil=0;clearTimeout(hideTimer);}report();});});
    });report();
  }
  document.addEventListener('pointerup',function(e){var v=choose();if(!v||!ui||ui.contains(e.target))return;var r=v.getBoundingClientRect();if(e.clientX>=r.left&&e.clientX<=r.right&&e.clientY>=r.top&&e.clientY<=r.bottom)setTimeout(reveal,0);},true);
  window.__stsVideo={scan:scan,fit:fit,restore:restore,action:action};
  ['resize','scroll','visibilitychange','fullscreenchange'].forEach(function(name){window.addEventListener(name,report,{passive:true});});
  new MutationObserver(function(records){
    if(timer || fitted || document.hidden || records.every(function(r){return ui && (r.target===ui||ui.contains(r.target));}))return;
    timer=setTimeout(function(){timer=null;scan();},200);
  }).observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:["class","style","hidden"]});
  scan();
})();
