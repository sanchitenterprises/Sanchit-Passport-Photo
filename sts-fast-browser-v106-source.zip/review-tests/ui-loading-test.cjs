const fs = require('fs'), vm = require('vm'), assert = require('assert');
const source = fs.readFileSync(__dirname+'/../app/src/main/java/com/sts/fastbrowser/MainActivity.java','utf8');
const line = source.split('\n').find(s=>s.includes('"function loadAllGradually()'));
const js = JSON.parse(line.trim().replace(/\s*\+$/, ''));
function make(stall=false) {
 let calls=0, tasks=[], sorted=[];
 const c={window:{},loadedCount:0,totalCount:4,pendingSort:null,
 loadMoreNow(){calls++;if(!stall)c.loadedCount++},
 setTimeout(fn){tasks.push(fn);return tasks.length},sortDocs(m){sorted.push(m)}};
 vm.createContext(c);vm.runInContext(js,c);
 return {c,tasks,sorted,calls:()=>calls};
}
let t=make();t.c.loadAllGradually();t.c.loadAllGradually();assert.equal(t.calls(),1,'duplicate schedules blocked');
while(t.tasks.length)t.tasks.shift()();assert.equal(t.calls(),4,'all batches loaded');
t=make(true);t.c.loadAllGradually();assert.equal(t.tasks.length,0,'stalled source stops retry loop');
t=make();t.c.window.__stsUiPaused=true;t.c.loadAllGradually();assert.equal(t.calls(),0,'background work paused');
t.c.window.__stsUiPaused=false;t.c.pendingSort='nameAsc';t.c.loadAllGradually();while(t.tasks.length)t.tasks.shift()();assert.deepEqual(t.sorted,['nameAsc'],'sort resumes after all batches');
console.log('PASS: duplicate, completion, stalled, paused and sort-resume cases');
