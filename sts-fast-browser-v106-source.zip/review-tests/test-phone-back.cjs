const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync(__dirname+'/../app/src/main/java/com/sts/fastbrowser/MainActivity.java','utf8');
const line=src.split('\n').find(l=>l.trim().startsWith('"function stsHandleBack()'));
const js=JSON.parse(line.trim().replace(/\s*\+$/,''));
function make(){const elements={};for(const id of ['sortSub','docMenu','modeMenu','searchBox','q']){const classes=new Set();elements[id]={value:'typed',blur(){this.blurred=true;},classList:{contains:x=>classes.has(x),remove:x=>classes.delete(x),add:x=>classes.add(x)}};}const c={document:{getElementById:id=>elements[id]},window:{__stsLoadTimer:5},selected:new Set(),filterTimer:4,pendingSort:null,cleared:[],filters:0,clearTimeout:n=>c.cleared.push(n),applyFilter:()=>c.filters++,clearSelection:()=>c.selected.clear()};vm.createContext(c);vm.runInContext(js,c);return {c,e:elements};}
let t=make();t.e.docMenu.classList.add('show');assert.equal(t.c.stsHandleBack(),true);assert(!t.e.docMenu.classList.contains('show'));
t=make();t.c.selected.add('file');assert.equal(t.c.stsHandleBack(),true);assert.equal(t.c.selected.size,0);
t=make();t.e.searchBox.classList.add('show');assert.equal(t.c.stsHandleBack(),true);assert.equal(t.e.q.value,'');assert(t.e.q.blurred);assert.equal(t.c.filters,1);assert.equal(t.c.cleared.length,2);
t=make();assert.equal(t.c.stsHandleBack(),false);
console.log('PASS: menu, selection, search cleanup, root exit (production JavaScript)');
