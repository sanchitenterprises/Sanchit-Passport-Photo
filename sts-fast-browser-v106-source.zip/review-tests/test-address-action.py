"""Test actual shared-button production methods with small UI doubles."""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[1];s=(root/'app/src/main/java/com/sts/fastbrowser/MainActivity.java').read_text()
a=s.index('    private boolean shouldShowAddressSearch()');b=s.index('    private void finishAddressEditing()',a);methods=s[a:b]
body='''class ActionTest {
 static class R {static class drawable {static int ic_search=1,ic_refresh=2;}}
 static class Field {boolean focus;String text="";boolean hasFocus(){return focus;}String getText(){return text;}}
 static class Icon {int image;String label;void setImageResource(int i){image=i;}void setContentDescription(String s){label=s;}}
 Field slot2Button=new Field();Icon slot1RefreshIcon=new Icon();boolean addressEdited;int activeSlot=2,refreshed;String submitted;
 void finishAddressEditing(){addressEdited=false;slot2Button.focus=false;updateAddressAction();}
 void refreshSlot(int s){refreshed=s;}
 void navigateD2Address(String s){submitted=s;finishAddressEditing();}
'''+methods+'''
 void check(boolean ok,String label){if(!ok)throw new AssertionError(label);System.out.println("PASS "+label);}
 public static void main(String[]args){
 ActionTest t=new ActionTest();t.updateAddressAction();t.check(t.slot1RefreshIcon.image==2,"default Refresh");
 t.slot2Button.text="https://existing.example";t.slot2Button.focus=true;t.updateAddressAction();t.check(t.slot1RefreshIcon.image==2,"focus without editing stays Refresh");
 t.slot2Button.text="youtube.com";t.addressEdited=true;t.updateAddressAction();t.check(t.slot1RefreshIcon.image==1,"typed URL changes to Search");
 t.performAddressAction();t.check("youtube.com".equals(t.submitted)&&t.refreshed==0,"Search submits address instead of refresh");t.check(t.slot1RefreshIcon.image==2,"submission restores Refresh");
 t.slot2Button.focus=true;t.slot2Button.text="passport photo";t.addressEdited=true;t.performAddressAction();t.check("passport photo".equals(t.submitted),"pasted search phrase submitted");
 t.slot2Button.focus=true;t.addressEdited=true;t.slot2Button.text="   ";t.updateAddressAction();t.check(t.slot1RefreshIcon.image==2,"empty input is Refresh");
 t.activeSlot=1;t.performAddressAction();t.check(t.refreshed==1,"Refresh operates on current Phone Data slot");
 t.addressEdited=true;t.slot2Button.text="background.example";t.slot2Button.focus=false;t.updateAddressAction();t.check(t.slot1RefreshIcon.image==2,"unfocused display is never Search");
 }
}'''
assert 'visibleFrame.left - anchorPosition[0]' in s
assert 'popup.showAsDropDown(anchor, visibleFrame.left - anchorPosition[0], dp(2), Gravity.LEFT)' in s
assert 'root.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)))' in s
bar=s[s.index('    private EditText makeD2AddressBar()'):s.index('    private ImageView makeIconButton')]
assert 'R.drawable.ic_search' not in bar
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'ActionTest.java';p.write_text(body)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(p)],check=True)
 subprocess.run(['java','-cp',d,'ActionTest'],check=True)
print('PASS source layout assertions: physical-left popup, unchanged 54dp, no extra address search icon')
