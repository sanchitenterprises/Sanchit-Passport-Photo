"""Run actual Activity lifecycle/lock methods with controllable Android doubles."""
from pathlib import Path
import subprocess,tempfile
s=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/sts/fastbrowser/PrivateBrowserActivity.java').read_text()
def method(start):
 a=s.index(start);b=s.index('{',a);depth=1;i=b+1
 while depth:
  if s[i]=='{':depth+=1
  if s[i]=='}':depth-=1
  i+=1
 return s[a:i]
methods='\n'.join(method(x) for x in ['    @Override protected void onResume()', '    @Override protected void onPause()', '    @Override protected void onUserLeaveHint()', '    private void lockPrivate()'])
methods=methods.replace('android.app.Dialog','Dialog')
# Credential-result branch is used verbatim from production.
a=s.index('        if(request==UNLOCK_REQUEST)');b=s.index('        if(request==2',a)
result=s[a:b]
java='''import java.util.*;
class Parent {protected void onResume(){}protected void onPause(){}protected void onUserLeaveHint(){}}
class GateTest extends Parent {
 static class Bundle{}
 static class View {static int INVISIBLE=4,VISIBLE=0,GONE=8;int visibility;void setVisibility(int v){visibility=v;}void removeView(Object v){}}
 static class Dialog {boolean dismissed;void dismiss(){dismissed=true;}}
 static class Browser {boolean destroyed,paused,timers;String getUrl(){return "https://example.com/private";}void saveState(Bundle b){}void evaluateJavascript(String j,Object cb){}void onPause(){paused=true;}void pauseTimers(){timers=true;}void stopLoading(){}void destroy(){destroyed=true;}}
 static class Video {boolean exited,destroyed;void exitFullscreen(){exited=true;}void destroy(){destroyed=true;}}
 boolean locked,resumed,credentialFlow,pendingUnlock,suppressPrompt,closing;View root=new View(),shield=new View(),webStage=new View(),loadingOverlay=new View();Video videoController=new Video();Browser browser=new Browser();Dialog activeMenu=new Dialog(),chromePopup=new Dialog();ArrayList<Dialog> privateDialogs=new ArrayList<>();Object picker;String lockedUrl;Bundle lockedHistory;int prompts,unlocks;static int UNLOCK_REQUEST=991,RESULT_OK=-1;
 void stopLoadingLogoAnimation(){}
 void requestUnlock(){prompts++;credentialFlow=true;}void unlockPrivate(){unlocks++;locked=false;pendingUnlock=false;}
 void result(int request,int result){'''+result+'''}
'''+methods+'''
 static void check(boolean b,String name){if(!b)throw new AssertionError(name);System.out.println("PASS "+name);}
 public static void main(String[] args){
 GateTest t=new GateTest();Browser old=t.browser;Video video=t.videoController;Dialog menu=t.activeMenu,dialog=new Dialog();t.privateDialogs.add(dialog);t.onPause();
 check(t.locked&&t.root.visibility==4&&t.shield.visibility==0,"private page covered on pause");check(old.destroyed&&video.destroyed&&t.browser==null,"normal minimize destroys active player");check(menu.dismissed&&dialog.dismissed,"private menus dismissed");check(t.lockedHistory!=null&&t.lockedUrl.endsWith("private"),"return navigation retained");
 t.onResume();check(t.prompts==1&&t.credentialFlow,"return requests phone credentials");t.onPause();t.result(991,0);t.onResume();check(t.locked&&t.prompts==1&&t.unlocks==0,"cancel stays locked without prompt loop");
 t.onPause();t.onResume();check(t.prompts==2,"later foreground can retry");t.onPause();t.result(991,-1);check(t.pendingUnlock&&t.locked,"success while paused does not reveal");t.onResume();check(!t.locked&&t.unlocks==1,"success revealed only on resume");
 t=new GateTest();t.locked=true;t.onPause();check(!t.browser.destroyed,"already locked is idempotent");
 t=new GateTest();t.picker=new Object();old=t.browser;t.onPause();check(t.locked&&old.paused&&old.timers&&!old.destroyed,"file chooser retained behind lock with timers paused");
 }
}'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'GateTest.java';p.write_text(java)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(p)],check=True)
 subprocess.run(['java','-cp',d,'GateTest'],check=True)
