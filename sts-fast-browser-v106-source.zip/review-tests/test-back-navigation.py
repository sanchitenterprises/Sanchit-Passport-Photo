"""Exercise production Back methods against controllable WebView doubles (not device UI)."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/com/sts/fastbrowser/MainActivity.java').read_text()
a=s.index('    @Override\n    public void onBackPressed()');b=s.index('    private void destroyWebView',a)
methods=s[a:b]
body='''import java.util.function.Consumer;
class Parent {public void onBackPressed(){}}
class BackTest extends Parent {
 static class Video {boolean full;boolean exitFullscreen(){boolean was=full;full=false;return was;}} Video videoController=new Video();
 static class WebView {boolean history;int backs;Consumer<String> result;boolean canGoBack(){return history;}void goBack(){backs++;}void evaluateJavascript(String js,Consumer<String> cb){result=cb;}}
 static class Field {boolean focus;boolean hasFocus(){return focus;}}
 Field slot2Button=new Field();WebView webView1=new WebView(),webView2=new WebView(),webView=webView1;
 int activeSlot=1,documentsLoadGeneration=1,backgrounds,homeLoads,focusClears;boolean slot1DocumentsHome=true,phoneBackPending,dead;
 void finishAddressEditing(){slot2Button.focus=false;focusClears++;}
 void showWebView(int slot){activeSlot=slot;webView=slot==1?webView1:webView2;}
 void showDocumentsHome(){homeLoads++;slot1DocumentsHome=true;showWebView(1);}
 boolean moveTaskToBack(boolean b){backgrounds++;return true;}boolean isFinishing(){return dead;}boolean isDestroyed(){return dead;}
'''+methods+'''
 void check(boolean ok,String label){if(!ok)throw new AssertionError(label);System.out.println("PASS "+label);}
 public static void main(String[] args){
  BackTest full=new BackTest();full.videoController.full=true;full.onBackPressed();full.check(!full.videoController.full&&full.webView1.result==null&&full.backgrounds==0,"fullscreen exits before page Back");
  BackTest t=new BackTest();t.webView1.history=true;t.onBackPressed();t.check(t.webView1.backs==0,"home ignores stale loading history");
  Consumer<String> pending=t.webView1.result;t.onBackPressed();t.check(pending==t.webView1.result,"repeated Back coalesced");
  pending.accept("true");t.check(t.backgrounds==0,"closing file menu keeps screen");
  t.onBackPressed();t.webView1.result.accept("false");t.check(t.backgrounds==1&&t.homeLoads==0,"root Back backgrounds without rescan");
  t=new BackTest();t.onBackPressed();t.documentsLoadGeneration++;t.webView1.result.accept("false");t.check(t.backgrounds==0,"stale callback cannot close newer screen");
  t=new BackTest();t.showWebView(2);t.webView2.history=true;t.onBackPressed();t.check(t.webView2.backs==1&&t.backgrounds==0,"website Back uses website history");
  t.webView2.history=false;t.onBackPressed();t.check(t.activeSlot==1&&t.homeLoads==0,"browser root returns existing Phone Data without scan");
  t=new BackTest();t.slot1DocumentsHome=false;t.onBackPressed();t.check(t.homeLoads==1,"saved site root returns Phone Data");
  t=new BackTest();t.slot2Button.focus=true;t.onBackPressed();t.check(t.focusClears==1&&t.backgrounds==0,"address focus dismissed first");
 }
}'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'BackTest.java';p.write_text(body)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(p)],check=True)
 subprocess.run(['java','-cp',d,'BackTest'],check=True)
