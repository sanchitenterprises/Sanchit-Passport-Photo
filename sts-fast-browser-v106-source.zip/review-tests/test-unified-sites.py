from pathlib import Path
import tempfile,subprocess
s=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/sts/fastbrowser/MainActivity.java').read_text()
def section(a,b):return s[s.index(a):s.index(b,s.index(a))]
methods=section('    private List<Site> orderedCustomSites()', '    private void addManageSection')+section('    private void reorderSite(', '    private void confirmDeleteSite(')
site=s[s.index('    private static class Site {'):s.rindex('\n}')]
code='''import java.util.*;
class UnifiedTest {
List<Site> sitesD1=new ArrayList<>(),sitesD2=new ArrayList<>(); int saved,refreshed;
void saveSites(int slot){saved++;} void showManageSitesDialog(){refreshed++;}
'''+methods+site+'''
void check(boolean b){if(!b)throw new AssertionError();}
static Site copy(Site s){Site n=new Site(s.name,s.url,s.passwordHash);n.order=s.order;return n;}
public static void main(String[] args){
UnifiedTest t=new UnifiedTest();
Site google=new Site("Google","google", "");Site a=new Site("A","same","hash1"),b=new Site("B","b",""),c=new Site("C","same","hash2"),d=new Site("D","d","");
t.sitesD1.addAll(Arrays.asList(google,a,b));t.sitesD2.addAll(Arrays.asList(google,c,d));
t.check(t.orderedCustomSites().equals(Arrays.asList(a,b,c,d)));
t.reorderSite(c,2,-1);t.check(t.orderedCustomSites().equals(Arrays.asList(a,c,b,d)));t.check(t.saved==2);
t.reorderSite(a,1,-1);t.reorderSite(d,2,1);t.check(t.saved==2);
UnifiedTest restarted=new UnifiedTest();for(Site x:t.sitesD1)restarted.sitesD1.add(copy(x));for(Site x:t.sitesD2)restarted.sitesD2.add(copy(x));
t.check(restarted.orderedCustomSites().get(1).name.equals("C"));t.check(restarted.orderedCustomSites().get(1).passwordHash.equals("hash2"));
Site e=new Site("E","e","");restarted.sitesD2.add(e);t.check(restarted.orderedCustomSites().get(4)==e);
t.check(t.siteOwner(c)==2);t.check(t.siteOwner(a)==1);
System.out.println("PASS shared order, cross-group move, both boundaries, reload order, duplicate records/password preservation, append, owner retention");
}}
'''
assert 'o.put("order", s.order)' in s and 'o.optInt("order", Integer.MAX_VALUE)' in s
assert 'D1 Websites' not in s and 'D2 Websites' not in s and 'Move to D' not in s
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'UnifiedTest.java';p.write_text(code)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(p)],check=True)
 subprocess.run(['java','-cp',d,'UnifiedTest'],check=True)
