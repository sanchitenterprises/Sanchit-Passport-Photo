import javax.tools.*;
import com.sun.source.util.JavacTask;
import java.nio.file.*;
import java.util.*;

/** Syntax validation only; this does not replace the Android compile/build. */
public class ParseSources {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        try (StandardJavaFileManager files = compiler.getStandardFileManager(diagnostics, null, null)) {
            List<Path> paths;
            try (java.util.stream.Stream<Path> stream = Files.walk(Path.of(args[0]))) {
                paths = stream.filter(p -> p.toString().endsWith(".java")).toList();
            }
            JavacTask task = (JavacTask) compiler.getTask(null, files, diagnostics,
                    List.of("-proc:none"), null, files.getJavaFileObjectsFromPaths(paths));
            task.parse();
            long errors = diagnostics.getDiagnostics().stream()
                    .filter(d -> d.getKind() == Diagnostic.Kind.ERROR).peek(System.err::println).count();
            if (errors != 0) throw new AssertionError(errors + " syntax errors");
            System.out.println("PASS Java syntax: " + paths.size() + " source files; Android type checking NOT performed");
        }
    }
}
