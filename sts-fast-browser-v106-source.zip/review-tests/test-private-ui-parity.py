from pathlib import Path
import re,tempfile,subprocess
root=Path(__file__).resolve().parents[1]/'app/src/main/java/com/sts/fastbrowser';m=(root/'MainActivity.java').read_text();p=(root/'PrivateBrowserActivity.java').read_text()
def method(src,name):
 a=re.search(r'^    (?:private|public|protected).*?\b'+name+r'\s*\(',src,re.M).start();b=src.index('{',a);d=1;i=b+1;q=None
 while d:
  c=src[i]
  if q:
   if c=='\\':i+=2;continue
   if c==q:q=None
  elif c in [chr(34),chr(39)]:q=c
  elif src.startswith('//',i):i=src.index('\n',i);continue
  elif src.startswith('/*',i):i=src.index('*/',i)+2;continue
  elif c=='{':d+=1
  elif c=='}':d-=1
  i+=1
 return src[a:i]
for name in ['makeSlotContainer','makeSlotLabel','makeD2AddressBar','makeIconButton','makeRipple','applyPressAnimation','measureMainMenuWidth','makeHistoryButton','setHistoryButtonEnabled','addMainMenuAction','fitPopupHeight','makePopupItem','makePasswordAction','addManageSection','startLoadingLogoAnimation','stopLoadingLogoAnimation']:
 assert method(m,name)==method(p,name),name
print('PASS 16 main/private presentation methods identical')
assert method(m,'showManagedSiteMenu')==method(p,'showManagedSiteMenu').replace('activeMenu=pm;pm.show();','pm.show();')
for name in ['showSitePasswordDialog','showSetSitePasswordDialog']:assert method(m,name)==method(p,name).replace('trackDialog(dialog);dialog.show();','dialog.show();')
print('PASS website options, move boundaries and password dialogs match')
for label in ['Ad Blocker','Download','Manage Websites','Clear Data','About']:assert '"'+label+'"' in method(p,'showOptions')
for source, menu, dropdown in [(m,'showMainMenu','showSitePopup'),(p,'showOptions','showSites')]:
 assert '"Add Website"' not in method(source,menu)
 assert 'Add website' not in method(source,dropdown)
 assert '.setNeutralButton("Add Website"' in method(source,'showManageSitesDialog')
 assert method(source,menu).count('addMainMenuAction(box, "Ad Blocker"')==1
assert method(m,'showAdBlockerDialog').replace('        \n','')==method(p,'showAdBlockerDialog').replace('        trackDialog(dialog);\n','')
print('PASS Add Website only inside Manage; one Ad Blocker opens identical Normal/Hard controls')
assert all(x not in p for x in ['sts_fast_browser_prefs','sites_d1_json','sites_d2_json'])
assert 'getSharedPreferences("sts_incognito_sites",MODE_PRIVATE)' in p
print('PASS private storage remains separate and browser menu functions present')
reorder=method(p,'reorderSite');ordered=method(p,'orderedCustomSites');site=p[p.index('private static class Site {'):p.rfind('}')]
java='''import java.util.*;
class OrderTest {
 ArrayList<Site> privateSites=new ArrayList<>();int saves,refreshes;List<String> disk=new ArrayList<>();
 void saveSites(int slot){if(slot!=2)throw new AssertionError("wrong storage");saves++;disk.clear();for(Site s:privateSites)disk.add(s.name);}
 void showManageSitesDialog(){refreshes++;}
'''+ordered+reorder+site+'''
 public static void main(String[] args){OrderTest t=new OrderTest();Site a=new Site("A","https://a.test","hash"),b=new Site("B","https://b.test","");t.privateSites.add(a);t.privateSites.add(b);t.reorderSite(a,2,-1);if(t.saves!=0)throw new AssertionError("top boundary");t.reorderSite(a,2,1);if(t.privateSites.get(1)!=a||!t.disk.equals(Arrays.asList("B","A"))||!a.passwordHash.equals("hash"))throw new AssertionError("persistence");t.reorderSite(a,2,1);if(t.saves!=1)throw new AssertionError("bottom boundary");t.reorderSite(a,2,-1);if(t.privateSites.get(0)!=a||t.refreshes!=2)throw new AssertionError("move up");System.out.println("PASS actual private order method: save, password retention and boundaries");}
}'''
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'OrderTest.java';f.write_text(java);subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(f)],check=True);subprocess.run(['java','-cp',d,'OrderTest'],check=True)
