from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/sts/fastbrowser/PdfEditGeometry.java'
java='''package com.sts.fastbrowser;
public class PdfGeometryTest {
 static void check(float actual,float expected){if(Math.abs(actual-expected)>.001)throw new AssertionError(actual+" != "+expected);}
 public static void main(String[] args){
  // Each expected point is the displayed top-left in PDF coordinates with a non-zero crop origin.
  float[][] expected={{11,813},{11,13},{611,13},{611,813}};int[] rotations={0,90,180,270};
  for(int i=0;i<4;i++){float[] m=PdfEditGeometry.matrix(rotations[i],600,800,11,13);check(m[2]+m[4],expected[i][0]);check(m[3]+m[5],expected[i][1]);
   float determinant=m[0]*m[3]-m[1]*m[2];check(determinant,480000);System.out.println("PASS rotation "+rotations[i]+" crop origin and area");}
  float[] point=PdfEditGeometry.point(350,500,-50,-100,2,400,600);check(point[0],.5f);check(point[1],.5f);System.out.println("PASS zoom/pan edit coordinates");
 }
}'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'PdfGeometryTest.java';p.write_text(java);subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(src),str(p)],check=True);subprocess.run(['java','-cp',d,'com.sts.fastbrowser.PdfGeometryTest'],check=True)
s=(src.parent/'PdfViewerActivity.java').read_text();section=s[s.index('    private void buildPdfEditor'):s.index('    @Override\n    protected void onCreate')]
assert 'AlertDialog' not in section and 'startActivity' not in section
assert 'SafeMediaExport.write' in section and 'PdfEditGeometry.matrix' in section and 'pdfUndo' in section
print('PASS editor controls, text input and Save As stay inline; transactional copy export path present')
