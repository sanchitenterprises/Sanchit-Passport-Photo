"""Exercise production editor history and encoder methods with deterministic JVM doubles."""
from pathlib import Path
import subprocess,tempfile,re
s=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/sts/fastbrowser/ImageViewerActivity.java').read_text()
def method(name):
 m=re.search(r'    private [^\n]+\b'+name+r'\([^\n]*\)(?: throws Exception)?\s*\{',s);a=m.start();j=s.index('{',a)+1;d=1
 while d:
  if s[j]=='{':d+=1
  elif s[j]=='}':d-=1
  j+=1
 return s[a:j]
java='''import java.io.*;import java.util.*;
class PhotoTest {
 interface ImageEdit { Bitmap apply(Bitmap source) throws Exception; }
 static class Bitmap {
  final int id; int quality=-1; Bitmap(int id){this.id=id;}
  enum CompressFormat {PNG,JPEG}
  boolean compress(CompressFormat f,int q,OutputStream out)throws IOException{quality=q;out.write(new byte[q]);return true;}
  int getWidth(){return 100;}int getHeight(){return 80;}
  static Bitmap createScaledBitmap(Bitmap s,int w,int h,boolean f){return s;}
  void recycle(){}
 }
 static HashMap<String,Bitmap> disk=new HashMap<>();
 static class BitmapFactory{static Bitmap decodeFile(String p){return disk.get(p);}}
 static class Worker{void execute(Runnable r){r.run();}}
 static class ImageCanvas {void setCropMode(boolean b){}}
 static class Toast {static final int LENGTH_LONG=1,LENGTH_SHORT=0;static Toast makeText(Object c,String t,int l){return new Toast();}void show(){}}
 boolean editorBusy,cropMode,edited,destroyed;int historyIndex=-1;Bitmap bitmap=new Bitmap(1);
 final int TOP_MODE_SCAN=2;final ArrayList<File> editHistory=new ArrayList<>();Worker imageWorker=new Worker();ImageCanvas imageCanvas=new ImageCanvas();
 void setEditorBusy(boolean b,String t){editorBusy=b;}void runOnUiThread(Runnable r){r.run();}boolean isDestroyed(){return destroyed;}boolean isFinishing(){return false;}
 void setBitmap(Bitmap b){bitmap=b;}void buildMainEditBar(){}void showActionTopHeader(int mode){}
 File snapshot(Bitmap image)throws Exception{File f=File.createTempFile("history", ".png");disk.put(f.getAbsolutePath(),image);return f;}
'''+''.join(method(n) for n in ['runEdit','undoEdit','redoEdit','restoreEdit','encodeForSave'])+'''
 static void check(boolean v,String label){if(!v)throw new AssertionError(label);System.out.println("PASS "+label);}
 public static void main(String[] args)throws Exception{
  PhotoTest t=new PhotoTest();t.runEdit("edit",b->new Bitmap(2));check(t.bitmap.id==2&&t.historyIndex==1&&!t.editorBusy,"edit commits result and history");
  t.undoEdit();check(t.bitmap.id==1,"undo restores original");t.redoEdit();check(t.bitmap.id==2,"redo restores edit");
  t.undoEdit();t.runEdit("branch",b->new Bitmap(3));t.redoEdit();check(t.bitmap.id==3&&t.editHistory.size()==2,"new edit removes old redo branch");
  t.runEdit("fail",b->{throw new IOException();});check(t.bitmap.id==3&&t.historyIndex==1&&!t.editorBusy,"failure leaves image and history intact");
  t.editorBusy=true;t.runEdit("busy",b->new Bitmap(99));t.undoEdit();check(t.bitmap.id==3,"busy prevents overlapping edits");t.editorBusy=false;
  for(int i=4;i<15;i++){final int id=i;t.runEdit("many",b->new Bitmap(id));}check(t.editHistory.size()==8&&t.historyIndex==7,"history bounded to eight lossless disk states");
  Bitmap image=new Bitmap(9);t.encodeForSave(image,false,0);check(image.quality==95,"default JPEG quality 95");
  t.encodeForSave(image,true,0);check(image.quality==100,"PNG export lossless");
  t.destroyed=true;t.runEdit("late",b->new Bitmap(100));check(t.bitmap.id==14,"late worker result cannot mutate destroyed viewer");
  for(File f:t.editHistory)f.delete();
 }
}'''
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'PhotoTest.java';f.write_text(java);subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(f)],check=True);subprocess.run(['java','-cp',d,'PhotoTest'],check=True)
assert 'captureCrop()' in s and 'Keep proportions' in s
assert all(x in s for x in ['ORIENTATION_FLIP_HORIZONTAL','ORIENTATION_FLIP_VERTICAL','ORIENTATION_TRANSPOSE','ORIENTATION_TRANSVERSE'])
print('PASS crop capture, aspect lock and mirrored EXIF paths present (device rendering still to verify)')
