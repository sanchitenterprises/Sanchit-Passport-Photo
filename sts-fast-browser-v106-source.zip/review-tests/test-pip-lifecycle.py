from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]/'app/src/main/java/com/sts/fastbrowser';s=(root/'BrowserVideoController.java').read_text();main=(root/'MainActivity.java').read_text();private=(root/'PrivateBrowserActivity.java').read_text()
assert 'videoController.stopped()' not in main and 'public void stopped()' not in s
assert 'videoController.setPipAllowed(false)' in private and 'enterPip(' not in private and 'perform("pause")' not in s
assert 'setAutoEnterEnabled(pipAllowed && playing)' in s
print('PASS no normal lifecycle pause; auto-enter follows playback; private PiP disabled')
a=s.index('    public void enterPip(');b=s.index('    private void restorePage()',a)
java='''import java.util.function.*;
class PipTest {
 static class Build {static class VERSION {static int SDK_INT=35;}}
 static class View {static final int GONE=8,VISIBLE=0;int visibility;void setVisibility(int v){visibility=v;}}
 static class WebView {String result="true";int evaluations;void evaluateJavascript(String js,Consumer<String> cb){evaluations++;if(cb!=null)cb.accept(result);}void post(Runnable r){r.run();}}
 static class Activity {boolean pip,accept=true;int enters;boolean enterPictureInPictureMode(Object params){enters++;pip=accept;return accept;}}
 Activity activity=new Activity();WebView view=new WebView(),fittedView;Supplier<WebView> current=()->view;View toolbar=new View(),customView;
 boolean pipAllowed=true,destroyed,entering,playing=true,fallbackFull;int restored;
 boolean inPip(){return activity.pip;}boolean isFullscreen(){return customView!=null||fallbackFull;}Object params(){return new Object();}void install(WebView v){}void toast(String t){}void restorePage(){restored++;fittedView=null;toolbar.visibility=View.VISIBLE;}
'''+s[a:b]+'''
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);System.out.println("PASS "+s);}
 public static void main(String[] args){
  PipTest t=new PipTest();t.enterPip(true);check(t.activity.enters==0,"Android 12+ uses previously armed auto-enter");
  t.pipChanged(true);check(t.fittedView==t.view&&t.toolbar.visibility==View.GONE,"system PiP callback fits actual video");
  t.pipChanged(false);check(t.restored==1&&t.toolbar.visibility==View.VISIBLE,"expand restores page");
  Build.VERSION.SDK_INT=30;t=new PipTest();t.enterPip(true);check(t.activity.enters==1&&t.view.evaluations==0,"older Android requests PiP synchronously without waiting for JS");
  t.pipChanged(true);check(t.fittedView==t.view,"older Android callback fits video");
  t.enterPip(true);check(t.activity.enters==1,"repeated leave guard");
  t=new PipTest();t.playing=false;t.enterPip(true);check(t.activity.enters==0,"paused video no automatic PiP");
  t.enterPip(false);check(t.activity.enters==1,"explicit PiP preserved");
  t=new PipTest();t.pipAllowed=false;t.enterPip(true);t.enterPip(false);t.preparePipContent();check(t.activity.enters==0&&t.view.evaluations==0,"private PiP blocked");
  t=new PipTest();t.activity.accept=false;t.enterPip(false);check(t.restored==1,"manual failure restores layout");
  t=new PipTest();t.view.result="false";t.enterPip(false);check(t.activity.enters==0,"explicit missing-video guard");
  t=new PipTest();t.customView=new View();t.enterPip(true);t.pipChanged(true);check(t.activity.enters==1&&t.view.evaluations==0,"native fullscreen host retained");
 }
}'''
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'PipTest.java';f.write_text(java);subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(f)],check=True);subprocess.run(['java','-cp',d,'PipTest'],check=True)
