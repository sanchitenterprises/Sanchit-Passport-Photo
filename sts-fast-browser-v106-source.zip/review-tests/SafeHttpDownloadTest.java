package com.sts.fastbrowser;

import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicReference;

public class SafeHttpDownloadTest {
    private static int passed;
    private static void check(boolean condition, String name) {
        if (!condition) throw new AssertionError(name);
        passed++;
        System.out.println("PASS " + name);
    }
    public static void main(String[] args) throws Exception {
        HttpServer first = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        HttpServer second = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        String base = "http://127.0.0.1:" + first.getAddress().getPort();
        String other = "http://127.0.0.1:" + second.getAddress().getPort();
        AtomicReference<String> receivedCookie = new AtomicReference<>();
        AtomicReference<String> receivedReferer = new AtomicReference<>();
        byte[] payload = "original-file-bytes".getBytes(StandardCharsets.UTF_8);
        com.sun.net.httpserver.HttpHandler file = exchange -> {
            receivedCookie.set(exchange.getRequestHeaders().getFirst("Cookie"));
            receivedReferer.set(exchange.getRequestHeaders().getFirst("Referer"));
            exchange.getResponseHeaders().add("Content-Type", "application/pdf");
            exchange.sendResponseHeaders(200, payload.length);
            try (java.io.OutputStream out = exchange.getResponseBody()) { out.write(payload); }
        };
        first.createContext("/file", file);
        second.createContext("/file", file);
        first.createContext("/same", e -> {
            e.getResponseHeaders().add("Location", "/file"); e.sendResponseHeaders(302, -1); e.close();
        });
        first.createContext("/cross", e -> {
            e.getResponseHeaders().add("Location", other + "/file"); e.sendResponseHeaders(302, -1); e.close();
        });
        first.createContext("/loop", e -> {
            e.getResponseHeaders().add("Location", "/loop"); e.sendResponseHeaders(302, -1); e.close();
        });
        first.createContext("/missing", e -> { e.sendResponseHeaders(404, -1); e.close(); });
        first.createContext("/short", e -> {
            e.sendResponseHeaders(200, 100);
            e.getResponseBody().write(1);
            try { e.getResponseBody().close(); } catch (IOException ignored) {}
            e.close();
        });
        first.start(); second.start();
        Path dir = Files.createTempDirectory("sts-http-test-");
        Path target = dir.resolve("download.tmp");
        try {
            SafeHttpDownload.Result result = SafeHttpDownload.download(base + "/same", target.toFile(),
                    "STS-test", "session=secret", base + "/page", null);
            check(java.util.Arrays.equals(payload, Files.readAllBytes(target)), "exact bytes preserved");
            check("session=secret".equals(receivedCookie.get()), "same-origin login preserved");
            check(result.url.equals(base + "/file"), "relative redirect resolved");
            SafeHttpDownload.download(base + "/cross", target.toFile(), "STS-test", "session=secret", base + "/page", null);
            check(receivedCookie.get() == null, "original cookie not sent across origins");
            check(receivedReferer.get() == null, "cross-origin referrer omitted");
            SafeHttpDownload.download(base + "/cross", target.toFile(), "STS-test", "session=secret", null,
                    url -> url.startsWith(other + "/") ? "target=allowed" : null);
            check("target=allowed".equals(receivedCookie.get()), "target-specific cookie used");
            for (String endpoint : new String[]{"/missing", "/loop", "/short"}) {
                boolean failed = false;
                try { SafeHttpDownload.download(base + endpoint, target.toFile(), null, null, null, null); }
                catch (IOException expected) { failed = true; }
                check(failed && !Files.exists(target), "failure cleanup " + endpoint);
            }
            Files.write(target, payload);
            try { SafeHttpDownload.download("invalid-url", target.toFile(), null, null, null, null); }
            catch (IOException expected) { }
            check(!Files.exists(target), "malformed URL cleanup");
            check(!SafeHttpDownload.sameOrigin(new URL("https://example.com/"), new URL("http://example.com/")), "scheme separation");
            check(SafeHttpDownload.sameOrigin(new URL("https://example.com/"), new URL("https://example.com:443/path")), "default port normalization");
            System.out.println("TOTAL: " + passed + " passed");
        } finally {
            first.stop(0); second.stop(0);
            Files.deleteIfExists(target); Files.deleteIfExists(dir);
        }
    }
}
