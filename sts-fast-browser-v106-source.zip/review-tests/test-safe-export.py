"""Run the real SafeMediaExport with fault-injecting Android resolver stubs."""
from pathlib import Path
import tempfile, subprocess
root=Path(__file__).resolve().parents[1]
files={
'android/annotation/TargetApi.java':'package android.annotation; public @interface TargetApi { int value(); }',
'android/net/Uri.java':'package android.net; public class Uri {}',
'android/provider/MediaStore.java':'package android.provider; public class MediaStore {public static class MediaColumns {public static final String IS_PENDING="pending";}}',
'android/content/ContentValues.java':'package android.content; public class ContentValues extends java.util.HashMap<String,Integer> {}',
'android/content/Context.java':'package android.content; public abstract class Context { public abstract ContentResolver getContentResolver(); }',
'android/content/ContentResolver.java':'''package android.content; import android.net.Uri; import java.io.*;
public abstract class ContentResolver {public abstract Uri insert(Uri c,ContentValues v); public abstract OutputStream openOutputStream(Uri u,String m)throws IOException; public abstract int update(Uri u,ContentValues v,String a,String[] b); public abstract int delete(Uri u,String a,String[] b);}''',
'com/sts/fastbrowser/ExportTest.java':'''package com.sts.fastbrowser;
import android.content.*; import android.net.Uri; import java.io.*;
public class ExportTest {
 static class Resolver extends ContentResolver {
  String mode; boolean closed,published,deleted; ByteArrayOutputStream bytes=new ByteArrayOutputStream();
  Resolver(String m){mode=m;}
  public Uri insert(Uri u,ContentValues v){if(v.get("pending")!=1)throw new AssertionError();return mode.equals("insert")?null:new Uri();}
  public OutputStream openOutputStream(Uri u,String m){if(mode.equals("null"))return null;return new FilterOutputStream(bytes){public void close()throws IOException{closed=true;if(mode.equals("close"))throw new IOException();super.close();}};}
  public int update(Uri u,ContentValues v,String a,String[] b){if(!closed)throw new AssertionError("published before close");if(mode.equals("publish"))return 0;published=true;return 1;}
  public int delete(Uri u,String a,String[] b){deleted=true;return 1;}
 }
 public static void main(String[] args)throws Exception {
  for(String mode:new String[]{"ok","writer","close","null","publish","insert"}){
   Resolver r=new Resolver(mode);Context c=new Context(){public ContentResolver getContentResolver(){return r;}};
   boolean failed=false;try{SafeMediaExport.write(c,new Uri(),new ContentValues(),out->{out.write(new byte[]{1,2,3});if(mode.equals("writer"))throw new IOException();});}catch(Exception e){failed=true;}
   if(mode.equals("ok")){if(failed||!r.published||r.deleted||r.bytes.size()!=3)throw new AssertionError(mode);}
   else if(!failed||r.published||(!mode.equals("insert")&&!r.deleted))throw new AssertionError(mode);
   System.out.println("PASS export "+mode);
  }
 }
}'''}
with tempfile.TemporaryDirectory() as directory:
 d=Path(directory)
 for name,body in files.items():
  p=d/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(body)
 java=list(map(str,d.rglob('*.java')))+[str(root/'app/src/main/java/com/sts/fastbrowser/SafeMediaExport.java')]
 subprocess.run(['java','com.sun.tools.javac.Main','-d',str(d),*java],check=True)
 subprocess.run(['java','-cp',str(d),'com.sts.fastbrowser.ExportTest'],check=True)
