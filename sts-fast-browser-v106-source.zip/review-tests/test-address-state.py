"""Exercise extracted production address methods with minimal UI/network test doubles."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/com/sts/fastbrowser/MainActivity.java').read_text()
def method(start,end):return s[s.index(start):s.index(end,s.index(start))]
methods=method('    private void updateSlotLabels()', '    private boolean shouldShowAddressSearch()')+method('    private void syncD2AddressBar(', '    private List<Site> getSites(')
assert s.count('makeIconButton(R.drawable.ic_home)')==1
assert s.count('makeIconButton(R.drawable.ic_refresh)')==1
assert 'root.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)))' in s
body='''class AddressTest {
static class TextUtils {static boolean isEmpty(String s){return s==null||s.isEmpty();}}
static class Uri {static String encode(String s){return s.replace(" ","%20");}}
static class Field {String text="";boolean focus;boolean hasFocus(){return focus;}void setText(String s){text=s;}void setSelection(int i){}void setContentDescription(String s){}}
Field slot1Button=new Field(),slot2Button=new Field();Object webView2=new Object();int activeSlot=2;boolean manualD2Address,slot1DocumentsHome=true;String manualAddressShown="",slot1Name="One",slot2Name="Saved",loaded="";
void finishAddressEditing(){slot2Button.focus=false;syncD2AddressBar(null);}
void showWebView(int slot){activeSlot=slot;updateSlotLabels();}
void loadBrowserUrl(Object view,String url){loaded=url;syncD2AddressBar(url);}
String normalizeUrl(String s){return s.contains("://")?s:"https://"+s;}
'''+methods+'''
void check(boolean ok){if(!ok)throw new AssertionError();}
public static void main(String[]args){AddressTest t=new AddressTest();
t.syncD2AddressBar("https://saved.example/login");t.check(t.slot2Button.text.isEmpty());
t.navigateD2Address("typed.example/path");t.check(t.slot2Button.text.equals("https://typed.example/path"));t.check(t.slot1Button.text.equals("Websites"));
t.syncD2AddressBar("https://typed.example/redirect");t.check(t.slot2Button.text.endsWith("/redirect"));
t.activeSlot=1;t.updateSlotLabels();t.syncD2AddressBar("https://background.example");t.check(t.slot2Button.text.isEmpty());
t.activeSlot=2;t.manualD2Address=false;t.updateSlotLabels();t.check(t.slot2Button.text.isEmpty());t.check(t.slot1Button.text.equals("Saved"));
t.slot2Button.focus=true;t.slot2Button.text="unfinished input";t.syncD2AddressBar("https://saved.example");t.check(t.slot2Button.text.equals("unfinished input"));
System.out.println("PASS saved URL hidden, manual address, redirect, inactive page, saved reselection, focused draft; one Home/Refresh and unchanged 54dp toolbar");
}}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'AddressTest.java';p.write_text(body)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(p)],check=True)
 subprocess.run(['java','-cp',d,'AddressTest'],check=True)
