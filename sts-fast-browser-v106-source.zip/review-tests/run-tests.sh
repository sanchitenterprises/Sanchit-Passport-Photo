#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
test_classes="$(mktemp -d)"
trap 'rm -rf "$test_classes"' EXIT
java com.sun.tools.javac.Main -d "$test_classes" \
  app/src/main/java/com/sts/fastbrowser/SafeHttpDownload.java \
  review-tests/SafeHttpDownloadTest.java review-tests/ParseSources.java
java -cp "$test_classes" com.sts.fastbrowser.SafeHttpDownloadTest
java -cp "$test_classes" ParseSources app/src/main/java
