const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(require('path').join(__dirname,'../app/src/main/assets/browser-video.js'),'utf8');
function run(pip=true){
 let now=1000,timers=[],native=false;
 class Element{
 constructor(parent=null,style=null){this.nodeType=1;this.parentElement=parent;this.children=[];if(parent)parent.children.push(this);this.attrs={};if(style!==null)this.attrs.style=style;this.isConnected=true;this.style={setProperty:(k,v)=>{this.attrs.style=(this.attrs.style||'')+k+':'+v+';';}};this.videoWidth=1920;this.videoHeight=1080;this.clientWidth=600;this.clientHeight=340;this.paused=true;this.ended=false;this.currentTime=50;this.duration=100;this.listeners={};this.rect={left:20,top:100,bottom:440,right:620,width:600,height:340};}
 getAttribute(n){return this.attrs[n]??null;}setAttribute(n,v){this.attrs[n]=v;}removeAttribute(n){delete this.attrs[n];}
 appendChild(e){e.parentElement=this;this.children.push(e);}contains(e){return this===e||this.children.some(c=>c.contains(e));}querySelector(){return this.children[0];}querySelectorAll(){return native?[control]:[];}closest(){return player;}
 addEventListener(n,f){this.listeners[n]=f;}getBoundingClientRect(){return this.rect;}
 play(){this.paused=false;this.listeners.play?.();return Promise.resolve();}pause(){this.paused=true;this.listeners.pause?.();}
 }
 const html=new Element(),body=new Element(html,'background:white'),header=new Element(body,'display:flex'),player=new Element(body,'width:600px'),video=new Element(player,'position:absolute'),control=new Element(player),second=new Element(body);video.paused=false;second.clientWidth=100;
 const originals=[html,body,header,player,video,control,second].map(x=>x.getAttribute('style'));let videos=[second,video],status=[],commands=[],events={};
 const context={Date:{now:()=>now},document:{body,createElement:()=>new Element(),documentElement:html,querySelectorAll:()=>videos,hidden:false,addEventListener:(n,f)=>events[n]=f},window:{__stsPipAllowed:pip,innerWidth:640,addEventListener:(n,f)=>events[n]=f},getComputedStyle:()=>({display:'block',visibility:'visible',opacity:'1'}),MutationObserver:class{observe(){}},STSVideo:{status:x=>status.push(JSON.parse(x)),command:x=>commands.push(x)},setTimeout:(f,ms)=>{let t={f,at:now+ms};timers.push(t);return t;},clearTimeout:t=>{timers=timers.filter(x=>x!==t);},innerHeight:800};
 function tick(ms){now+=ms;let due=timers.filter(t=>t.at<=now);timers=timers.filter(t=>t.at>now);due.forEach(t=>t.f());}
 vm.createContext(context);vm.runInContext(source,context);const api=context.window.__stsVideo,overlay=body.children.at(-1);
 assert.equal(overlay.children.length,pip?3:2);assert.equal(overlay.style.display,'none','playing starts hidden');
 overlay.children.forEach(b=>assert(b.children[0].src.startsWith('data:image/png;base64,')));
 events.pointerup({target:video,clientX:100,clientY:150});tick(0);assert.equal(overlay.style.display,'block');assert.equal(overlay.style.left,'20px');assert.equal(overlay.style.top,'100px');assert.equal(overlay.style.width,'600px');tick(2200);assert.equal(overlay.style.display,'none');
 video.pause();assert.equal(overlay.style.display,'block');video.play();assert.equal(overlay.style.display,'none','play hides immediately');
 native=true;video.pause();assert.equal(overlay.style.display,'none','native controls win');native=false;video.controls=true;api.scan();assert.equal(overlay.style.display,'none');video.controls=false;video.play();
 overlay.children[1].onclick({preventDefault(){},stopPropagation(){}});assert.deepEqual(commands,['full']);
 assert(api.fit('pip'));assert.equal(overlay.style.display,'none');assert(video.attrs.style.includes('object-fit:contain'));assert(header.attrs.style.includes('display:none'));assert.equal(video.parentElement,player);assert.equal(video.currentTime,50);assert.equal(video.paused,false);
 api.fit('full');assert.equal(overlay.style.display,'none');api.restore();assert.deepEqual([html,body,header,player,video,control,second].map(x=>x.getAttribute('style')),originals);
 api.action('toggle');assert(video.paused);video.paused=false;api.action('forward');assert.equal(video.currentTime,70);api.action('back');assert.equal(video.currentTime,50);video.duration=Infinity;api.action('forward');assert.equal(video.currentTime,50);api.action('pause');assert(video.paused);
 videos=[];assert.equal(api.fit(),false);assert.equal(api.action('toggle'),false);api.scan();assert.equal(status.at(-1).ready,false);
}
run(true);run(false);console.log('PASS production video JS: PNG, video bounds, tap timeout, play-hide, native precedence, private PiP omitted, fit/restore and playback actions.');
