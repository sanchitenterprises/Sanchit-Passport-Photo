STS Fast Browser v1.0.113 (versionCode 114)

FIX: PDF Native Text Replace and Delete target the text at the exact page position tapped, not all occurrences of the same string. The engine maps original page Tj/TJ token glyph offsets to rendered TextPosition glyph bounds. If the selected position cannot be matched unambiguously to an original PDF operator, it refuses the edit rather than silently changing the wrong location. Preview and final Save use the same position-aware mutation.

UNCHANGED: v1.0.112 single-word tap Replace/Delete UI; Text, Replace, Highlighter, Undo, Redo; three-dot Save/Save As; other browser features. No scanned-PDF OCR behavior changes. v1.0.105 locked baseline is untouched.

LIMITATIONS: Embedded fonts that cannot encode replacement or texts split across unsupported operator boundaries may still be rejected. In scanned PDFs, Delete remains a visual cover only. Actual uploaded PDF 2612182 (1).pdf and real-device touch tests were not available.
