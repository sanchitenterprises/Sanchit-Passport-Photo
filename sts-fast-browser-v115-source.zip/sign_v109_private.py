from pathlib import Path
import subprocess,zipfile,os,hashlib
home=Path('/mnt/data/sfb_v109_sign_private');home.mkdir(exist_ok=True)
os.chmod(home,0o700)
full=zipfile.ZipFile('/mnt/data/STS-Fast-Browser-v1.0.108-FULL-MATERIAL.zip')
ci=zipfile.ZipFile('/mnt/data/STS-Fast-Browser-v1.0.109-GitHub-unsigned-artifact.zip')
raw=ci.read('sts-fast-browser/app/build/outputs/apk/release/app-release-unsigned.apk')
unsigned=home/'unsigned.apk';unsigned.write_bytes(raw)
for filename,key in [('STS-Fast-Browser-Signing-Key.jks','keystore'),('apksigner.jar','jar')]:
 p=home/filename;p.write_bytes(full.read('05-PRIVATE-SIGNING/'+filename));os.chmod(p,0o600)
review=full.read('05-PRIVATE-SIGNING/STS-Fast-Browser-Signing-Key-README.txt').decode()
props={l.split(':',1)[0].strip().lower():l.split(':',1)[1].strip() for l in review.splitlines() if ':' in l}
assert all(k in props for k in ['alias','store password','key password'])
old=Path('/mnt/data/STS-Fast-Browser-v1.0.108.apk')
new=Path('/mnt/data/STS-Fast-Browser-v1.0.109.apk')
cmd=['java','-cp',str(home/'apksigner.jar'),'com.android.apksigner.ApkSignerTool','sign','--ks',str(home/'STS-Fast-Browser-Signing-Key.jks'),'--ks-key-alias',props['alias'],'--ks-pass','env:KSPASS','--key-pass','env:KEYPASS','--v1-signing-enabled','true','--v2-signing-enabled','true','--v3-signing-enabled','true','--out',str(new),str(unsigned)]
env=os.environ.copy();env['KSPASS']=props['store password'];env['KEYPASS']=props['key password']
p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env,timeout=120)
if p.returncode:raise RuntimeError('Signing failed: '+p.stderr[-900:])

def verify(apk):
 q=subprocess.run(['java','-cp',str(home/'apksigner.jar'),'com.android.apksigner.ApkSignerTool','verify','--verbose','--print-certs',str(apk)],capture_output=True,text=True,timeout=120)
 if q.returncode:raise RuntimeError('APK verification failed '+q.stderr[-500:])
 return q.stdout
before=verify(old);after=verify(new)
import re
fingerprint=r'Signer #1 certificate SHA-256 digest: ([0-9a-f]+)'
prior=re.search(fingerprint,before,re.I);latest=re.search(fingerprint,after,re.I)
assert prior and latest and prior.group(1)==latest.group(1), 'Cert mismatch'
assert 'Verified using v2 scheme (APK Signature Scheme v2): true' in after
assert 'Verified using v3 scheme (APK Signature Scheme v3): true' in after
print('Signed v109:',new,'bytes:',new.stat().st_size,'SHA256:',hashlib.sha256(new.read_bytes()).hexdigest())
print('Same certificate as v108:',True)
print('Signature v2/v3 valid:',True)
