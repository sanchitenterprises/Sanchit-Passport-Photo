from pathlib import Path
p=Path(__file__).parent/'app/src/main/java/com/sts/fastbrowser/PdfViewerActivity.java'
s=p.read_text()
def replace(old,new):
 global s
 if old not in s: raise RuntimeError('missing target: '+old[:120])
 s=s.replace(old,new,1)
replace('private String pdfTool = "Move";', '''private String pdfTool = "Move";
    private boolean textBold, textPlacementArmed;
    private PdfEditMark lastPlacedText;
    private LinearLayout styleRow, paletteRow;
    private TextView boldButton, colourButton;''')
replace('for (String label : new String[]{"Move", "Text", "Replace", "Select", "Pen", "Highlight", "Undo", "Redo", "Colour", "Size", "Save", "Save As", "Done"})',
        'for (String label : new String[]{"Text", "Replace", "Highlighter", "Undo", "Redo"})')
replace('''            int icon = "Undo".equals(label)?R.drawable.ic_undo:"Redo".equals(label)?R.drawable.ic_redo:
                    label.startsWith("Save")?R.drawable.ic_save:"Done".equals(label)?R.drawable.ic_done:
                    "Pen".equals(label)?R.drawable.ic_edit:0;''',
'''            int icon = "Undo".equals(label)?R.drawable.ic_undo:"Redo".equals(label)?R.drawable.ic_redo:0;''')
replace('''        textActionButton.setOnClickListener(v -> {
            if (isPdfReplacementMode()) applyPdfReplacement();
            else hidePdfKeyboard();
        });''',
'''        textActionButton.setOnClickListener(v -> {
            if (isPdfReplacementMode()) applyPdfReplacement();
            else {
                if(inlineText.getText().toString().trim().isEmpty()){
                    editHint.setText("पहले Text लिखें, फिर Place दबाएँ");return;
                }
                textPlacementArmed=true;lastPlacedText=null;
                editHint.setText("PDF पर एक बार छुएँ; Text सिर्फ एक बार Place होगा");
                hidePdfKeyboard();
            }
        });''')
replace('''        textRow.setVisibility(View.GONE); editPanel.addView(textRow);
        saveRow = new LinearLayout(this);''',
'''        textRow.setVisibility(View.GONE); editPanel.addView(textRow);
        styleRow = new LinearLayout(this);styleRow.setGravity(Gravity.CENTER_VERTICAL);
        boldButton=editButton("Bold: OFF");boldButton.setOnClickListener(v->{
            textBold=!textBold;boldButton.setText(textBold?"Bold: ON":"Bold: OFF");
            modifyPlacedTextStyle();
        });
        styleRow.addView(boldButton,new LinearLayout.LayoutParams(-2,dp(40)));
        colourButton=editButton("Color");colourButton.setOnClickListener(v->{
            paletteRow.setVisibility(paletteRow.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE);
        });
        styleRow.addView(colourButton,new LinearLayout.LayoutParams(-2,dp(40)));
        styleRow.setVisibility(View.GONE);editPanel.addView(styleRow);
        paletteRow=new LinearLayout(this);paletteRow.setGravity(Gravity.CENTER_VERTICAL);
        int[] colors={Color.BLACK,Color.WHITE,Color.RED,Color.BLUE,Color.GREEN,Color.YELLOW,
            Color.parseColor("#FF9800"),Color.parseColor("#9C27B0")};
        for(int color:colors){
            TextView swatch=editButton("●");swatch.setTextSize(23);swatch.setTextColor(color);
            swatch.setContentDescription(String.format(java.util.Locale.ROOT,"Text color #%06X",color&0xFFFFFF));
            swatch.setOnClickListener(v->{inkColor=color;paletteRow.setVisibility(View.GONE);modifyPlacedTextStyle();updateEditHint();});
            paletteRow.addView(swatch,new LinearLayout.LayoutParams(0,dp(40),1));
        }
        paletteRow.setVisibility(View.GONE);editPanel.addView(paletteRow);
        saveRow = new LinearLayout(this);''')
replace('''        pdfEditing=true;editPanel.setVisibility(View.VISIBLE);pdfTool="Move";updateEditHint();''',
'''        pdfEditing=true;editPanel.setVisibility(View.VISIBLE);pdfTool="Move";
        textPlacementArmed=false;styleRow.setVisibility(View.GONE);paletteRow.setVisibility(View.GONE);
        textRow.setVisibility(View.GONE);updateEditHint();''')
# Toolbar actions central
start=s.index('    private void pdfEditorAction(String action) {')
end=s.index('    private boolean isPdfReplacementMode()', start)
s=s[:start]+'''    private void pdfEditorAction(String action) {
        if(pdfSaving)return;
        if("Undo".equals(action)||"Redo".equals(action)){
            ArrayList<ArrayList<PdfEditMark>> from="Undo".equals(action)?pdfUndo:pdfRedo;
            ArrayList<ArrayList<PdfEditMark>> to="Undo".equals(action)?pdfRedo:pdfUndo;
            if(!from.isEmpty()){
                to.add(new ArrayList<>(pdfMarks));pdfMarks.clear();pdfMarks.addAll(from.remove(from.size()-1));
                lastPlacedText=null;textPlacementArmed=false;
                refreshNativeReplacePreview();redrawPdfMarks();
            }
        }else if("Save".equals(action)){savePdfEdits(true);return;}
        else if("Save As".equals(action)){
            saveRow.setVisibility(saveRow.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE);return;
        }else{
            pdfTool="Highlighter".equals(action)?"Highlight":action;
            replacementSelection=null;replacementScanSelection=null;replacementRequestId++;
            spanActive=false;spanDragging=false;textSpanPage=-1;
            textPlacementArmed=false;lastPlacedText=null;
            boolean textMode="Text".equals(pdfTool)||isPdfReplacementMode();
            textRow.setVisibility(textMode?View.VISIBLE:View.GONE);
            styleRow.setVisibility(("Text".equals(pdfTool)||"Highlight".equals(pdfTool))?View.VISIBLE:View.GONE);
            boldButton.setVisibility("Text".equals(pdfTool)?View.VISIBLE:View.GONE);
            paletteRow.setVisibility(View.GONE);
            textActionButton.setText(isPdfReplacementMode()?"Apply":"Place");
            inlineText.setHint(isPdfReplacementMode()?"पुराना Text चुनें, नया Text लिखें":"Text लिखें और Place दबाएँ");
            if(isPdfReplacementMode())inlineText.setText("");
            hidePdfKeyboard();
        }
        updateEditHint();redrawPdfMarks();
    }
    private void modifyPlacedTextStyle(){
        if(!"Text".equals(pdfTool))return;
        PdfEditMark original=lastPlacedText;
        if(original==null||!pdfMarks.contains(original))return;
        PdfEditMark updated=original.copy();updated.color=inkColor;updated.bold=textBold;
        replacePdfMark(original,updated);lastPlacedText=updated;
    }
    /** Only swap a clone, never mutate a committed mark: Undo must restore prior size/position/style. */
    private void replacePdfMark(PdfEditMark original,PdfEditMark updated){
        int index=pdfMarks.indexOf(original);if(index<0)return;
        pdfUndo.add(new ArrayList<>(pdfMarks));if(pdfUndo.size()>30)pdfUndo.remove(0);
        pdfRedo.clear();pdfMarks.set(index,updated);updateEditHint();redrawPdfMarks();
    }
    private void updateEditHint(){
        android.widget.HorizontalScrollView strip=(android.widget.HorizontalScrollView)editPanel.getChildAt(0);
        LinearLayout buttons=(LinearLayout)strip.getChildAt(0);
        for(int i=0;i<buttons.getChildCount();i++){
            TextView button=(TextView)buttons.getChildAt(i);String label=String.valueOf(button.getTag());
            boolean selected=("Highlighter".equals(label)?"Highlight":label).equals(pdfTool);
            button.setTypeface(null,selected?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL);
            button.setTextColor(selected?Color.parseColor("#00796B"):Color.parseColor("#162326"));
            button.setEnabled(!pdfSaving&&(!"Undo".equals(label)||!pdfUndo.isEmpty())&&(!"Redo".equals(label)||!pdfRedo.isEmpty()));
            button.setAlpha(button.isEnabled()?1f:0.5f);
        }
        String prompt="Move".equals(pdfTool)?"Scroll / zoom":
            "Text".equals(pdfTool)?"लिखें → Place → Tap; Text को खींचें या दो उँगली से Resize करें":
            "Replace".equals(pdfTool)?"एक शब्द पर Tap, कई शब्दों के लिए Drag; Handles से Select बदलें":
            "Highlight".equals(pdfTool)?"Color चुनकर Highlight करें":"";
        editHint.setText(pdfSaving?"PDF Save हो रही है…":prompt+" • "+pdfMarks.size()+" edits");
    }
''' + s[end:]
replace('private boolean isPdfReplacementMode(){return "Replace".equals(pdfTool)||"Select".equals(pdfTool);}',
        'private boolean isPdfReplacementMode(){return "Replace".equals(pdfTool);}')
replace('!"Select".equals(pdfTool)||replacementRequestId!=request', ' !isPdfReplacementMode()||replacementRequestId!=request')
# menu Save actions, preserve other features
replace('''        pm.getMenu().add("Edit");
        pm.getMenu().add("Share");''','''        pm.getMenu().add("Edit");
        pm.getMenu().add("Save");
        pm.getMenu().add("Save As");
        pm.getMenu().add("Share");''')
replace('''            if ("Edit".equals(t)) { startPdfEditing(); return true; }
            if (!pdfMarks.isEmpty())''','''            if ("Edit".equals(t)) { startPdfEditing(); return true; }
            if ("Save".equals(t)||"Save As".equals(t)) {
                if(!pdfEditing)startPdfEditing();
                pdfEditorAction(t);return true;
            }
            if (!pdfMarks.isEmpty())''')
# replace touch handling and onDraw region
replace('''            for(PdfEditMark mark:pdfMarks)if(mark.page==pageIndex && !"Replace".equals(mark.kind))mark.draw(canvas,getWidth(),getHeight());''',
'''            for(PdfEditMark mark:pdfMarks)if(mark.page==pageIndex && !"Replace".equals(mark.kind) && mark!=movingTextOriginal)mark.draw(canvas,getWidth(),getHeight());''')
replace('''            if("Select".equals(pdfTool) && textSpanPage==pageIndex && spanActive){''',
'''            if("Replace".equals(pdfTool) && textSpanPage==pageIndex && spanActive){''')
replace('''        private PdfEditMark activeMark;
        private final Matrix''',
'''        private PdfEditMark activeMark;
        private PdfEditMark movingTextOriginal, movingTextDraft;
        private float dragOffsetX,dragOffsetY,initialPinchDistance,initialTextSize;
        private boolean pinchText;
        private final Matrix''')
# editTouch entire
start=s.index('        private boolean editTouch(MotionEvent event){')
end=s.index('\n        @Override\n        public boolean onTouchEvent',start)
s=s[:start]+'''        private PdfEditMark findTextAt(float x,float y){
            // Hit testing uses the same TextPaint size as drawing, with a small finger tolerance.
            for(int i=pdfMarks.size()-1;i>=0;i--){
                PdfEditMark mark=pdfMarks.get(i);
                if(mark.page!=pageIndex || !"Text".equals(mark.kind)||mark.points.isEmpty())continue;
                float[] pos=mark.points.get(0);
                android.graphics.Paint paint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
                paint.setTextSize(getWidth()*mark.size);
                paint.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT,
                    mark.bold?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL));
                float length=paint.measureText(mark.text)/Math.max(1,getWidth());
                float yheight=(paint.getTextSize()*1.5f)/Math.max(1,getHeight());
                float pad=0.012f;
                if(x>=pos[0]-pad&&x<=Math.min(1,pos[0]+length+pad)&&
                   y>=pos[1]-pad&&y<=Math.min(1,pos[1]+yheight+pad))return mark;
            }
            return null;
        }
        private boolean editTouch(MotionEvent event){
            if(pdfSaving)return true;
            if(!pdfEditing || "Move".equals(pdfTool))return false;
            getParent().requestDisallowInterceptTouchEvent(true);
            int action=event.getActionMasked();
            float[] xy=PdfEditGeometry.point(event.getX(),event.getY(),offsetX,offsetY,currentScale,getWidth(),getHeight());
            if("Text".equals(pdfTool)&&movingTextDraft!=null){
                if(action==MotionEvent.ACTION_POINTER_DOWN && event.getPointerCount()==2){
                    pinchText=true;
                    initialPinchDistance=(float)Math.hypot(event.getX(0)-event.getX(1),event.getY(0)-event.getY(1));
                    initialTextSize=movingTextDraft.size;
                    return true;
                }
                if(action==MotionEvent.ACTION_MOVE){
                    if(pinchText&&event.getPointerCount()>=2){
                        float now=(float)Math.hypot(event.getX(0)-event.getX(1),event.getY(0)-event.getY(1));
                        if(initialPinchDistance>1f)movingTextDraft.size=Math.max(0.009f,Math.min(0.15f,initialTextSize*now/initialPinchDistance));
                    }else if(!pinchText){
                        movingTextDraft.points.get(0)[0]=Math.max(0,Math.min(1,xy[0]-dragOffsetX));
                        movingTextDraft.points.get(0)[1]=Math.max(0,Math.min(1,xy[1]-dragOffsetY));
                    }
                    invalidate();return true;
                }
                if(action==MotionEvent.ACTION_POINTER_UP){return true;}
                if(action==MotionEvent.ACTION_UP){
                    replacePdfMark(movingTextOriginal,movingTextDraft);lastPlacedText=movingTextDraft;
                    movingTextOriginal=null;movingTextDraft=null;pinchText=false;
                    getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;
                }
                if(action==MotionEvent.ACTION_CANCEL){
                    movingTextOriginal=null;movingTextDraft=null;pinchText=false;
                    getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;
                }
                return true;
            }
            if(action==MotionEvent.ACTION_DOWN){
                if(xy[0]<0||xy[1]<0||xy[0]>1||xy[1]>1)return true;
                if("Replace".equals(pdfTool)){
                    boolean start=spanActive&&textSpanPage==pageIndex&&
                        Math.hypot(spanStartX-xy[0],spanStartY-xy[1])<SPAN_HANDLE_RADIUS;
                    boolean end=spanActive&&textSpanPage==pageIndex&&
                        Math.hypot(spanEndX-xy[0],spanEndY-xy[1])<SPAN_HANDLE_RADIUS;
                    if(!start&&!end){spanStartX=xy[0];spanStartY=xy[1];spanEndX=xy[0];spanEndY=xy[1];spanHandle=1;}
                    else spanHandle=start?0:1;
                    textSpanPage=pageIndex;spanActive=true;spanDragging=true;invalidate();return true;
                }
                if("Text".equals(pdfTool)){
                    PdfEditMark touched=findTextAt(xy[0],xy[1]);
                    if(touched!=null){
                        lastPlacedText=touched;textBold=touched.bold;inkColor=touched.color;
                        boldButton.setText(textBold?"Bold: ON":"Bold: OFF");
                        movingTextOriginal=touched;movingTextDraft=touched.copy();
                        float[] p=touched.points.get(0);
                        dragOffsetX=xy[0]-p[0];dragOffsetY=xy[1]-p[1];pinchText=false;
                        invalidate();return true;
                    }
                    if(!textPlacementArmed){
                        editHint.setText("नया Text रखने के लिए पहले Place दबाएँ; पुराने Text को छूकर Move/Resize करें");return true;
                    }
                    String text=inlineText.getText().toString().trim();
                    if(text.isEmpty()){editHint.setText("पहले नया Text लिखें");return true;}
                    activeMark=new PdfEditMark(pageIndex,"Text",inkColor,0.026f,text);
                    activeMark.bold=textBold;
                    activeMark.point(xy[0],xy[1]);invalidate();return true;
                }
                if(pdfMarks.size()>=200){editHint.setText("200 edits पूरे; आगे बढ़ने से पहले Save करें");return true;}
                activeMark=new PdfEditMark(pageIndex,pdfTool,inkColor,0.021f,"");
                activeMark.point(xy[0],xy[1]);invalidate();return true;
            }
            if(action==MotionEvent.ACTION_MOVE && "Replace".equals(pdfTool)&&spanDragging){
                if(spanHandle==0){spanStartX=Math.max(0,Math.min(1,xy[0]));spanStartY=Math.max(0,Math.min(1,xy[1]));}
                else{spanEndX=Math.max(0,Math.min(1,xy[0]));spanEndY=Math.max(0,Math.min(1,xy[1]));}
                invalidate();return true;
            }
            if(action==MotionEvent.ACTION_UP && "Replace".equals(pdfTool)){
                if(spanDragging){
                    spanDragging=false;spanHandle=-1;
                    float distance=(float)Math.hypot(spanEndX-spanStartX,spanEndY-spanStartY);
                    if(distance<0.008f)selectPdfText(pageIndex,spanStartX,spanStartY);
                    else selectPdfRange(pageIndex,spanStartX,spanStartY,spanEndX,spanEndY);
                }
                getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;
            }
            if(action==MotionEvent.ACTION_MOVE && activeMark!=null&&"Text".equals(activeMark.kind)){
                // Placement follows finger until released, but commits exactly once.
                activeMark.points.get(0)[0]=Math.max(0,Math.min(1,xy[0]));
                activeMark.points.get(0)[1]=Math.max(0,Math.min(1,xy[1]));invalidate();return true;
            }
            if(action==MotionEvent.ACTION_MOVE&&activeMark!=null){
                if(activeMark.points.size()<6000)activeMark.point(xy[0],xy[1]);invalidate();return true;
            }
            if(action==MotionEvent.ACTION_UP){
                if(activeMark!=null){
                    commitPdfMark(activeMark);
                    if("Text".equals(activeMark.kind)){
                        lastPlacedText=activeMark;textPlacementArmed=false;
                        editHint.setText("Text रखा गया; Move/Resize के लिए इसे छुएँ, नया Text रखने के लिए Place दबाएँ");
                    }
                    activeMark=null;
                }
                getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;
            }
            if(action==MotionEvent.ACTION_CANCEL){activeMark=null;spanDragging=false;spanHandle=-1;
                getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;}
            return true;
        }
''' + s[end:]
# when moving draft, show on canvas (and remove original)
replace('''            if(activeMark!=null)activeMark.draw(canvas,getWidth(),getHeight());''',
'''            if(activeMark!=null)activeMark.draw(canvas,getWidth(),getHeight());
            if(movingTextDraft!=null)movingTextDraft.draw(canvas,getWidth(),getHeight());''')
# mode initial replaces and state
replace('''versionCode 110''','''versionCode 110''') if False else None
p.write_text(s)
# mark class
m=p.with_name('PdfEditMark.java')
s=m.read_text()
s=s.replace('final int page, color, background; final String kind, text, oldText; final float size;',
'''final int page, background; int color; final String kind, text, oldText; float size;
 boolean bold=false;''')
s=s.replace(' void point(float x,float y){', ''' PdfEditMark copy(){
  PdfEditMark out=new PdfEditMark(page,kind,color,size,text,oldText,background);out.bold=bold;
  for(float[] p:points)out.point(p[0],p[1]);return out;
 }
 void point(float x,float y){''')
s=s.replace('tp.setTypeface(Typeface.DEFAULT);','tp.setTypeface(Typeface.create(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL));')
s=s.replace('''if("Highlight".equals(kind)){p.setColor(Color.YELLOW);p.setAlpha(85);}''','''if("Highlight".equals(kind)){p.setColor(color);p.setAlpha(85);}''')
m.write_text(s)
# increment
build=p.parents[3]/'build.gradle' # app/src/main/java/com ->? avoid
build=Path(__file__).parent/'app/build.gradle'
t=build.read_text().replace('versionCode 110','versionCode 111').replace("versionName '1.0.109'","versionName '1.0.110'")
build.write_text(t)
print('Patched',p)
