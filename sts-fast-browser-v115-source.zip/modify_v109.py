from pathlib import Path
src=Path('app/src/main/java/com/sts/fastbrowser')
file=src/'PdfTextSelection.java'
s=file.read_text()
needle='    private static float clamp(float value){return Math.max(0f,Math.min(1f,value));}\n'
patch='''    /** Two drag endpoints select a continuous word interval in reading order.
     * No guessed text is inserted: native replacement still validates the exact
     * PDF font/bytes and fails safely for unsupported fragmented content. */
    static Selection pickRange(PDDocument doc,int page,float sx,float sy,float ex,float ey) throws IOException {
        PDPage target=doc.getPage(page);
        PDRectangle rect=target.getCropBox();if(rect==null)rect=target.getMediaBox();
        int angle=((target.getRotation()%360)+360)%360;
        float w=angle%180==0?rect.getWidth():rect.getHeight();
        float h=angle%180==0?rect.getHeight():rect.getWidth();
        PdfTextSelection stripper=new PdfTextSelection(page,w,h);
        stripper.getText(doc);
        if(stripper.words.isEmpty())return null;
        int from=stripper.nearestIndex(sx,sy),to=stripper.nearestIndex(ex,ey);
        if(from<0||to<0)return null;
        if(from>to){int tmp=from;from=to;to=tmp;}
        if(to-from>=80)return null; // guard against accidental whole-page edits
        StringBuilder joined=new StringBuilder();
        float left=1,top=1,right=0,bottom=0,maxH=0;
        for(int i=from;i<=to;i++){
            Selection word=stripper.words.get(i);
            if(joined.length()>0){
                Selection previous=stripper.words.get(i-1);
                boolean sameLine=Math.abs(word.top-previous.top)<Math.max(word.height,previous.height)*0.9f;
                joined.append(sameLine?' ':'\\n');
            }
            joined.append(word.original);
            left=Math.min(left,word.left);top=Math.min(top,word.top);
            right=Math.max(right,word.right);bottom=Math.max(bottom,word.bottom);
            maxH=Math.max(maxH,word.height);
        }
        String text=joined.toString();
        if(text.length()>500)return null;
        return new Selection(page,text,left,top,right,bottom,maxH);
    }
    private int nearestIndex(float x,float y){
        int best=-1;float distance=Float.MAX_VALUE;
        for(int i=0;i<words.size();i++){
            Selection word=words.get(i);
            float dx=Math.max(word.left-x,Math.max(0,x-word.right));
            float dy=Math.max(word.top-y,Math.max(0,y-word.bottom));
            float d=dx*dx+dy*dy;
            if(d<distance){best=i;distance=d;}
        }
        return distance<=0.0025f?best:-1;
    }
'''
assert needle in s
s=s.replace(needle,patch+needle)
file.write_text(s)

file=src/'PdfScanTextReplace.java'
s=file.read_text()
needle='    private static void append(Text result,List<Candidate> out){\n'
patch='''    /** Select an OCR text span using two endpoints (never uploads the PDF). */
    static Found recognizeRange(Bitmap image,int page,float sx,float sy,float ex,float ey) throws Exception {
        TextRecognizer latin=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        TextRecognizer devanagari=TextRecognition.getClient(new DevanagariTextRecognizerOptions.Builder().build());
        ArrayList<Candidate> elements=new ArrayList<>();
        try {
            append(Tasks.await(latin.process(InputImage.fromBitmap(image,0))),elements);
            append(Tasks.await(devanagari.process(InputImage.fromBitmap(image,0))),elements);
        } finally {latin.close();devanagari.close();}
        ArrayList<Candidate> unique=new ArrayList<>();
        for(Candidate c:elements){
            if(c.rect==null || c.rect.isEmpty() || c.text.getText()==null || c.text.getText().trim().isEmpty())continue;
            boolean duplicated=false;
            for(Candidate prior:unique){
                Rect a=c.rect,b=prior.rect;
                Rect both=new Rect(a);
                if(both.intersect(b)){
                    float overlap=both.width()*(float)both.height()/Math.max(1,Math.min(a.width()*a.height(),b.width()*b.height()));
                    if(overlap>0.72f){duplicated=true;break;}
                }
            }
            if(!duplicated)unique.add(c);
        }
        if(unique.isEmpty())return null;
        unique.sort((a,b)->{
            if(Math.abs(a.rect.centerY()-b.rect.centerY()) <= Math.max(a.rect.height(),b.rect.height())*0.50f)
                return Integer.compare(a.rect.left,b.rect.left);
            return Integer.compare(a.rect.centerY(),b.rect.centerY());
        });
        float x1=sx*image.getWidth(),y1=sy*image.getHeight();
        float x2=ex*image.getWidth(),y2=ey*image.getHeight();
        int start=nearest(unique,x1,y1,image.getWidth());
        int end=nearest(unique,x2,y2,image.getWidth());
        if(start<0||end<0)return null;
        if(start>end){int t=start;start=end;end=t;}
        if(end-start>60)return null;
        Rect area=new Rect(unique.get(start).rect);
        StringBuilder text=new StringBuilder();
        for(int i=start;i<=end;i++){
            Candidate current=unique.get(i);
            if(i>start){
                Candidate prev=unique.get(i-1);
                boolean sameLine=Math.abs(current.rect.centerY()-prev.rect.centerY())<Math.max(current.rect.height(),prev.rect.height())*0.6f;
                text.append(sameLine?' ':'\\n');
            }
            text.append(current.text.getText());area.union(current.rect);
        }
        area.inset(-1,-1);
        area.intersect(0,0,image.getWidth(),image.getHeight());
        if(text.length()>500)return null;
        int background=background(image,area);boolean unsafe=background<0;
        if(unsafe)background=Color.WHITE;
        int foreground=foreground(image,area,background);
        return new Found(page,text.toString(),area,image,background,foreground,unsafe);
    }
    private static int nearest(List<Candidate> words,float x,float y,int width){
        int best=-1;float min=Float.MAX_VALUE;
        for(int i=0;i<words.size();i++){
            Rect r=words.get(i).rect;
            float dx=Math.max(r.left-x,Math.max(0,x-r.right));
            float dy=Math.max(r.top-y,Math.max(0,y-r.bottom));
            float distance=(dx*dx+dy*dy)/((float)width*width);
            if(distance<min){min=distance;best=i;}
        }
        return min>0.0025f?-1:best;
    }
'''
assert needle in s
s=s.replace(needle,patch+needle)
file.write_text(s)

file=src/'PdfViewerActivity.java'
s=file.read_text()
s=s.replace('private PdfScanTextReplace.Found replacementScanSelection;','''private PdfScanTextReplace.Found replacementScanSelection;
    // Drag-selection belongs to the existing in-viewer Replace editor; no new activity/window.
    private int textSpanPage=-1;
    private float spanStartX,spanStartY,spanEndX,spanEndY;
    private boolean spanActive,spanDragging;
    private int spanHandle=-1;
    private static final float SPAN_HANDLE_RADIUS=0.025f;''')
s=s.replace('"Move", "Text", "Replace", "Pen"','"Move", "Text", "Replace", "Select", "Pen"')
s=s.replace('if ("Replace".equals(pdfTool)) applyPdfReplacement();','if (isPdfReplacementMode()) applyPdfReplacement();')
s=s.replace('''            pdfTool=action;replacementSelection=null;replacementScanSelection=null;replacementRequestId++;
            boolean textMode="Text".equals(action)||"Replace".equals(action);
            textRow.setVisibility(textMode?View.VISIBLE:View.GONE);
            textActionButton.setText("Replace".equals(action)?"Apply":"Place");
            inlineText.setHint("Replace".equals(action)?"PDF text चुनें, फिर यहाँ बदलें":"Text लिखें, फिर PDF पर जगह छुएँ");
            if("Replace".equals(action))inlineText.setText("");''','''            pdfTool=action;replacementSelection=null;replacementScanSelection=null;replacementRequestId++;
            spanActive=false;spanDragging=false;textSpanPage=-1;
            boolean textMode="Text".equals(action)||isPdfReplacementMode();
            textRow.setVisibility(textMode?View.VISIBLE:View.GONE);
            textActionButton.setText(isPdfReplacementMode()?"Apply":"Place");
            inlineText.setHint(isPdfReplacementMode()?"Selected PDF text यहाँ बदलें":"Text लिखें, फिर PDF पर जगह छुएँ");
            if(isPdfReplacementMode())inlineText.setText("");''')
s=s.replace('''                  "Replace".equals(pdfTool)?" • पुराने text पर tap, नया लिखें, Apply और Save":""));''','''                  "Select".equals(pdfTool)?" • उँगली खींचकर शब्द चुनें; किनारे के handles से selection बदलें":"Replace".equals(pdfTool)?" • एक शब्द पर tap; कई शब्द के लिए Select खोलें":""));''')
needle='    private void selectPdfText(int page,float x,float y){\n'
insert='''    private boolean isPdfReplacementMode(){return "Replace".equals(pdfTool)||"Select".equals(pdfTool);}
    private void clearPdfSpan(){spanActive=false;spanDragging=false;textSpanPage=-1;spanHandle=-1;redrawPdfMarks();}
    /** Selection endpoints are page-normalized to survive zoom and scrolling. */
    private void selectPdfRange(int page,float sx,float sy,float ex,float ey){
        replacementSelection=null;replacementScanSelection=null;
        final int request=++replacementRequestId;
        editHint.setText("चुने हुए PDF text की जाँच कर रहे हैं…");
        pdfRenderExecutor.execute(()->{
            PdfTextSelection.Selection nativeText=null;
            PdfScanTextReplace.Found scanText=null;
            String error=null;
            try{
                synchronized(this){if(textDocument!=null)nativeText=PdfTextSelection.pickRange(textDocument,page,sx,sy,ex,ey);}
                if(nativeText==null){
                    Bitmap bitmap=null;
                    try{bitmap=renderPageBitmap(page,Math.min(1900,Math.max(1500,basePageRenderWidth*2)));
                        scanText=PdfScanTextReplace.recognizeRange(bitmap,page,sx,sy,ex,ey);
                    }finally{if(bitmap!=null&&!bitmap.isRecycled())bitmap.recycle();}
                }
            }catch(Exception e){error=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();}
            final PdfTextSelection.Selection selected=nativeText;
            final PdfScanTextReplace.Found scanned=scanText;
            final String failure=error;
            runOnUiThread(()->{
                if(destroyed||!pdfEditing||!"Select".equals(pdfTool)||replacementRequestId!=request)return;
                replacementSelection=selected;replacementScanSelection=scanned;
                if(selected!=null){
                    inlineText.setText(selected.original);
                    editHint.setText("चुना हुआ text: "+selected.original+" • अब नया text लिखें और Apply करें");
                }else if(scanned!=null){
                    inlineText.setText(scanned.text);
                    editHint.setText(scanned.complexBackground?
                        "चयन मिला, लेकिन stamp/line/background है; सुरक्षित Replace संभव नहीं":
                        "Scanned selection: "+scanned.text+" • font केवल अनुमानित होगा");
                }else{
                    inlineText.setText("");
                    editHint.setText(failure==null?"इस selection में PDF text नहीं मिला; handles बदलें":
                        "Selection नहीं मिला: "+failure);
                }
                redrawPdfMarks();
            });
        });
    }
'''
assert needle in s
s=s.replace(needle,insert+needle)
s=s.replace('if(destroyed||!pdfEditing||!"Replace".equals(pdfTool)||replacementRequestId!=request)return;','if(destroyed||!pdfEditing||!"Replace".equals(pdfTool)||replacementRequestId!=request)return;')
s=s.replace('if(sel==null && scanned==null){editHint.setText("पहले PDF के पुराने text पर tap करें");return;}','if(sel==null && scanned==null){editHint.setText("पहले पुराने PDF text को tap या Select करके चुनें");return;}')
s=s.replace('''                    replacementSelection=null;replacementScanSelection=null;
                    hidePdfKeyboard();''','''                    replacementSelection=null;replacementScanSelection=null;
                    clearPdfSpan();hidePdfKeyboard();''')
s=s.replace('''        replacementSelection=null;replacementScanSelection=null;
        hidePdfKeyboard();''','''        replacementSelection=null;replacementScanSelection=null;
        clearPdfSpan();hidePdfKeyboard();''')
needle='''            if(activeMark!=null)activeMark.draw(canvas,getWidth(),getHeight());
            canvas.restore();'''
insert='''            if(activeMark!=null)activeMark.draw(canvas,getWidth(),getHeight());
            if("Select".equals(pdfTool) && textSpanPage==pageIndex && spanActive){
                android.graphics.Paint p=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
                p.setColor(0x52008080);
                float sx=spanStartX*getWidth(),sy=spanStartY*getHeight();
                float ex=spanEndX*getWidth(),ey=spanEndY*getHeight();
                canvas.drawRect(Math.min(sx,ex),Math.min(sy,ey),Math.max(sx,ex),Math.max(sy,ey),p);
                p.setColor(0xFF00796B);p.setStyle(android.graphics.Paint.Style.STROKE);
                p.setStrokeWidth(dp(1.5f));
                canvas.drawRect(Math.min(sx,ex),Math.min(sy,ey),Math.max(sx,ex),Math.max(sy,ey),p);
                p.setStyle(android.graphics.Paint.Style.FILL);
                canvas.drawCircle(sx,sy,dp(6)/Math.max(1,currentScale),p);
                canvas.drawCircle(ex,ey,dp(6)/Math.max(1,currentScale),p);
            }
            canvas.restore();'''
assert needle in s
s=s.replace(needle,insert)
needle='''                if("Replace".equals(pdfTool)){
                    selectPdfText(pageIndex,xy[0],xy[1]);return true;
                }
                if("Text".equals(pdfTool)){'''
insert='''                if("Replace".equals(pdfTool)){
                    selectPdfText(pageIndex,xy[0],xy[1]);return true;
                }
                if("Select".equals(pdfTool)){
                    boolean start=spanActive && textSpanPage==pageIndex &&
                        Math.hypot(spanStartX-xy[0],spanStartY-xy[1])<SPAN_HANDLE_RADIUS;
                    boolean end=spanActive && textSpanPage==pageIndex &&
                        Math.hypot(spanEndX-xy[0],spanEndY-xy[1])<SPAN_HANDLE_RADIUS;
                    if(!start&&!end){
                        spanStartX=xy[0];spanStartY=xy[1];spanEndX=xy[0];spanEndY=xy[1];
                        spanHandle=1;
                    }else spanHandle=start?0:1;
                    textSpanPage=pageIndex;spanActive=true;spanDragging=true;invalidate();return true;
                }
                if("Text".equals(pdfTool)){'''
assert needle in s
s=s.replace(needle,insert)
needle='''            }else if(action==MotionEvent.ACTION_MOVE && activeMark!=null && !"Text".equals(activeMark.kind)){
                if(activeMark.points.size()<6000)activeMark.point(xy[0],xy[1]);invalidate();
            }else if(action==MotionEvent.ACTION_UP){'''
insert='''            }else if(action==MotionEvent.ACTION_MOVE && "Select".equals(pdfTool) && spanDragging){
                if(spanHandle==0){spanStartX=Math.max(0,Math.min(1,xy[0]));spanStartY=Math.max(0,Math.min(1,xy[1]));}
                else {spanEndX=Math.max(0,Math.min(1,xy[0]));spanEndY=Math.max(0,Math.min(1,xy[1]));}
                invalidate();
            }else if(action==MotionEvent.ACTION_MOVE && activeMark!=null && !"Text".equals(activeMark.kind)){
                if(activeMark.points.size()<6000)activeMark.point(xy[0],xy[1]);invalidate();
            }else if(action==MotionEvent.ACTION_UP && "Select".equals(pdfTool)){
                if(spanDragging){
                    spanDragging=false;spanHandle=-1;
                    float distance=(float)Math.hypot(spanEndX-spanStartX,spanEndY-spanStartY);
                    if(distance<0.008f){
                        // A tap in Select mode selects one word, just like Replace.
                        spanEndX=spanStartX;spanEndY=spanStartY;
                    }
                    selectPdfRange(pageIndex,spanStartX,spanStartY,spanEndX,spanEndY);
                }
                getParent().requestDisallowInterceptTouchEvent(false);invalidate();
            }else if(action==MotionEvent.ACTION_UP){'''
assert needle in s
s=s.replace(needle,insert)
s=s.replace('''            }else if(action==MotionEvent.ACTION_CANCEL || event.getPointerCount()>1){activeMark=null;invalidate();}''','''            }else if(action==MotionEvent.ACTION_CANCEL || event.getPointerCount()>1){
                activeMark=null;spanDragging=false;spanHandle=-1;
                getParent().requestDisallowInterceptTouchEvent(false);invalidate();
            }''')
s=s.replace('versionCode 109','versionCode 110') if False else s
file.write_text(s)

b=Path('app/build.gradle');s=b.read_text().replace('versionCode 109','versionCode 110').replace("versionName '1.0.108'","versionName '1.0.109'");b.write_text(s)
print('Source patches complete')
