from pathlib import Path
src=Path(__file__).resolve().parents[1]
n=(src/'app/src/main/java/com/sts/fastbrowser/PdfNativeTextReplace.java').read_text()
v=(src/'app/src/main/java/com/sts/fastbrowser/PdfViewerActivity.java').read_text()
assert 'Selected PDF text occurs more than once on the page' not in n
assert 'Match m=locate(doc,pageIndex,matches,left,top,right,bottom);' in n
assert 'final List<List<TextPosition>>' not in n or 'operations' in n
assert 'processOperator(Operator operator,List<COSBase> operands)' in n
assert 'protected void processTextPosition(TextPosition glyph)' in n
assert 'glyphBase+=glyphCount(str,font)' in n
assert 'getXDirAdj()' in n and 'getYDirAdj()' in n
assert 'Cannot uniquely locate tapped text' in n
assert 'setSuppressDuplicateOverlappingText(false)' in n
assert 'PdfNativeTextReplace.replace(doc,m.page,m.oldText,m.text,m.points.get(0)[0]' in v
assert 'PdfNativeTextReplace.delete(doc,m.page,m.oldText,m.points.get(0)[0]' in v
assert 'PdfNativeTextReplace.replace(doc,mark.page,mark.oldText,mark.text,mark.points.get(0)[0]' in v
assert 'PdfNativeTextReplace.delete(doc,mark.page,mark.oldText,mark.points.get(0)[0]' in v
assert 'new String[]{"Text", "Replace", "Highlighter", "Undo", "Redo"}' in v
assert 'PdfTextSelection.pick(textDocument,page,x,y)' in v
assert 'selectPdfText(pageIndex,xy[0],xy[1]);' in v
assert 'selectPdfRange(pageIndex,' not in v
assert '"ScanDelete".equals(kind)' in (src/'app/src/main/java/com/sts/fastbrowser/PdfEditMark.java').read_text()
assert "versionCode 114" in (src/'app/build.gradle').read_text()
print('PASS location-aware Replace/Delete source guards, no duplicate-string rejection')
