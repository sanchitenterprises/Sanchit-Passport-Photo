from pathlib import Path
root=Path(__file__).resolve().parents[1]
v=(root/'app/src/main/java/com/sts/fastbrowser/PdfViewerActivity.java').read_text()
m=(root/'app/src/main/java/com/sts/fastbrowser/PdfEditMark.java').read_text()
assert 'new String[]{"Text", "Replace", "Highlighter", "Undo", "Redo"}' in v
assert 'pm.getMenu().add("Save")' in v and 'pm.getMenu().add("Save As")' in v
assert '"Select".equals(pdfTool)' not in v
assert 'selectPdfText(pageIndex,xy[0],xy[1])' in v
assert 'selectPdfRange(pageIndex' not in v
assert 'textPlacementArmed=false;' in v
assert 'movingTextDraft.size=Math.max' in v
assert 'replacePdfMark(movingTextOriginal,movingTextDraft)' in v
assert 'PdfEditMark copy()' in m and 'bold?Typeface.BOLD:Typeface.NORMAL' in m
assert 'p.setColor(color);p.setAlpha(85)' in m
print('PASS PDF toolbar, in-viewer save, text placement/move/pinch, bold, color and stable Replace tap')
