from pathlib import Path
r=Path(__file__).resolve().parents[1]
v=(r/'app/src/main/java/com/sts/fastbrowser/PdfViewerActivity.java').read_text()
assert 'selectPdfText(pageIndex,xy[0],xy[1]);' in v
assert 'selectPdfRange(pageIndex,' not in v
assert 'spanDragging' not in v
assert 'canvas.drawRect(Math.min(sx,ex)' not in v
assert 'deleteTextButton=editButton("Delete")' in v
print('PASS: problematic range select removed; stable tap only, Delete within Replace')
