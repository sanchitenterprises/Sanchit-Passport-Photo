package com.sts.fastbrowser;

import com.tom_roush.pdfbox.cos.COSArray;
import com.tom_roush.pdfbox.cos.COSBase;
import com.tom_roush.pdfbox.cos.COSFloat;
import com.tom_roush.pdfbox.cos.COSName;
import com.tom_roush.pdfbox.cos.COSNumber;
import com.tom_roush.pdfbox.cos.COSString;
import com.tom_roush.pdfbox.contentstream.operator.Operator;
import com.tom_roush.pdfbox.pdfparser.PDFStreamParser;
import com.tom_roush.pdfbox.pdfwriter.ContentStreamWriter;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.pdmodel.PDPage;
import com.tom_roush.pdfbox.pdmodel.PDResources;
import com.tom_roush.pdfbox.pdmodel.common.PDStream;
import com.tom_roush.pdfbox.pdmodel.font.PDFont;
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.text.TextPosition;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Conservative *native* PDF text-object replacement, no white masking or rasterized text.
 * Only replaces an exact unique text fragment contained within one Tj/TJ string in the
 * page content stream, using its existing font and restoring the original text advance.
 * Rejects ambiguous, split-across-operators, non-encodable and image/scanned text.
 */
final class PdfNativeTextReplace {
    private PdfNativeTextReplace() {}
    private static final class Glyph {
        final int charFrom, charTo, byteFrom, byteTo;
        Glyph(int a,int b,int c,int d){charFrom=a;charTo=b;byteFrom=c;byteTo=d;}
    }
    private static final class Match {
        int opIndex, arrayIndex, fromByte, toByte;
        COSString token;
        PDFont font;
        int showIndex, glyphFrom, glyphTo;
    }

    /** Collects actual displayed glyph bounds for each original text-show operator.
     * Operator order (not visual/reading sorting) ties screen geometry to PDF bytes.
     * Unresolvable form streams and glyph mismatches fail closed. */
    private static final class ShowPositions extends PDFTextStripper {
        final List<List<TextPosition>> operations = new ArrayList<>();
        private List<TextPosition> collecting;
        ShowPositions(int pageIndex) throws IOException {
            super();
            setStartPage(pageIndex+1);setEndPage(pageIndex+1);
            setSortByPosition(false);
            setSuppressDuplicateOverlappingText(false);
        }
        @Override protected void processOperator(Operator operator,List<COSBase> operands) throws IOException {
            String op=operator.getName();
            if("Tj".equals(op)||"TJ".equals(op)){
                List<TextPosition> saved=collecting;
                List<TextPosition> glyphs=new ArrayList<>();
                collecting=glyphs;
                operations.add(glyphs);
                try{super.processOperator(operator,operands);}
                finally{collecting=saved;}
            }else super.processOperator(operator,operands);
        }
        @Override protected void processTextPosition(TextPosition glyph){
            if(collecting!=null)collecting.add(glyph);
            super.processTextPosition(glyph);
        }
    }

    private static final class Bounds {
        float left=Float.MAX_VALUE,top=Float.MAX_VALUE,right=-Float.MAX_VALUE,bottom=-Float.MAX_VALUE;
        boolean valid;
    }
    private static Bounds boundsFor(Match m,List<List<TextPosition>> positions,
                                    float pageWidth,float pageHeight){
        if(m.showIndex<0||m.showIndex>=positions.size()||pageWidth<=0||pageHeight<=0)return null;
        List<TextPosition> text=positions.get(m.showIndex);
        if(m.glyphFrom<0||m.glyphTo>text.size()||m.glyphFrom>=m.glyphTo)return null;
        Bounds result=new Bounds();
        for(int i=m.glyphFrom;i<m.glyphTo;i++){
            TextPosition g=text.get(i);
            float x=g.getXDirAdj(),y=g.getYDirAdj();
            float width=g.getWidthDirAdj(),height=g.getHeightDir();
            if(!Float.isFinite(x)||!Float.isFinite(y)||width<=0||height<=0)return null;
            result.left=Math.min(result.left,x/pageWidth);
            result.top=Math.min(result.top,(y-height)/pageHeight);
            result.right=Math.max(result.right,(x+width)/pageWidth);
            result.bottom=Math.max(result.bottom,(y+height*0.15f)/pageHeight);
            result.valid=true;
        }
        return result;
    }

    private static Match locate(PDDocument doc,int pageIndex,List<Match> matches,
                    float left,float top,float right,float bottom) throws IOException {
        if(matches.isEmpty())throw new IOException("Selected text not editable in PDF font/stream");
        if(!(left>=0&&right<=1&&top>=0&&bottom<=1&&left<right&&top<bottom))
            throw new IOException("Selected text coordinates missing");
        PDPage page=doc.getPage(pageIndex);
        PDRectangle r=page.getCropBox();if(r==null)r=page.getMediaBox();
        int rotation=((page.getRotation()%360)+360)%360;
        float pageWidth=rotation%180==0?r.getWidth():r.getHeight();
        float pageHeight=rotation%180==0?r.getHeight():r.getWidth();
        ShowPositions stripper=new ShowPositions(pageIndex);
        stripper.getText(doc);
        float centerX=(left+right)/2f,centerY=(top+bottom)/2f;
        float best=Float.MAX_VALUE,next=Float.MAX_VALUE;
        Match picked=null;
        for(Match m:matches){
            Bounds b=boundsFor(m,stripper.operations,pageWidth,pageHeight);
            if(b==null||!b.valid)continue;
            float bx=(b.left+b.right)/2f,by=(b.top+b.bottom)/2f;
            float dx=Math.abs(bx-centerX),dy=Math.abs(by-centerY);
            float h=Math.max(bottom-top,b.bottom-b.top);
            // Keep edits tied to the exact visible word, not just the same Unicode.
            if(dx>Math.max(0.012f,(right-left)*0.33f)||dy>Math.max(0.010f,h*0.45f))continue;
            float score=dx*dx+dy*dy;
            if(score<best){next=best;best=score;picked=m;}
            else if(score<next)next=score;
        }
        if(picked==null||next-best<0.000025f)
            throw new IOException("Cannot uniquely locate tapped text; PDF unchanged");
        return picked;
    }

    static void replace(PDDocument doc,int pageIndex,String oldText,String replacement,
                        float left,float top,float right,float bottom) throws IOException {
        mutate(doc,pageIndex,oldText,replacement,false,left,top,right,bottom);
    }

    /** Remove the exact selected native glyph bytes, retaining their advance.
     * This is actual content-stream deletion, not white paint or text overlay. */
    static void delete(PDDocument doc,int pageIndex,String oldText,
                       float left,float top,float right,float bottom) throws IOException {
        mutate(doc,pageIndex,oldText,"",true,left,top,right,bottom);
    }
    private static void mutate(PDDocument doc,int pageIndex,String oldText,String replacement,boolean deleting,
                               float left,float top,float right,float bottom) throws IOException {
        if (oldText==null||oldText.isEmpty()||replacement==null||(!deleting&&replacement.isEmpty())
                ||oldText.length()>500||replacement.length()>500)
            throw new IOException("Empty or overly long PDF text");
        PDPage page=doc.getPage(pageIndex);
        PDResources resources=page.getResources();
        if(resources==null)throw new IOException("No page font resources");
        PDFStreamParser parser=new PDFStreamParser(page);
        parser.parse();
        List<Object> tokens=parser.getTokens();
        PDFont font=null;
        List<Match> matches=new ArrayList<>();
        int showIndex=-1;
        for(int i=0;i<tokens.size();i++){
            Object current=tokens.get(i);
            if(!(current instanceof Operator))continue;
            String op=((Operator)current).getName();
            if("Tj".equals(op)||"TJ".equals(op))showIndex++;
            if("Tf".equals(op)){
                if(i>=2 && tokens.get(i-2) instanceof COSName && tokens.get(i-1) instanceof COSNumber)
                    font=resources.getFont((COSName)tokens.get(i-2));
            }else if("Tj".equals(op) && font!=null && i>=1 && tokens.get(i-1) instanceof COSString){
                findMatches((COSString)tokens.get(i-1),font,oldText,i,-1,showIndex,0,matches);
            }else if("TJ".equals(op) && font!=null && i>=1 && tokens.get(i-1) instanceof COSArray){
                COSArray items=(COSArray)tokens.get(i-1);
                int glyphBase=0;
                for(int j=0;j<items.size();j++)if(items.get(j) instanceof COSString){
                    COSString str=(COSString)items.get(j);
                    findMatches(str,font,oldText,i,j,showIndex,glyphBase,matches);
                    glyphBase+=glyphCount(str,font);
                }
            }
        }
        // Never choose by text alone. The same word may legitimately appear in a
        // business name, city, address or table. Select the match at the tap bounds.
        Match m=locate(doc,pageIndex,matches,left,top,right,bottom);
        byte[] raw=m.token.getBytes();
        byte[] before=Arrays.copyOfRange(raw,0,m.fromByte);
        byte[] oldBytes=Arrays.copyOfRange(raw,m.fromByte,m.toByte);
        byte[] after=Arrays.copyOfRange(raw,m.toByte,raw.length);
        byte[] newBytes;
        try { newBytes=m.font.encode(replacement); }
        catch(Exception e){throw new IOException("Existing PDF font cannot encode replacement",e);}
        float adjustment=byteWidth(m.font,newBytes)-byteWidth(m.font,oldBytes);
        COSArray changed=new COSArray();
        if(before.length!=0)changed.add(new COSString(before));
        changed.add(new COSString(newBytes));
        // TJ uses units of 1/1000 text-space; positive advance compensation.
        if(Math.abs(adjustment)>0.001f)changed.add(new COSFloat(adjustment));
        if(after.length!=0)changed.add(new COSString(after));
        if(m.arrayIndex<0){
            tokens.set(m.opIndex-1,changed);
            tokens.set(m.opIndex,Operator.getOperator("TJ"));
        }else{
            COSArray original=(COSArray)tokens.get(m.opIndex-1);
            COSArray rebuilt=new COSArray();
            for(int j=0;j<original.size();j++){
                if(j==m.arrayIndex){for(int k=0;k<changed.size();k++)rebuilt.add(changed.get(k));}
                else rebuilt.add(original.get(j));
            }
            tokens.set(m.opIndex-1,rebuilt);
        }
        // Prepare new stream first. Change page resources only after complete serialization.
        ByteArrayOutputStream data=new ByteArrayOutputStream();
        new ContentStreamWriter(data).writeTokens(tokens);
        PDStream stream=new PDStream(doc);
        try(OutputStream out=stream.createOutputStream(COSName.FLATE_DECODE)){
            data.writeTo(out);
        }
        page.setContents(stream);
    }

    private static float byteWidth(PDFont font,byte[] encoded) throws IOException {
        ByteArrayInputStream stream=new ByteArrayInputStream(encoded);
        float width=0;
        while(stream.available()>0)width+=font.getWidth(font.readCode(stream));
        return width;
    }

    private static int glyphCount(COSString token,PDFont font){
        try{
            ByteArrayInputStream in=new ByteArrayInputStream(token.getBytes());
            int n=0;while(in.available()>0){font.readCode(in);n++;}
            return n;
        }catch(Exception e){return -1000000;}
    }
    private static void findMatches(COSString token,PDFont font,String target,
                int opIndex,int arrIndex,int showIndex,int glyphBase,List<Match> out){
        try {
            byte[] raw=token.getBytes();
            ByteArrayInputStream input=new ByteArrayInputStream(raw);
            StringBuilder decoded=new StringBuilder();
            List<Glyph> glyphs=new ArrayList<>();
            while(input.available()>0){
                int from=raw.length-input.available();
                int code=font.readCode(input);
                int to=raw.length-input.available();
                String text=font.toUnicode(code);
                if(text==null||text.isEmpty())return;
                int charFrom=decoded.length();decoded.append(text);
                glyphs.add(new Glyph(charFrom,decoded.length(),from,to));
            }
            int from=decoded.indexOf(target);
            while(from>=0){
                int to=from+target.length();
                Glyph first=null,last=null;
                for(Glyph g:glyphs){if(g.charFrom==from)first=g;if(g.charTo==to)last=g;}
                if(first!=null&&last!=null&&first.byteFrom<last.byteTo){
                    Match match=new Match();match.opIndex=opIndex;match.arrayIndex=arrIndex;
                    match.token=token;match.font=font;match.fromByte=first.byteFrom;match.toByte=last.byteTo;
                    match.showIndex=showIndex;
                    int firstIndex=-1,lastIndex=-1;
                    for(int g=0;g<glyphs.size();g++){
                        if(glyphs.get(g)==first)firstIndex=g;
                        if(glyphs.get(g)==last)lastIndex=g;
                    }
                    match.glyphFrom=glyphBase+firstIndex;
                    match.glyphTo=glyphBase+lastIndex+1;
                    if(firstIndex>=0&&lastIndex>=firstIndex&&glyphBase>=0)out.add(match);
                }
                from=decoded.indexOf(target,from+1);
            }
        }catch(Exception ignored){/* unknown mapping: leave original PDF untouched */}
    }
}
