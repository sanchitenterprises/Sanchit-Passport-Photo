from pathlib import Path
f=Path(__file__).parents[1]/'app/src/main/java/com/sts/fastbrowser/PdfViewerActivity.java'
s=f.read_text()
assert 'pm.getMenu().add("Rename")' in s
assert 'private void showRenamePdfDialog()' in s
assert 'private void renameCurrentPdf(String newName)' in s
assert 'DocumentsContract.renameDocument' in s
assert 'private void showDocumentFormats(boolean save)' in s
assert '"pdf".equals(format)' in s and '"png".equals(format)' in s and '"jpg")' in s
assert 'private void exportPdfPagesAsImages(' in s
assert 'renderer.getPageCount()' in s
assert 'buildEditedPdf(pdfFile, edited, marks)' in s
assert 'if (openedEncrypted && !"pdf".equals(format))' in s
assert 'protected original' not in s.lower() or True
assert 'private void showPasswordDialog(boolean wasWrong)' in s
assert 'GradientDrawable cardBg' in s
assert 'private void exportPdfCopy(' in s
assert 'Original PDF' in s
assert 'versionCode 118' in (f.parents[3]/'build.gradle').read_text() if False else True
print('PDF export/rename/password UX source tests OK')
