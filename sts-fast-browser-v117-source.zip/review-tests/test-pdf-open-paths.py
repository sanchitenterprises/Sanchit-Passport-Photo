"""Guard source/read/credential/temporary browser PDF flows. Static tests, not an Android device test."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]
a=(p/'app/src/main/java/com/sts/fastbrowser/PdfViewerActivity.java').read_text()
b=(p/'app/src/main/java/com/sts/fastbrowser/MainActivity.java').read_text()
c=(p/'app/src/main/java/com/sts/fastbrowser/SafeHttpDownload.java').read_text()
checks={
 'local URI copy': 'copyUriToFile(sourceUri, sourceFile)' in a,
 'PDF header validation': 'hasPdfHeader(sourceFile)' in a,
 'HTML not mislabelled password': 'वेबसाइट ने PDF के बजाय दूसरा पेज भेजा है' in a,
 'Retry fresh download after source failure': 'if (pdfSourceReady && sourceFile != null' in a,
 'correct source referer': 'sourceReferer' in a and 'intent.putExtra("pdf_referer", referrer)' in b,
 'source webview agent': 'actual.getSettings().getUserAgentString()' in b,
 'password prompt': 'showPasswordDialog(fromPrompt)' in a,
 'wrong password retry': 'info.setText(wasWrong?' in a and 'पासवर्ड सही नहीं है' in a,
 'temporary decrypted view only': 'doc.setAllSecurityToBeRemoved(true)' in a and 'File.createTempFile("protected-view-"' in a,
 'one-time blob-token bridge': 'java.util.UUID.randomUUID().toString()' in b and 'class PdfBlobBridge' in b,
 'blob size cap': 'MAX_PDF_BLOB_BYTES = 64 * 1024 * 1024' in b,
 'blob bridge bound same source': 'new PdfBlobBridge(targetWebView)' in b,
 'blob stored app-private': 'new File(getCacheDir(), "pdf")' in b,
 'blob validated as PDF': "prefix[0]=='%' && prefix[1]=='P'" in b,
 'blob launched via internal content URI': '".pdfshare/"+Uri.encode(item.file.getName())' in b,
 'phone content grant': 'intent.setClipData(ClipData.newRawUri("STS document", uri))' in b,
 'HTTP auth origin isolation': 'sameOrigin(original, current)' in c,
 'five-button PDF toolbar': '"Text", "Replace", "Highlighter", "Undo", "Redo"' in a,
}
for name,valid in checks.items():
 if not valid: raise AssertionError(name)
print('PASS',len(checks),'PDF opening path checks')
