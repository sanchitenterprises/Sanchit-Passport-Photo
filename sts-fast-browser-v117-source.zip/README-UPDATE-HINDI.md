STS Fast Browser v1.0.117 — Professional PDF Viewer, Rename, Save/Save As Export
Package: com.sts.fastbrowser | versionName 1.0.117 | versionCode 118

- Protected PDF में compact rounded soft-teal dialog, clear warning, password visibility toggle, open/cancel buttons. Password transient; never stored.
- PDF Viewer three-dot में Rename. Local content provider/file के लिए वास्तविक नाम बदलने का प्रयास; remote/temporary downloaded PDF में नए नाम से नई कॉपी Downloads में बनेगी, वेबसाइट की फाइल नहीं बदलेगी. Rename विफल होने पर original सुरक्षित रहता है.
- Save/Save As में PDF / PNG / JPG. बिना edits Original को फिर Save की जरूरत नहीं; Save As से नए नाम और format में export. Edit वाला Save सुरक्षित PDF in-place only if writable; अन्यथा Save As copy. PDF बहुपृष्ठ हो तो PNG/JPG के सभी pages अलग चित्र के रूप में Pictures/STS Fast Browser में जाएंगे; PDF copies Downloads/STS Fast Browser में.
- Unsaved edits को image/PDF exports में actual edited PDF temp stream से render किया जाता है, न कि मूल bitmap-only screenshot से. Unsupported native font changes safely fail, preserving edits; do not fake success.
- Password-protected document image export warns that images do not retain PDF encryption. Unedited PDF copy preserves encryption.
- Toolbar Text, Replace, Highlighter, Undo, Redo unchanged. Browser PDF download and editing logic from v1.0.116 retained. Locked v1.0.105 untouched. APK Android real-device validation required.
